public class GotChange {
    public static void main(String[] args) {

    }

    private static int greedy(int num, int coinAmount, int[] coins) {
        for (int i = coins.length - 1; i >= 0; i--) {
            if (num - coins[i] >= 0) {
                return(greedy((num - coins[i]), coinAmount++, coins));
            }
        }
        return coinAmount;
    }
}
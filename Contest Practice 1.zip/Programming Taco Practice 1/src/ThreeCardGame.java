public class ThreeCardGame {
    public static void main(String[] args) {

    }
}

class Card implements Comparable<Card> {
    private String name, symbol;
    public Card(String name, String symbol) {
        this.name = name;
        this.symbol = symbol;
    }

    public Card(String identity) {
        String[] info = identity.split("");
        name = info[0];
        symbol = info[1];
    }

    public String getName() {
        return name;
    }

    public String getSymbol() {
        return symbol;
    }

    @Override
    public int compareTo(Card c) {
        return name.compareTo(c.getName());
    }
}
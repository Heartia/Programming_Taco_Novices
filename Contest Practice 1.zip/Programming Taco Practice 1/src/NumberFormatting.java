import java.text.DecimalFormat;

public class NumberFormatting {
    public static void main(String[] args) {
        double bigBoi = 31415926535426.1415926535426;
        DecimalFormat df = new DecimalFormat("#,###,###,##0.0000");
        System.out.println((df.format(bigBoi)));
    }
}
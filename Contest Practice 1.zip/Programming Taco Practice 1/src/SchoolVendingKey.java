import java.util.Scanner;
import java.text.NumberFormat;
/**
 * Write a description of class SchoolVending here.
 *
 * @author (your contestant number)
 * @version (a version number or a date)
 */
public class SchoolVendingKey {
    public static void main(String[] args) {
//Variable Declaration
        String Choice;
        int items = 0;
        double subTotal = 0;
        double grandTotal = 0;
        double tax = 0;
//Continue to call the menu until exit option
        do {
            Choice = Menu(items, subTotal); // Get the value of choice by calling menu
// if statments to handle the user's input.
            if (Choice.equalsIgnoreCase("A")) {
                items++;
                subTotal += 2;
            } else if (Choice.equalsIgnoreCase("B")) {
                items++;
                subTotal += 1;
            } else if (Choice.equalsIgnoreCase("C")) {
                items++;
                subTotal += 1;
            }
                else if (Choice.equalsIgnoreCase("E")) {
                items++;
                subTotal += .75;
            } else if (Choice.equalsIgnoreCase("F")) {
                items++;
                subTotal += .5;
            } else if (Choice.equalsIgnoreCase("G")) {
                items = 0;
                subTotal = 0;
            } else if (Choice.equalsIgnoreCase("H")) {
                FinalOutput(items, subTotal); //calls FinalOutput with current sales
            } else {
                items = 0;
                subTotal = 0;
                FinalOutput(items, subTotal); //calls FinalOutput with zeros
            }
        }
        while (!Choice.equalsIgnoreCase("H") && !Choice.equalsIgnoreCase("X"));
    }

    /**
     * Displays the current sales total and menu. Validates all input while ignoring case
     * pre: Items and Sub
     * post: returns the user's validated option
     */
    public static String Menu(int items, double Sub) {
        String userInput;
        NumberFormat formatter = NumberFormat.getCurrencyInstance(); //used to format current sales total
        Scanner input = new Scanner(System.in); //takes in user input
        do {
            CLS(); //calls the clear screen method
//Current Sale
            System.out.println(" Current Sales");
            System.out.println("Items Selected: " + items);
            System.out.print("Current Sales Total: ");
            System.out.println(formatter.format(Sub));
            System.out.println();
            System.out.println();
// Menu Screen
            System.out.println(" School Vending Menu");
            System.out.println("A: Notebook Paper - $2.00 B: Mechanical Pencils (3 Pack) - $1.00");
            System.out.println("C: 3 Ring Binder - $3.00 D: Pens (3 Pack)(Black,Red,Blue - $1.00");
            System.out.println("E: Folder - $0.75 F: Highlighter - $0.50");
            System.out.println("G: Clear Transaction H: Exit and pay");
            System.out.println("X: Cancel and Exit");
            System.out.print("Please Choose from the menu printed above: ");
            userInput = input.nextLine();
//validates user input
            if ((!userInput.equalsIgnoreCase("A")) && (!userInput.equalsIgnoreCase("B")) &&
                    (!userInput.equalsIgnoreCase("C")) && (!userInput.equalsIgnoreCase("D")) &&
                    (!userInput.equalsIgnoreCase("E")) && (!userInput.equalsIgnoreCase("F")) &&
                    (!userInput.equalsIgnoreCase("G")) && (!userInput.equalsIgnoreCase("H")) &&
                    (!userInput.equalsIgnoreCase("X"))) {
                System.out.println("Illegal Entry!");
                Sleep(2);//calls the sleep method (2 seconds)
                CLS(); //calls the clear screen method
            }
        }
        while ((!userInput.equalsIgnoreCase("A")) && (!userInput.equalsIgnoreCase("B")) &&
                (!userInput.equalsIgnoreCase("C")) && (!userInput.equalsIgnoreCase("D")) &&
                (!userInput.equalsIgnoreCase("E")) && (!userInput.equalsIgnoreCase("F")) &&
                (!userInput.equalsIgnoreCase("G")) && (!userInput.equalsIgnoreCase("H")) &&
                (!userInput.equalsIgnoreCase("X")));
        return (userInput.toUpperCase());
    }

    /**
     * Clear Screen Method
     * pre: none
     * post: clears the screen
     */
    public static void CLS() {
        System.out.print('\u000C');
    }

    /**
     * JAVA PROGRAMMING - REGIONAL 2017
     * Page 10 of 10
     * pauses the program
     * pre: number of seconds to pause
     * post: pauses the program
     */
    public static void Sleep(int seconds) {
        try {
            Thread.sleep(1000 * seconds); //1000 milliseconds is one second.
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Displays the Final Output screen
     * pre: number of items, and subtotal of sales
     * post: none
     */
    public static void FinalOutput(int items, double subTotal) {
        NumberFormat formatter = NumberFormat.getCurrencyInstance();
        CLS();
        System.out.println(" Final Sales");
        System.out.println("Items Selected: " + items);
        System.out.print("Current Sales Total: ");
        System.out.println(formatter.format(subTotal));
    }
}
public class MinCoins {

    /*
    * Given a list of N coins, their values (V1, V2, … , VN), and the total sum S.
    * Find the minimum number of coins the sum of which is S (we can use as many
    * coins of one type as we want), or report that it’s not possible to select
    * coins in such a way that they sum up to S.
     */

    public static void main(String[] args) {
        
    }
}
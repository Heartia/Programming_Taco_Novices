import java.util.Scanner;

public class SimpleInterest {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.printf("%.2f", (double)((scan.nextInt() * scan.nextInt() * scan.nextInt())/100));
    }
}
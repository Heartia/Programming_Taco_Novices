public class LongIncreaseSubsequence {

    private static int maxLength = 1, bestEnd = 0;

    public static void main(String[] args) {

    }

    /*
    * There is an O(N^2) solution and a more efficient O(N log N) solution.
    *
    * Here, we'll do O(N^2) first, then O(N log N) later.
     */

    private static void longIncSub(int[] array) {
        int[] dp = new int[array.length], prev = new int[array.length];
        dp[0] = 1;
        prev[0] = -1;

        for (int i = 1; i < array.length; i++) {
            dp[i] = 1;
            prev[i] = -1;

            for (int j = i - 1; j >= 0; j--) {
                if (dp[j] + 1 > dp[i] && array[j] < array[i]) {
                    dp[i] = dp[j] + 1;
                    prev[i] = j;
                }
            }

            if (dp[i] > maxLength) {
                bestEnd = i;
                maxLength = dp[i];
            }
        }
    }
}
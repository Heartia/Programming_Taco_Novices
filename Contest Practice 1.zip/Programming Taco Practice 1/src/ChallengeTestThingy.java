import java.util.ArrayList;
import java.util.Arrays;

public class ChallengeTestThingy {
    public static void main(String[] args) {
        /*String s = "Baton Rouge";
        String t = s.charAt(3) + ""; // You can't directly store chars in string
        t = t.concat(s.substring(7, 9));
        System.out.println(t);

        ArrayList<Object> a = new ArrayList<Object>();
        a.add(new Object());
        a.add(8);
        a.addAll(a);
        a.add(null);
        a.add("ksikk");

        System.out.println(a.get(0) == a.get(2));
        System.out.println(a);
        System.out.println(a.get(5) instanceof Object);

        String k = "212 wildcats hurt somebody out there!";
        String[] sA = k.split("(\\w{2})");
        System.out.println(Arrays.toString(sA));
        System.out.println(sA.length + " " + sA[3]);

        byte b = 100;
        int ib = 0b100;
        System.out.println(ib);

        System.out.printf("%10.3f",121.3121);

        int x = 6, y = 12;
        System.out.println(x / (y / 4) + " " + y / 4);
        x/=y/=4;
        System.out.println(x + " " + y);

        int x = 7;
        if (x <= 9 && (++x) >= 8) {
            System.out.print(2);
        }
        if (x == 8) {
            System.out.print(1);
        }
        System.out.println(2 + " " + x);

        int a = 5, b = 4, c = 3, d = 2, e = 1;

        System.out.println(a/=b+=c+=d+=a-=e*=6);
        System.out.println(a += b);

        int[] y = {1, 2, 3, 4, 5, 0};
        int k = y[0];
        for (int x = 0; x < 22; x++) {
            System.out.println(k);
            k = y[k];
        }
        System.out.println(k);

        int n = 2;
        for (int i = n; i <= 99; i++) {
            n+= i;
        }
        System.out.println(n);

        System.out.println((99*(99+2))/2);*/

        System.out.println(Math.sqrt(64));
    }
}
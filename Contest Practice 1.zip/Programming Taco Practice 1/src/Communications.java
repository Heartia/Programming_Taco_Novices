import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class Communications {
    public static void main(String[] args) {
        String filename = "Communications.txt";
        try {
            BufferedReader br = new BufferedReader(new FileReader(filename));

            
        } catch (FileNotFoundException e) {
            System.out.println("Error: File Not Found " + filename);
        }
    }

    private static void menu() {

    }

    private static void sleep() {

    }

    private static void clearScreen() {

    }
}
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;

public class CountDays {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String month = scan.next();
        int year = scan.nextInt();
        String day = scan.next();


    }

}

class Clock {

    private static HashMap<String, Integer> months = new HashMap<>();
    private static String[] days = new String[]{"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
    private int date, monthInt, year;
    private String day, monthStr;

    Clock(int day, String month, int year) {
        date = day;
        monthStr = month;
        this.year = year;

        monthInt = months.get(monthStr);
    }

    Clock(String day, String month, int year) {
        this.day = day;
        monthStr = month;
        this.year = year;

        monthInt = months.get(monthStr);
    }

    Clock(int day, int month, int year) {
        date = day;
        monthInt = month;
        this.year = year;


    }

    Clock(String day, int month, int year) {
        this.day = day;
        monthInt = month;
        this.year = year;
    }

    private static void fillMap() {
        months.put("January", 31);
        months.put("February", 28);
        months.put("March", 31);
        months.put("April", 30);
        months.put("May", 31);
        months.put("June", 30);
        months.put("July", 31);
        months.put("August", 31);
        months.put("September", 30);
        months.put("October", 31);
        months.put("November", 30);
        months.put("December", 31);
    }

}
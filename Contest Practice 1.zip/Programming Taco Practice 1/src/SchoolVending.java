public class SchoolVending {
    public static void main(String[] args) {

    }
}
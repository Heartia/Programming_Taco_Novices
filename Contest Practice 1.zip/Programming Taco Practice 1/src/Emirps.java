import java.io.*;
import java.math.BigInteger;

public class Emirps {
    private static final int EMIRP = 2, PRIME = 1, NOTPRIME = 0;

    public static void main(String[] args) {
        String filename = "Emirps.txt";
        try {
            BufferedReader br = new BufferedReader(new FileReader(filename));
            StringBuilder outputBuilder = new StringBuilder();
            String line = "";

            while((line = br.readLine()) != null) {
                int primeChance = isEmirp(line);
                if (primeChance == NOTPRIME) {
                    outputBuilder.append(line + " is not prime\n");
                }
                else if (primeChance == PRIME) {
                    outputBuilder.append(line + " is a prime\n");
                }
                else if (primeChance == EMIRP) {
                    outputBuilder.append(line + " is not prime\n");
                }
            }

            writeToFile(filename, outputBuilder.toString());
        } catch (FileNotFoundException e) {
            System.out.println("File Being Read From Not Found: " + filename);
        } catch (IOException e) {
            System.out.println("Issues With File Being Read From: " + filename);
        }
    }

    private static int isEmirp(String nString) {
        if (!isPrime(Integer.parseInt(nString))) {
            if (!isPrime(Integer.parseInt(new StringBuilder(nString).reverse().toString()))) {
                return EMIRP;
            }
            else {
                return PRIME;
            }
        }
        return NOTPRIME;
    }

    private static boolean isPrime(int n) {
        if ( n > 2 && n % 2 == 0 ) {
            System.out.println(n + " is not prime");
            return false;
        }
        int top = (int)Math.sqrt(n) + 1;
        for(int i = 3; i < top; i+=2){
            if(n % i == 0){
                System.out.println(n + " is not prime");
                return false;
            }
        }
        System.out.println(n + " is prime");
        return true;
    }

    private static void writeToFile(String filename, String text) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(filename));
            bw.write(text);
            bw.flush();
            bw.close();
        } catch (IOException e) {
            System.out.println("File Written To Not Found: " + filename);
        }
    }
}
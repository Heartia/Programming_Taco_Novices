import javax.swing.*;

public class AppSwing1 {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AppSwing2();
            }
        });
    }

}
import java.io.*;
import java.util.Scanner;

public class BaseKAddition {
    public static void main(String[] args) {
        if (0 < args.length) {
            String filename = args[0];
            File file = new File(filename);
            try {
                BufferedReader br = new BufferedReader(new FileReader(file));

                    String caseString = br.readLine(), baseString = br.readLine(),
                            num1String = br.readLine(), num2String = br.readLine();

                    int cases = Integer.parseInt(caseString), base = Integer.parseInt(baseString);
                    int num1 = Integer.parseInt(num1String, base), num2 = Integer.parseInt(num2String, base);
                    int sum = 0;
                    for (int c = 0; c < cases; c++) {
                        sum += add(num1, num2);
                    }

                    writeToFile(filename, base, num1, num2, sum);

            } catch (FileNotFoundException e) {
                System.out.println("Error: File Reading From Not Found: " + filename);
                return;
            } catch (IOException e) {
                System.out.println("Error: Trouble Reading From File: " + filename);
                return;
            } catch (NumberFormatException e) {
                System.out.println("Error: Please Re-enter Values Into Input/Output File: " + filename);
                return;
            }
            System.out.println("Program Successfully Finished.");
        }
        else {
            System.out.println("Error: No File Name Input Into The Command Line");
        }
    }

    private static int add(int num1, int num2) {
        return num1 + num2;
    }

    private static void writeToFile(String fileName, int base, int num1, int num2, int sum) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileName));
            bw.write("The base of the numbers to add is " + base);
            bw.newLine();
            bw.write("The first number is " + Integer.toString(num1, base));
            bw.newLine();
            bw.write("The second number is " + Integer.toString(num2, base));
            bw.newLine();
            bw.write("The sum is: " + Integer.toString(sum, base));
            bw.flush();
            bw.close();
        } catch (IOException e) {
            System.out.println("Error: Trouble Writing To File: " + fileName);
        }
    }
}
import java.util.Arrays;

public class CSCTest1718_01 {
    public static void main(String[] args) {
        int c = 0;
        for (int i = 0; i < 100; i++) {
            if (i > 20 ^ i < 80) { // > 20, NOT >= 20. Pay attention.
                c++;
                System.out.println("c before: " + (c - 1) +
                        " | c after: " + c + " | current i: " + i);
            }
        }
        System.out.println(c);

        System.out.println(flip(-64));

        String x = "abaaababa";
        String[] strs = x.split("a");
        System.out.println(Arrays.toString(strs));
        System.out.println(strs.length);

        System.out.println(Math.log(1/Math.E));

        System.out.println(shift(6, 1, "<<")); // Equivalent to 6 * 2
        System.out.println(shift(6, 2, "<<")); // Equivalent to 6 * 4
        System.out.println(shift(6, 3, "<<")); // Equivalent to 6 * 8
        System.out.println(shift(Integer.MAX_VALUE, 1, "<<")); // The bits roll over.

        // In most cases, when the bits don't roll over, left shift is num * 2 ^ shiftAmt
        //   This is faster for compilers, and is honestly better.

        System.out.println(shift(48, 1, ">>>")); // Equivalent to 48 / 2
        System.out.println(shift(48, 2, ">>>")); // Equivalent to 48 / 4
        System.out.println(shift(48, 3, ">>>")); // Equivalent to 48 / 8

        // In most cases, when the bits aren't lost, logical right shift is num / 2 ^ shiftAmt
        // It also pads with 0.

        System.out.println(shift(939524102, 4, "<<")); // Bits are lost here.
        System.out.println(shift(shift(939524102, 4, "<<"), 4, ">>>")); // Bits are also lost here.
        // The original value can never be received again once bits are lost.

        System.out.println(shift(Integer.parseInt("1000000000000000000000001100000", 2), 4, ">>"));
        // Arithmetic right shift is just like logical right shift, except it pads with the most significant digit.
        System.out.println(stars(5));

        byte b = 127;
        b++;
        System.out.println(b);
    }

    private static int flip(int n) {
        return ~n;
    }

    private static int shift(int num, int shiftAmt, String shift) {
        if (shift.equals(">>")) { // Arithmetic signed right shift
            return num >> shiftAmt;
        }
        else if (shift.equals(">>>")) { // Logical unsigned right shift
            return num >>> shiftAmt;
        }
        else if (shift.equals("<<")) { // Left Shift
            return num << shiftAmt;
        }
        return -1;
    }

    private static String stars(int n) {
        if (n == 0)
            return "*";
        String stars = stars(n - 1);
        System.out.println("*");
        String s;
        s = stars.replaceAll(".", "*");
        return s;
    }
}

abstract class Song implements Comparable<Song> {
    String title;
    int plays;
    public static int songsMade;

    public Song(String str, int p) {
        title = str;
        plays = p;
        songsMade++;
    }

    public int compareTo(Song s) {
        return s.plays-plays;
    }

    public String toString() {
        return title+" "+plays;
    }
}

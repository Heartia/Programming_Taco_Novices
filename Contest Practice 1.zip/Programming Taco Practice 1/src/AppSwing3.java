import javax.swing.*;
import java.awt.*;

public class AppSwing3 extends JPanel {

    private JTextArea textArea;

    public AppSwing3() {
        textArea = new JTextArea();

        setLayout(new BorderLayout());

        add(new JScrollPane(textArea), BorderLayout.CENTER);
    }

    public void append(String text) {
        textArea.append(text);
    }
}
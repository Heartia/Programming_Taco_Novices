import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AppSwing2 extends JFrame{

    private JButton button;
    private AppSwing3 textPanel;

    public AppSwing2() {
        super("IntelliJ - Regional Content_17");

        setLayout(new BorderLayout());

        button = new JButton("Clicc me, boi");
        textPanel = new AppSwing3();
        textPanel.append("\t\t\tCurrent Sales\n" +
                "Items Selected: 0\n" +
                "Current Sales Total: $0.00\n" +
                "" +
                "\t\t\tSchool Vending Menu\n" +
                "A: Notebook Paper - $2.00\t\t\tB: Mechanical Pencil (3 Pack) - $1.00\n" +
                "C: 3 Ring Binder - $3.00\t\t\tD: Pens (3 Pack)(Black, Red, Blue) - $1.00\n" +
                "E: Foler - $0.75\t\t\t\tF: Highlighter - $0.50\n" +
                "G: Clear Transaction\t\t\tH: Exit and Pay\n" +
                "X: Cancel and Exit\n" +
                "Please Choose from the menu printed above:\n");

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textPanel.append("What are you doing?\n");
            }
        });

        add(textPanel, BorderLayout.CENTER);
        add(button, BorderLayout.SOUTH);

        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
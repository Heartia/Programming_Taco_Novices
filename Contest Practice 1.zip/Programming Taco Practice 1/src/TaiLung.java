import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class TaiLung {
    private static ArrayList<Integer> list = new ArrayList<>();
    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("Tailung.txt"));

        int j = scan.nextInt(), s = scan.nextInt();
        scan.nextInt();


        while (scan.hasNext()) {
            list.add(scan.nextInt());
        }

        int speed = j - s;

        if (speed <= 0) {
            System.out.println(-1);
            System.exit(-1);
        }

        int jumps = -1;

        for (int i = 0; i < list.size(); i++) {
            while (list.get(i) > 0) {
                list.set(i, list.get(i) - speed);
                jumps++;
            }
        }

        System.out.println(jumps);
    }
}
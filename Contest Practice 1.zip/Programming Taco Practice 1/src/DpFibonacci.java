public class DpFibonacci {
    private static long[] memo;
    private static final long NIL = -1;

    public static void main(String[] args) {
        long start = System.currentTimeMillis();
        System.out.println(dPfibonacci(45));
        System.out.println(System.currentTimeMillis() - start);
        start = System.currentTimeMillis();
        System.out.println(fibonacci(45));
        System.out.println(System.currentTimeMillis() - start);
    }

    /*
    * This is slow, however. Notice how certain sub-problems are
    * solved twice or even thrice. Put in a bigger number and you'll
    * be overloading the computer and taking way too much time.
     */

    private static long fibonacci(long n) {
        if (n == 0) return 0;
        else if (n == 1) return 1;
        else {
            return fibonacci(n - 1) + fibonacci(n - 2);
        }
    }

    /*
    * Here, tabulation is shown, where every single sub problem is
    * solved from the beginning, before the system quite simply just
    * looks up the problem after it has been solved.
     */

    private static long dPfibonacci(int n) {
        long[] memo = new long[n + 1];
        memo[0] = 0;
        memo[1] = 1;
        for (int i = 2; i < n + 1; i++) {
            memo[i] = memo[i - 1] + memo[i - 2];
        }
        return memo[n];
    }

    /*
     * So let's think about a dynamic Programming solution, with
     * memoisation.
     *
     * Memoisation means no re-computation. This means more efficiency.
     */

    private static void initialise() {
        memo = new long[Integer.MAX_VALUE];
        for (int i = 0; i < Integer.MAX_VALUE; i++) {
            memo[i] = NIL;
        }
    }

    private static long dPfibonacci2(int n) {
        initialise();
        if (memo[n] == NIL) { //Checks to see if memo[n] is already recorded or not.
            if (n <= 1) { // Checks to see if n abides by the base case.
                memo[n] = n;
            }
            else { // Calls recursively if not abiding by the base case.
                memo[n] = dPfibonacci(n - 2) + dPfibonacci2(n - 2);
            }
        }
        return memo[n];
    }

    /*
    * Tabulation:
    * Works in bottom up fashion.
    * Avoids multiple lookups, and can subsequently save time.
    *
    * Memoisation:
    * Works in top down fashion.
    * Sometimes avoids computing solutions to subproblems that aren't needed.
    * Is sometimes more intuitive than tabulation.
     */
}
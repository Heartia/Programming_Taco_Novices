import javax.swing.*;
import java.awt.*;

public class Display extends JFrame {

    private TextHandler textPanel;

    public Display(String title, int width, int height) {
        super(title);

        setLayout(new BorderLayout());

        textPanel = new TextHandler();

        add(textPanel, BorderLayout.CENTER);

        setSize(width, height);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void write(String text) {
        textPanel.append(text);
    }
}
import javax.swing.*;
import java.awt.*;

public class TextHandler extends JPanel {

    private JTextArea textArea;

    public TextHandler() {
        textArea = new JTextArea();
        textArea.setFont(new Font("Tahoma", Font.PLAIN, 30));


        setLayout(new BorderLayout());

        add(new JScrollPane(textArea), BorderLayout.CENTER);
    }

    public void append(String text) {
        textArea.append(text);
    }
}
public class Game {

    Display display;

    public Game(String title, int width, int height) {
        display = new Display(title, width, height);
    }

}
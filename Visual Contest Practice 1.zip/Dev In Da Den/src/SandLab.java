
import javax.swing.*;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.event.*;

public class SandLab
{
    public static void main(String[] args)
    {
        SandLab lab = new SandLab(175, 300);
        lab.run();
    }

    //add constants for particle types here
    public static final int EMPTY = 0;
    public static final int EMPTYR = 3, EMPTYG = 4, EMPTYB = 25;
    public static final int METAL = 1;
    public static final int METALR = 122, METALG = 96, METALB = 90;
    public static final int SAND = 2;
    public static final int SANDR = 234, SANDG = 195, SANDB = 109;
    public static final int WATER = 3;
    public static final int WATERR = 64, WATERG = 141, WATERB = 209;
    public static final int TALLGRASS = 4;
    public static final int GRASSR = 80, GRASSG = 122, GRASSB = 69;
    public static final int DIRT = 5;
    public static final int DIRTR = 71, DIRTG = 55, DIRTB = 27;
    public static final int SOAKDIRT = 6;
    public static final int SDIRTR = 25, SDIRTG = 20, SDIRTB = 10;
    //do not add any more fields
    //No, listen to me. I will add mroe fields.
    private int[][] grid;
    private SandDisplay display;
    private Random random;

    public SandLab(int numRows, int numCols)
    {
        String[] names;
        names = new String[7];
        names[EMPTY] = "Empty";
        names[METAL] = "Metal";
        names[SAND] = "Sand";
        names[WATER] = "Water";
        names[TALLGRASS] = "Tall Grass";
        names[DIRT] = "Dirt";
        names[SOAKDIRT] = "Soaked Dirt";
        display = new SandDisplay("2D Minecraft", numRows, numCols, names);
        grid = new int[numRows][numCols];
        random = new Random();
    }

    //called when the user clicks on a location using the given tool
    private void locationClicked(int row, int col, int tool)
    {
        grid[row][col] = tool;
    }

    //copies each element of grid into the display
    public void updateDisplay()
    {
        for (int r = 0; r < grid.length; r++) {
            for (int c = 0; c < grid[r].length; c++)
            {
                switch (grid[r][c]) {
                    case EMPTY:
                        display.setColor(r, c, new Color(EMPTYR, EMPTYG, EMPTYB));
                        break;
                    case METAL:
                        display.setColor(r, c, new Color(METALR, METALG, METALB));
                        break;
                    case SAND:
                        display.setColor(r, c, new Color(SANDR, SANDG, SANDB));
                        break;
                    case WATER:
                        display.setColor(r, c, new Color(WATERR, WATERG, WATERB));
                        break;
                    case TALLGRASS:
                        display.setColor(r, c, new Color(GRASSR, GRASSG, GRASSB));
                        break;
                    case DIRT:
                        display.setColor(r, c, new Color(DIRTR, DIRTG, DIRTB));
                        break;
                    case SOAKDIRT:
                        display.setColor(r, c, new Color(SDIRTR, SDIRTG, SDIRTB));
                    default:
                        break;
                }
            }
        }
    }

    //called repeatedly.
    //causes one random particle to maybe do something.
    public void step()
    {
        int row = random.nextInt(grid.length);
        int col = random.nextInt(grid[0].length);
        if (grid[row][col] == SAND && row + 1 < grid.length) {
            if(grid[row + 1][col] == EMPTY) {
                grid[row][col] = EMPTY;
                grid[row + 1][col] = SAND;
            }
            else if (grid[row + 1][col] == WATER) {
                grid[row][col] = WATER;
                grid[row + 1][col] = SAND;
            }
        }
        else if (grid[row][col] == DIRT && row + 1 < grid.length) {
            if(grid[row + 1][col] == EMPTY) {
                grid[row][col] = EMPTY;
                grid[row + 1][col] = DIRT;
            }
            else if (grid[row + 1][col] == WATER) {
                grid[row + 1][col] = SOAKDIRT;
            }
        }
        else if (grid[row][col] == SOAKDIRT && row + 1 < grid.length) {
            if(grid[row + 1][col] == EMPTY) {
                grid[row][col] = EMPTY;
                grid[row + 1][col] = SOAKDIRT;
            }
        }
        else if (grid[row][col] == TALLGRASS && row - 1 > 0) {
            if(row + 1 < grid.length && grid[row - 1][col] == EMPTY && grid[row + 1][col] == DIRT) {
                grid[row - 1][col] = TALLGRASS;
                display.pause(10);
                if (row - 2 > 0) {
                    grid[row - 2][col] = TALLGRASS;
                }
                display.pause(10);
                if (row - 3 > 0) {
                    grid[row - 3][col] = TALLGRASS;
                }
                display.pause(10);
                if (row - 4 > 0) {
                    grid[row - 4][col] = TALLGRASS;
                }
                display.pause(10);
                if (row - 5 > 0) {
                    grid[row - 5][col] = TALLGRASS;
                }
            }
        }
        else if (grid[row][col] == EMPTY && row - 1 > 0 && grid[row - 1][col] == WATER) {
            grid[row][col] = WATER;
            grid[row - 1][col] = EMPTY;
        }
        else if (grid[row][col] == WATER && row + 1 < grid.length/* &&
              grid[row][col + 1] == EMPTY*/) {
            //boolean hasMovedDown = false;
            int rightOrLeft = random.nextInt(2) + 1;

            switch (rightOrLeft) {
                case 1: //Left
                    if (col - 1 >= 0 && grid[row][col - 1] == EMPTY) {
                        grid[row][col] = EMPTY;
                        grid[row][col - 1] = WATER;
                        if (row + 1 < grid.length && grid[row + 1][col - 1] == EMPTY) {
                            //hasMovedDown = true;
                            grid[row][col - 1] = EMPTY;
                            grid[row + 1][col - 1] = WATER;
                        }
                    }
                    else if (col + 1 < grid[0].length && grid[row][col + 1] == EMPTY) {
                        grid[row][col] = EMPTY;
                        grid[row][col + 1] = WATER;
                        if (row + 1 < grid.length && grid[row + 1][col + 1] == EMPTY) {
                            //hasMovedDown = true;
                            grid[row][col + 1] = EMPTY;
                            grid[row + 1][col + 1] = WATER;
                        }
                    }
                    break;
                case 2: //Right
                    if (col + 1 < grid[0].length && grid[row][col + 1] == EMPTY) {
                        grid[row][col] = EMPTY;
                        grid[row][col + 1] = WATER;
                        if (row + 1 < grid.length && grid[row + 1][col + 1] == EMPTY) {
                            //hasMovedDown = true;
                            grid[row][col + 1] = EMPTY;
                            grid[row + 1][col + 1] = WATER;
                        }
                    }
                    else if (col - 1 >= 0 && grid[row][col - 1] == EMPTY) {
                        grid[row][col] = EMPTY;
                        grid[row][col - 1] = WATER;
                        if (row + 1 < grid.length && grid[row + 1][col - 1] == EMPTY) {
                            //hasMovedDown = true;
                            grid[row][col - 1] = EMPTY;
                            grid[row + 1][col - 1] = WATER;
                        }
                    }
                    break;
            }
          /*if(!hasMovedDown && grid[row + 1][col] == EMPTY) {
            grid[row][col] = EMPTY;
            grid[row + 1][col] = EMPTY;
            grid[row + 1][col] = WATER;
          }*/
        }
    }

    //do not modify
    public void run()
    {
        while (true)
        {
            for (int i = 0; i < display.getSpeed(); i++)
                step();
            updateDisplay();
            display.repaint();
            display.pause(1);  //wait for redrawing and for mouse
            int[] mouseLoc = display.getMouseLocation();
            if (mouseLoc != null)  //test if mouse clicked
                locationClicked(mouseLoc[0], mouseLoc[1], display.getTool());
        }
    }
}

class SandDisplay extends JComponent implements MouseListener,
        MouseMotionListener, ActionListener, ChangeListener
{
    private Image image;
    private int cellSize = 4;
    private JFrame frame;
    private int tool;
    private int numRows;
    private int numCols;
    private int[] mouseLoc;
    private JButton[] buttons;
    private JSlider slider;
    private int speed;

    public SandDisplay(String title, int numRows, int numCols, String[] buttonNames)
    {
        this.numRows = numRows;
        this.numCols = numCols;
        tool = 1;
        mouseLoc = null;
        speed = computeSpeed(50);

        //determine cell size
        //cellSize = Math.max(1, 600 / Math.max(numRows, numCols));
        image = new BufferedImage(numCols * cellSize, numRows * cellSize, BufferedImage.TYPE_INT_RGB);

        frame = new JFrame(title);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.PAGE_AXIS));

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.LINE_AXIS));
        frame.getContentPane().add(topPanel);

        setPreferredSize(new Dimension(numCols * cellSize, numRows * cellSize));
        addMouseListener(this);
        addMouseMotionListener(this);
        topPanel.add(this);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.PAGE_AXIS));
        topPanel.add(buttonPanel);

        buttons = new JButton[buttonNames.length];

        for (int i = 0; i < buttons.length; i++)
        {
            buttons[i] = new JButton(buttonNames[i]);
            buttons[i].setActionCommand("" + i);
            buttons[i].addActionListener(this);
            buttonPanel.add(buttons[i]);
        }

        buttons[tool].setSelected(true);

        slider = new JSlider(JSlider.HORIZONTAL, 0, 100, 50);
        slider.addChangeListener(this);
        slider.setMajorTickSpacing(1);
        slider.setPaintTicks(true);
        Hashtable<Integer, JLabel> labelTable = new Hashtable<Integer, JLabel>();
        labelTable.put(new Integer(0), new JLabel("Slow"));
        labelTable.put(new Integer(100), new JLabel("Fast"));
        slider.setLabelTable(labelTable);
        slider.setPaintLabels(true);

        frame.getContentPane().add(slider);

        frame.pack();
        frame.setVisible(true);
    }

    public void paintComponent(Graphics g)
    {
        g.drawImage(image, 0, 0, null);
    }

    public void pause(int milliseconds)
    {
        try
        {
            Thread.sleep(milliseconds);
        }
        catch(InterruptedException e)
        {
            throw new RuntimeException(e);
        }
    }

    public int[] getMouseLocation()
    {
        return mouseLoc;
    }

    public int getTool()
    {
        return tool;
    }

    public void setColor(int row, int col, Color color)
    {
        Graphics g = image.getGraphics();
        g.setColor(color);
        g.fillRect(col * cellSize, row * cellSize, cellSize, cellSize);
    }

    public void mouseClicked(MouseEvent e)
    {
    }

    public void mousePressed(MouseEvent e)
    {
        mouseLoc = toLocation(e);
    }

    public void mouseReleased(MouseEvent e)
    {
        mouseLoc = null;
    }

    public void mouseEntered(MouseEvent e)
    {
    }

    public void mouseExited(MouseEvent e)
    {
    }

    public void mouseMoved(MouseEvent e)
    {
    }

    public void mouseDragged(MouseEvent e)
    {
        mouseLoc = toLocation(e);
    }

    private int[] toLocation(MouseEvent e)
    {
        int row = e.getY() / cellSize;
        int col = e.getX() / cellSize;
        if (row < 0 || row >= numRows || col < 0 || col >= numCols)
            return null;
        int[] loc = new int[2];
        loc[0] = row;
        loc[1] = col;
        return loc;
    }

    public void actionPerformed(ActionEvent e)
    {
        tool = Integer.parseInt(e.getActionCommand());
        for (JButton button : buttons)
            button.setSelected(false);
        ((JButton)e.getSource()).setSelected(true);
    }

    public void stateChanged(ChangeEvent e)
    {
        speed = computeSpeed(slider.getValue());
    }

    //returns number of times to step between repainting and processing mouse input
    public int getSpeed()
    {
        return speed;
    }

    //returns speed based on sliderValue
    //speed of 0 returns 10^3
    //speed of 100 returns 10^6
    private int computeSpeed(int sliderValue)
    {
        return (int)Math.pow(10, 0.03 * sliderValue + 3);
    }
}


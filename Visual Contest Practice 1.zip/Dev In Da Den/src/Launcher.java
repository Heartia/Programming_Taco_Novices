import java.awt.*;
import java.util.Random;
import javax.swing.*;

public class Launcher {

    public static void main(String[] args) {
        RandomMap randomMap = new RandomScape(600, 1100, 1, "Hai Fellow Hoomans Hai");

        randomMap.genMap();
    }

}

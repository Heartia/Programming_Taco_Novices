package PokemonBattleSim;

public class Move {

    private int power;
    private int type1, type2;
    private int physOrSpec;
    public static final int PHYSICAL = 1, SPECIAL = 2;
    private int status;
    private String moveName;

    public int getPower() {
        return power;
    }

    public int getType1() {
        return type1;
    }

    public int getType2() {
        return type2;
    }

    public int getPhysOrSpec() {
        return physOrSpec;
    }

    public int getStatus() {
        return status;
    }

    public boolean isThawable() {
        if (moveName.equals("Fusion Flare") || moveName.equals("Flame Wheel") || moveName.equals("Sacred Fire") ||
        moveName.equals("Flare Blitz") || moveName.equals("Scald") || moveName.equals("Steam Eruption")) {
            return true;
        }
        return false;
    }
}

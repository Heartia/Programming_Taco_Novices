package PokemonBattleSim;

import java.util.Random;

public class Pokemon {

    private Random random = new Random();

    private int evasion, accuracy;
    private int[] nature = new int[6];
    private static final int HP = 0, ATTACK = 1, DEFENSE = 2, SP_ATK = 3,
    SP_DEF = 4, SPD = 5;
    private int[] bases = new int[6];
    private int[] ivs = new int[6];
    private int[] evs = new int[6];
    private int[] stages = new int[6];
    private int[] stats = new int[6];
    private int[] badges = new int[random.nextInt(8)];
    private int level;
    private int currentHP;
    private int status;
    private int volatileStatus;
    private int badPoisonTurns;

    public static final int OKAY = 0, PARALYSED = 1, POISONED = 2, SLEEPING = 3, FROZEN = 4, BURNT = 5, BADLYPOISONED = 6;

    private PokemonStorage storage;
    public static final int NOMRAL = 0, FIGHTING = 1, FLYING = 2, POISON = 3,
            GROUND = 4, ROCK = 5, BUG = 6, GHOST = 7, STEEL = 8, FIRE = 9,
            WATER = 10, GRASS = 11, ELECTRIC = 12, PSYCHIC = 13, ICE = 14,
            DRAGON = 15, DARK = 16, FAIRY = 17;

    private static final double[][] typeEffectiveness = new double[][]{{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, .5, 0, 1, 1, .5, 1},
            {1, .5, .5, 1, 2, 2, 1, 1, 1, 1, 1, 2, .5, 1, .5, 1, 2, 1},
            {1, 2, .5, 1, .5, 1, 1, 1, 2, 1, 1, 1, 2, 1, .5, 1, 1, 1},
            {1, 1, 2, .5, .5, 1, 1, 1, 0, 2, 1, 1, 1, 1, .5, 1, 1, 1},
            {1, .5, 2, 1, .5, 1, 1, .5, 2, .5, 1, .5, 2, 1, .5, 1, .5, 1},
            {1, .5, .5, 1, 2, .5, 1, 1, 2, 2, 1, 1, 1, 1, 2, 1, .5, 1},
            {2, 1, 1, 1, 1, 2, 1, .5, 1, .5, .5, .5, 2, 0, 2, 2, .5},
            {1, 1, 1, 1, 2, 1, 1, .5, .5, 1, 1, 1, .5, .5, 1, 1, 0, 2},
            {1, 2, 1, 2, .5, 1, 1, 2, 1, 0, 1, .5, 2, 1, 1, 1, 2, 1},
            {1, 1, 1, .5, 2, 1, 2, 1, 1, 1, 1, 2, .5, 1, 1, 1, .5, 1},
            {1, 1, 1, 1, 1, 1, 2, 2, 1, 1, .5, 1, 1, 1, 1, 0, .5, 1},
            {1, .5, 1, 1, 2, 1, .5, .5, 1, .5, 2, 1, 1, .5, 1, 2, .5, .5},
            {1, 2, 1, 1, 1, 2, .5, 1, .5, 2, 1, 2, 1, 1, 1, 1, .5, 1},
            {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, .5, 1, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, .5, 0},
            {1, 1, 1, 1, 1, 1, .5, 1, 1, 1, 2, 1, 1, 2, 1, .5, 1, .5},
            {1, .5, .5, .5, 1, 2, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, .5, 2},
            {1, .5, 1, 1, 1, 2, .5, 1, 1, 1, 1, 1, 1, 2, 2, .5, 1}};

    private static final boolean FEMALE = false, MALE = true;

    private boolean gender, shiny, ability;
    private int type1, type2;
    private String name;
    private Move[] moves;

    public Pokemon(String name, int level) {
        this.name = name;
        this.level = level;
        storage = new PokemonStorage();
        instantiate();
    }

    private void instantiate() {
        gender = random.nextBoolean();
        ability = random.nextBoolean();
        if (random.nextInt(65536) < 16) shiny = true;

        int increaseNature = random.nextInt(6);
        int decreaseNature = random.nextInt(6);

        int evTotal = 0;
        // bases = Arrays.copy(PokemonStorage.getBases());
        for (int s = 0; s < stats.length; s++) {
            ivs[s] = random.nextInt(32);
            int evAdd = random.nextInt(256);
            if (evTotal + evAdd >= 510) {
                evs[s] = (evTotal + evAdd) - 510;
            }
            else {
                evs[s] = evAdd;
                evTotal += evAdd;
            }
            if (s == HP) {
                stats[s] = (((2 * bases[s] + ivs[s] + (evs[s] / 4)) * level) / 100) + level + 10;
            }
            else {
                stats[s] = ((((2 * bases[s] + ivs[s] + (evs[s] / 4)) * level) / 100) + 5);
            }
            if (increaseNature != decreaseNature) {
                if (s == increaseNature) stats[s] *= 1.1;
                else if (s == decreaseNature) stats[s] *= 0.9;
            }
        }
        for (int i = 0; i < badges.length; i++) {
            badges[i] = random.nextInt(18) + 1;
        }
        status = volatileStatus = OKAY;
    }

    private double[] giveDamage(Move move) {
        if (status == PARALYSED) {
            if (random.nextDouble() < .25) return new double[]{0, 0, 0, 0, 0};
        }
        else if (status == FROZEN) {
            if (move.isThawable() || random.nextDouble() < .2) status = OKAY;
            else {
                return new double[]{0, 0, 0, 0, 0};
            }
        }
        else if (status == SLEEPING) {
            if (random.nextDouble() < .2) status = OKAY;
            else {
                return new double[]{0, 0, 0, 0, 0};
            }
        }

        double modifier = 1;

        for (int i = 0; i < badges.length; i++) {
            if (badges[i] == move.getType1() || badges[i] == move.getType2()) {
                modifier *= 1.25;
                break;
            }
        }

        if (stages[SPD] == 0 && random.nextInt(24) == 0) modifier *= 1.5;
        else if (stages[SPD] == 1 && random.nextInt(8) == 0) modifier *= 1.5;
        else if (stages[SPD] == 2 && random.nextBoolean()) modifier *= 1.5;
        else if (stages[SPD] >= 3) modifier *= 1.5;

        modifier *= ((random.nextDouble() / 6.67) + 0.85);

        if (move.getType1() == type1 || move.getType1() == type2 || move.getType2() == type1 || move.getType2() == type2) {
            modifier *= 2;
        }

        if (status == BURNT) modifier /= 2;

        return new double[]{(((2 * level) / 5) + 2) * move.getPower() * stats[ATTACK], modifier, move.getStatus(), move.getType1(), move.getType2()};
    }

    private void takeDamage(int[] damage) {
        status = damage[2];
        damage[0] = ((damage[0] / stats[DEFENSE]) / 50) + 2;

        damage[1] *= typeEffectiveness[damage[3]][type1];
        damage[1] *= typeEffectiveness[damage[3]][type2];
        damage[1] *= typeEffectiveness[damage[4]][type1];
        damage[1] *= typeEffectiveness[damage[4]][type2];

        if (status == FROZEN) {
            if (type1 == FIRE || type2 == FIRE) {
                status = OKAY;
            }
        }

        damage[0] *= damage[1];

        if (damage[0] < 1) {
            currentHP -= 1;
            return;
        }
        if (currentHP - damage[0] <= 0) {
            currentHP = 0;
        }
        else {
            currentHP -= damage[0];
        }
    }

    private void analyseStatus() {
        if (status == POISONED) {
            currentHP -= (1 / (double)8) * HP;
        }
        else if (status == BADLYPOISONED) {
            currentHP -= (badPoisonTurns++ / (double)16) * HP;
        }
        else if (status == BURNT) {
            currentHP -= (1 / (double)16) * HP;
        }
        if (currentHP < 0) currentHP = 0;
    }

}

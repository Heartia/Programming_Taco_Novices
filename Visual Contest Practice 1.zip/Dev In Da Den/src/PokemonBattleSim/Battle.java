package PokemonBattleSim;

public class Battle {

    final int SUN = 0, RAIN = 1, HARSHSUN = 2, SANDSTORM = 3;
    private int weather;
    Pokemon[] pokemons;

    public Battle() {
        pokemons = new Pokemon[2];
    }

    public int getWeather() {
        return weather;
    }

    public void setWeather(int weather) {
        this.weather = weather;
    }
}

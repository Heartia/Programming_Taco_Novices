package PokemonBattleSim;

public class Launcher {

}

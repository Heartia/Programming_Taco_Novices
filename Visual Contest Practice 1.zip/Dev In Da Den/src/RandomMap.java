import javax.swing.*;
import java.awt.*;
import java.util.Random;

public abstract class RandomMap extends JFrame {

    protected int[][] map;      // array representing map
    protected static int rows;   // number of rows in array
    protected static int cols;   // number of columns in array
    protected int size;  // size of graphical representation (cells)
    protected static Random random;
    protected static Canvas canvas;
    protected static Color[] colorof = {};

    public RandomMap(int rows, int cols, int cellSize, String title) {
        this.rows = rows;
        this.cols = cols;
        size = cellSize;
        map = new int[rows][cols];  // creates array
        int XDIM = cols * size;
        int YDIM = rows * size;
        random = new Random();
        canvas = new Canvas(title, XDIM, YDIM);
        canvas.wait(500);// Synch with system
        canvas.setForegroundColor(new Color(55, 120, 161));
        canvas.fillRectangle(0, 0, XDIM, YDIM);
    }

    public abstract void genMap();

    public void drawmap()
    {
        for(int i=0;i<rows;i++) {

            canvas.wait(3);  // animation delay

            for (int j = 0; j < cols; j++) {
                canvas.setForegroundColor(RandomMap.colorof[map[i][j]]);
                canvas.fillRectangle(j * size, i * size, size, size);
            }
        }
    } //drawmap

    protected static int checkMap(int[][] map, int whatToCheck) {
        int amount = 0;

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                if(map[r][c] == whatToCheck) {
                    amount++;
                }
            }
        }
        return amount;
    }

    protected static int[][] fillMap(int[][] map, int numToFill) {
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                map[r][c] = numToFill;
            }
        }
        return map;
    }

    protected static int[][] seedMapOnlyOn(int[][] map, int seed, int baseSeed, int rowMin, int rowMax, int colMin, int colMax, float probability) {
        float chance;

        for (int r = rowMin; r < rowMax; r++) {
            for (int c = colMin; c < colMax; c++) {
                chance = random.nextFloat();
                if (chance <= probability) {
                    if (map[r][c] == baseSeed) {
                        map[r][c] = seed;
                    }
                }
            }
        }

        return map;
    }

    protected static int[][] seedMapOnlyOn(int[][] map, int seed, int baseSeed, float probability) {
        float chance;

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                chance = random.nextFloat();
                if (chance <= probability) {
                    if (map[r][c] == baseSeed) {
                        map[r][c] = seed;
                    }
                }
            }
        }

        return map;
    }

    protected static int[][] seedMapAround(int[][] map, int seed, int baseSeed, int whatToSeedOn, int rowMin, int rowMax, int colMin, int colMax, float probability) {
        float chance;

        for (int r = rowMin; r < rowMax; r++) {
            for (int c = colMin; c < colMax; c++) {
                chance = random.nextFloat();
                if (chance <= probability) {
                    if (map[r][c] == baseSeed) {
                        if (r - 1 > 0 && map[r - 1][c] == whatToSeedOn) {
                            map[r - 1][c] = seed;
                        }
                        if (r + 1 < rows && map[r + 1][c] == whatToSeedOn) {
                            map[r + 1][c] = seed;
                        }
                        if (c - 1 > 0 && map[r][c - 1] == whatToSeedOn) {
                            map[r][c - 1] = seed;
                        }
                        if (c + 1 < rows && map[r][c + 1] == whatToSeedOn) {
                            map[r][c + 1] = seed;
                        }
                    }
                }
            }
        }

        return map;
    }

    protected static int[][] seedMapAround(int[][] map, int seed, int baseSeed, int whatToSeedOn, float probability) {
        float chance;

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                chance = random.nextFloat();
                if (chance <= probability) {
                    if (map[r][c] == baseSeed) {
                        if (r - 1 >= 0 && map[r - 1][c] == whatToSeedOn) {
                            map[r - 1][c] = seed;
                        }
                        if (r + 1 < rows && map[r + 1][c] == whatToSeedOn) {
                            map[r + 1][c] = seed;
                        }
                        if (c - 1 >= 0 && map[r][c - 1] == whatToSeedOn) {
                            map[r][c - 1] = seed;
                        }
                        if (c + 1 < cols && map[r][c + 1] == whatToSeedOn) {
                            map[r][c + 1] = seed;
                        }
                    }
                }
            }
        }

        return map;
    }

    protected static int[][] seedMapAwayFrom(int[][] map, int seed, int baseSeed, int seedAwayFrom, int distance, float probability) {
        float chance;

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                chance = random.nextFloat();
                if (chance <= probability) {
                    boolean canChange = true;
                    for (int x = 0; x < distance; x++) {
                        for (int y = 0; y < distance; y++) {
                            if(!((r - y > 0 && c - x > 0) && map[r - y][c - x] != seedAwayFrom)) {
                                canChange = false;
                                break;
                            }
                            if(!((r - y > 0 && c + x < cols) && map[r - y][c + x] != seedAwayFrom)) {
                                canChange = false;
                                break;
                            }
                            if(!((r + y < rows && c - x > 0) && map[r + y][c - x] != seedAwayFrom)) {
                                canChange = false;
                                break;
                            }
                            if(!((r + y < rows && c + x < cols) && map[r + y][c + x] != seedAwayFrom)) {
                                canChange = false;
                                break;
                            }
                        }
                        if(!canChange) break;
                        if(map[r][c] == baseSeed) {
                            map[r][c] = seed;
                        }
                    }
                }
            }
        }

        return map;
    }

    protected static int[][] seedMap(int[][] map, int seed, int rowMin, int rowMax, int colMin, int colMax, float probability) {
        float chance;

        for (int r = rowMin; r < rowMax; r++) {
            for (int c = colMin; c < colMax; c++) {
                chance = random.nextFloat();
                if (chance <= probability) {
                    map[r][c] = seed;
                }
            }
        }

        return map;
    }

    protected static int[][] seedMap(int[][] map, int seed, float probability) {
        float chance;

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                chance = random.nextFloat();
                if (chance <= probability) {
                    map[r][c] = seed;
                }
            }
        }

        return map;
    }

    protected static int[][] seedAndSpreadLopsided(int[][] map, int seed, int baseSeed, int potency, float seedProbability, float spreadProbability) {
        seedProbability *= Math.pow(10, -3);
        map = seedMapOnlyOn(map, seed, baseSeed, seedProbability);
        map = spreadOnlyOn(map, seed, baseSeed, potency, spreadProbability);
        return map;
    }

    protected static int[][] spreadDirectlyTo(int[][] map, int whatToSpread, int whatToGet, int startRow, int startCol, float probability) {
        float chances = random.nextFloat();
        float[][] mapPlots = new float[rows][cols];

        if(chances < probability) {
            mapPlots[startRow][startCol] = 0.2f;

        }

        return map;
    }

    protected static int[][] spreadOnlyOn(int[][] map, int whatToSpread, int baseSeed, int potency, float probability) {
        for (int p = 0; p < potency; p++) {
            float[][] mapChances = new float[rows][cols];

            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    if (map[r][c] == whatToSpread) {
                        if (r - 1 >= 0 && map[r - 1][c] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r - 1][c] += change;
                        }
                        if (r + 1 < rows && map[r + 1][c] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r + 1][c] += change;
                        }
                        if (c - 1 >= 0 && map[r][c - 1] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r][c - 1] += change;
                        }
                        if (c + 1 < cols && map[r][c + 1] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r][c + 1] += change;
                        }
                    }
                }
            }

            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    if(mapChances[r][c] >= probability) {
                        map[r][c] = whatToSpread;
                    }
                }
            }
        }

        return map;
    }

    protected static int[][] spreadSquareOnlyOn(int[][] map, int whatToSpread, int baseSeed, int potency, float probability) {
        for (int p = 0; p < potency; p++) {
            float[][] mapChances = new float[rows][cols];

            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    if (map[r][c] == whatToSpread) {
                        if (r - 1 >= 0 && map[r - 1][c] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r - 1][c] += change;
                        }
                        if (r + 1 < rows && map[r + 1][c] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r + 1][c] += change;
                        }
                        if (c - 1 >= 0 && map[r][c - 1] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r][c - 1] += change;
                        }
                        if (c + 1 < cols && map[r][c + 1] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r][c + 1] += change;
                        }

                        if (r - 1 >= 0 && c - 1 >= 0 && map[r - 1][c - 1] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r - 1][c - 1] += change;
                        }
                        if (r - 1 >= 0 && c + 1 < cols && map[r - 1][c + 1] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r - 1][c + 1] += change;
                        }
                        if (r + 1 < rows && c - 1 >= 0 && map[r + 1][c - 1] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r + 1][c - 1] += change;
                        }
                        if (r + 1 < rows && c - 1 < cols && map[r + 1][c + 1] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r + 1][c + 1] += change;
                        }
                    }
                }
            }

            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    if(mapChances[r][c] >= probability) {
                        map[r][c] = whatToSpread;
                    }
                }
            }
        }

        return map;
    }

    protected static int[][] spreadInDirectionsOnlyOn(int[][] map, int whatToSpread, int baseSeed, boolean[] directions, int potency, float probability) {
        final int UP = 0, UPRIGHT = 1, RIGHT = 2, DOWNRIGHT = 3, DOWN = 4, DOWNLEFT = 5, LEFT = 6, UPLEFT = 7;

        for (int p = 0; p < potency; p++) {
            float[][] mapChances = new float[rows][cols];

            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    if (map[r][c] == whatToSpread) {
                        if (directions[UP] && r - 1 >= 0 && map[r - 1][c] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r - 1][c] += change;
                        }
                        if (directions[DOWN] && r + 1 < rows && map[r + 1][c] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r + 1][c] += change;
                        }
                        if (directions[LEFT] && c - 1 >= 0 && map[r][c - 1] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r][c - 1] += change;
                        }
                        if (directions[RIGHT] && c + 1 < cols && map[r][c + 1] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r][c + 1] += change;
                        }

                        if (directions[UPLEFT] && r - 1 >= 0 && c - 1 >= 0 && map[r - 1][c - 1] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r - 1][c - 1] += change;
                        }
                        if (directions[UPRIGHT] && r - 1 >= 0 && c + 1 < cols && map[r - 1][c + 1] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r - 1][c + 1] += change;
                        }
                        if (directions[DOWNLEFT] && r + 1 < rows && c - 1 >= 0 && map[r + 1][c - 1] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r + 1][c - 1] += change;
                        }
                        if (directions[DOWNRIGHT] && r + 1 < rows && c + 1 < cols && map[r + 1][c + 1] == baseSeed) {
                            float change = random.nextFloat() / 4;
                            mapChances[r + 1][c + 1] += change;
                        }
                    }
                }
            }

            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    if(mapChances[r][c] >= probability) {
                        map[r][c] = whatToSpread;
                    }
                }
            }
        }

        return map;
    }

    protected static int[][] spreadInDirections(int[][] map, int whatToSpread, boolean[] directions, int potency, float probability) {
        final int UP = 0, UPRIGHT = 1, RIGHT = 2, DOWNRIGHT = 3, DOWN = 4, DOWNLEFT = 5, LEFT = 6, UPLEFT = 7;

        for (int p = 0; p < potency; p++) {
            float[][] mapChances = new float[rows][cols];

            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    if (map[r][c] == whatToSpread) {
                        if (directions[UP] && r - 1 >= 0 && map[r - 1][c] != whatToSpread) {
                            float change = random.nextFloat() / 4;
                            mapChances[r - 1][c] += change;
                        }
                        if (directions[DOWN] && r + 1 < rows && map[r + 1][c] != whatToSpread) {
                            float change = random.nextFloat() / 4;
                            mapChances[r + 1][c] += change;
                        }
                        if (directions[LEFT] && c - 1 >= 0 && map[r][c - 1] != whatToSpread) {
                            float change = random.nextFloat() / 4;
                            mapChances[r][c - 1] += change;
                        }
                        if (directions[RIGHT] && c + 1 < cols && map[r][c + 1] != whatToSpread) {
                            float change = random.nextFloat() / 4;
                            mapChances[r][c + 1] += change;
                        }

                        if (directions[UPLEFT] && r - 1 >= 0 && c - 1 >= 0 && map[r - 1][c - 1] != whatToSpread) {
                            float change = random.nextFloat() / 4;
                            mapChances[r - 1][c - 1] += change;
                        }
                        if (directions[UPRIGHT] && r - 1 >= 0 && c + 1 < cols && map[r - 1][c + 1] != whatToSpread) {
                            float change = random.nextFloat() / 4;
                            mapChances[r - 1][c + 1] += change;
                        }
                        if (directions[DOWNLEFT] && r + 1 < rows && c - 1 >= 0 && map[r + 1][c - 1] != whatToSpread) {
                            float change = random.nextFloat() / 4;
                            mapChances[r + 1][c - 1] += change;
                        }
                        if (directions[DOWNRIGHT] && r + 1 < rows && c + 1 < cols && map[r + 1][c + 1] != whatToSpread) {
                            float change = random.nextFloat() / 4;
                            mapChances[r + 1][c + 1] += change;
                        }
                    }
                }
            }

            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    if(mapChances[r][c] >= probability) {
                        map[r][c] = whatToSpread;
                    }
                }
            }
        }

        return map;
    }

    protected static int[][] spread(int[][] map, int whatToSpread, int potency, float probability) {
        for (int p = 0; p < potency; p++) {
            float[][] mapChances = new float[rows][cols];

            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    if (map[r][c] == whatToSpread) {
                        if (r - 1 >= 0 && map[r - 1][c] != whatToSpread) {
                            float change = random.nextFloat() / 4;
                            mapChances[r - 1][c] += change;
                        }
                        if (r + 1 < rows && map[r + 1][c] != whatToSpread) {
                            float change = random.nextFloat() / 4;
                            mapChances[r + 1][c] += change;
                        }
                        if (c - 1 >= 0 && map[r][c - 1] != whatToSpread) {
                            float change = random.nextFloat() / 4;
                            mapChances[r][c - 1] += change;
                        }
                        if (c + 1 < cols && map[r][c + 1] != whatToSpread) {
                            float change = random.nextFloat() / 4;
                            mapChances[r][c + 1] += change;
                        }
                    }
                }
            }

            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < cols; c++) {
                    if(mapChances[r][c] >= probability) {
                        map[r][c] = whatToSpread;
                    }
                }
            }
        }

        return map;
    }

    protected static void printMap(int[][] map, int version) {
        System.out.println("Version: " + version);
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                if (c + 1 < cols) {
                    System.out.print(map[r][c] + " ");
                }
                else {
                    System.out.print(map[r][c]);
                }
            }
            System.out.println();
        }
        System.out.println();
    }

    public int getCellSize() {
        return size;
    }

    public void setCellSize(int size) {
        this.size = size;
    }
}

package RandomGame;

public class Launcher {

    public static void main(String[] args) {
        new Game("Hey!", 1200, 675);
    }

}

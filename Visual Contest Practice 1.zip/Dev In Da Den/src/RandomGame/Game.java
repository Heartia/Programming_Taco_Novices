package RandomGame;

import java.awt.*;
import java.awt.image.BufferStrategy;

public class Game extends Canvas implements Runnable {

    private Window window;
    private Graphics g;
    private Thread thread;
    private boolean running;
    private int width, height;

    public Game(String name, int width, int height) {
        window = new Window(name, width, height);
        thread = new Thread();
        this.width = width;
        this.height = height;
    }

    public synchronized void stop() {
        try {
            thread.join();
            running = false;
        } catch(Exception e) {
            thread = new Thread(this);
            thread.start();
        }
    }

    private synchronized void tick() {
        Toolkit.getDefaultToolkit().sync();
    }

    private synchronized void render() {
        BufferStrategy bs = this.getBufferStrategy();

        if (bs == null) {
            this.createBufferStrategy(3);
            return;
        }

        Graphics g = bs.getDrawGraphics();

        window.fillBackground(new Color(0, 0, 50), g);

        Toolkit.getDefaultToolkit().sync();
    }

    @Override
    public void run() {
        this.requestFocus();

        long lastTime = System.nanoTime();
        double amountOfTicks = 60.0;
        double ns = 1000000000 / amountOfTicks;
        double delta = 0;
        long timer = System.currentTimeMillis();
        int frames = 0;
        while(running) {
            long now = System.nanoTime();
            delta += (now - lastTime) / ns;
            lastTime = now;
            while(delta >= 1) {
                tick();
                delta--;
            }
            if(running) {
                render();
            }
            frames++;

            if(System.currentTimeMillis() - timer > 1000) {
                timer += 1000;
                System.out.println("FPS: "+ frames);
                frames = 0;
            }
        }
        stop();
    }
}

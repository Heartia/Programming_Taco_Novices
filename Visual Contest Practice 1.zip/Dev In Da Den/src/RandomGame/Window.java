package RandomGame;

import javax.swing.*;
import java.awt.*;

public class Window extends Canvas {

    private JFrame frame;
    int width, height;

    public Window(String name, int width, int height) {
        frame = new JFrame(name);
        frame.setMinimumSize(new Dimension(width, height));
        frame.setMaximumSize(new Dimension(width, height));
        frame.setPreferredSize(new Dimension(width, height));
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setAlwaysOnTop(true);
        frame.pack();
        frame.setVisible(true);
        this.width = width;
        this.height = height;
    }

    public void fillBackground(Color c, Graphics g) {
        g.setColor(c);
        g.fillRect(0, 0, width, height);
    }

}

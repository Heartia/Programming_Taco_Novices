package SololearnCodes;

import java.util.Random;

public class MinecraftSimulator {

    static Random random = new Random();

    public static void main(String[] args) {
        long begin = System.currentTimeMillis();
        System.out.println("Bootleg Minecraft Java Edition\n");
        String name = random.nextBoolean() ? "Steve" : "Alex";
        double hp = 20, hunger = 20;
        while (true) {
            System.out.println(name + " | hearts: " + hp / 2 + " hunger " + hunger / 2);
            hp--;
            if (hp == 0) {
                System.out.println("HP reached 0.\nGame Over");
                break;
            }
        }
        long end = System.currentTimeMillis();
        System.out.println(end - begin);
    }

}

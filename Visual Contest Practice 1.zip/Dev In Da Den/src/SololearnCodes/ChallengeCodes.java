package SololearnCodes;

public class ChallengeCodes {

    final int val;

    {
        val = 2;
    }

    public static void main(String[] args) {
        B b = new B();
        b.say(12);
    }

}

class A {
    public void say(int number){
        System.out.print("A:"+number);
    }
}

class B extends A{

}

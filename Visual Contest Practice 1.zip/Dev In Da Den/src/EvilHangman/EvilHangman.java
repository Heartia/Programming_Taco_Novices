package EvilHangman;

/**
 * EvilHangman.java  06/04/2015
 *
 * @author - Jane Doe
 * @author - Period n
 * @author - Id nnnnnnn
 *
 * @author - I received help from ...
 *
 */

import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

public class EvilHangman
{
	private boolean debug;
	private Scanner in;
	private List<String> wordList;
	private int wordLength;
	private int remainingGuesses;
	private String solution;
	private String guessedLetters;
	private Random random;

	/**
	 * Construct an EvilHangman object.
	 * @param fileName the name of the file that contains the word list.
	 * @param debug indicates if the size of the remaining word list
	 *        should be included in the toString result.
	 * @throws FileNotFoundException when the fileName file does not exist.
	 */
   public EvilHangman(String fileName, boolean debug) throws FileNotFoundException {
		this.debug = debug;
		in = new Scanner(System.in);
		inputWords(fileName);
		System.out.println("Number of guesses? ");
		remainingGuesses = in.nextInt();
		char[] dashes = new char[wordLength];
		Arrays.fill(dashes, '-');
		solution = new String(dashes);
		guessedLetters = "";
		random = new Random();
   }

	/**
	 * Plays one the game.  The user guesses letters until either
	 * they guess the word, or they run out of guesses.
	 * Game status is printed each turn and winning / losing
	 * information is printed at the conclusion of the game.
	 */
   public void playGame() {
		while (solution.contains("-") && remainingGuesses > 0) {
			System.out.println(this);
			String letter = inputLetter().toUpperCase();
			guessedLetters += letter;
			List<Partition> partitionList = getPartitionList(letter);
			removeSmallerPartitions(partitionList);
			wordList = getWordsFromOptimalPartition(partitionList);
			String tempSolution = solution;
			substitute(wordList.get(0), letter);
			if (tempSolution.equals(solution)) {
				remainingGuesses--;
			}
		}
		if (remainingGuesses != 0) {
			System.out.println("You win, congratulations!");
		}
		else {
			System.out.println("You lose, sorry!");
		}
		System.out.println("The word was \"" + wordList.get(random.nextInt(wordList.size())) + "\"");
   }

	/**
	 * Creates and returns a status string that indicates the
	 * state of the game.
	 * @return the game status string.
	 */
   public String toString()
   {
   		if (debug) {
			return "\n" + "Remaining guesses: " + remainingGuesses +
					"\nGuessed letters: " + guessedLetters +
					"\nSolution: " + solution +
					"\nRemaining words: " + wordList.size() + "\n";
		}
   		else {
			return "\n" + "Remaining guesses: " + remainingGuesses +
					"\nGuessed letters: " + guessedLetters +
					"\nSolution: " + wordList.size() + "\n";
		}
   }


	////////// PRIVATE HELPER METHODS //////////

	/**
	 * Helper method for the constructor:
	 * Inputs the word length from the user, reads in the words from
	 * the fileName file, and initializes the wordList instance variable
	 * with the words of the correct length.  This method loops until
	 * a valid word length is entered.
	 * @param fileName the name of the file that contains the word list.
	 * @throws FileNotFoundException when the fileName file does not exist.
	 */
   private void inputWords(String fileName) throws FileNotFoundException {
		wordList = new ArrayList<>();
		while (wordList.isEmpty()) {
			System.out.print("Word length? ");
			wordLength = in.nextInt();
			Scanner file = new Scanner(new File(fileName));
			while (file.hasNext()) {
				String word = file.next();
				if (word.length() == wordLength) {
					wordList.add(word);
				}
			}
			if (wordList.isEmpty()) {
				System.out.println("There are no words with " + wordLength + " letters.");
			}
		}
   }

	/**
	 * Helper method for playGame:
	 * Inputs a one-letter string from the user.
	 * Loops until the string is a one-character character in the range
	 * a-z or A-Z.
	 * @return the single-letter string converted to upper-case.
	 */
	private String inputLetter() {
		System.out.print("Next letter? ");
		String letter = in.next();
		if (Character.isLetter(letter.charAt(0))) {
			return letter;
		}
		else {
			System.out.println("Invalid input!");
			return inputLetter();
		}
	}

	/**
	 * Helper method for getPartitionList:
	 * Uses word and letter to create a pattern.  The pattern string
	 * has the same number of letter as word.  If a character in
	 * word is the same as letter, the pattern is letter; Otherwise
	 * it's "-".
	 * @param word the word used to create the pattern
	 * @param letter the letter used to create the pattern
	 * @return the pattern
	 */
	private String getPattern(String word, String letter)
	{
		StringBuilder lettersFound = new StringBuilder();
		for (int i = 0; i < word.length(); i++) {
			if (word.charAt(i) == letter.charAt(0)) {
				lettersFound.append(letter);
			}
			else {
				lettersFound.append("-");
			}
		}
		return lettersFound.toString();
	}

	/**
	 * Helper method for playGame:
	 * Partitions each string in wordList based on their patterns.
	 * @param letter the letter used to find the pattern for
	 *        each word in wordList.
	 * @return the list of partitions.
	 */
	private List<Partition> getPartitionList(String letter)
	{
		List<Partition> partitionList = new ArrayList<>();
		for (int i = 0; i < wordList.size(); i++) {
			String pattern = getPattern(wordList.get(i), letter);
			if (i == 0) {
				partitionList.add(new Partition(pattern, wordList.get(i)));
				continue;
			}
			for (int p = 0; p < partitionList.size(); p++) {
				if (!partitionList.get(p).addIfMatches(pattern, wordList.get(i))) {
					partitionList.add(new Partition(pattern, wordList.get(i)));
				}
			}
		}
		return partitionList;
	}

	/**
	 * Helper method for playGame:
	 * Removes all but the largest (most words) partitions from partitions.
	 * @param partitions the list of partitions.
	 *        Precondition: partitions.size() > 0
	 * Postcondition: partitions
	 * 1) contains all of the partitions with the most words.
	 * 2) does not contain any of the partitions with fewer than the most words.
	 */
	private void removeSmallerPartitions(List<Partition> partitions) {
		int maxNumWords = 0;
		for (int i = 0; i < partitions.size(); i++) {
			if (partitions.get(i).getWords().size() > maxNumWords) {
				maxNumWords = partitions.get(i).getWords().size();
			}
		}
		for (int j = 0; j < partitions.size(); j++) {
			if (partitions.get(j).getWords().size() < maxNumWords) {
				partitions.remove(j);
				j--;
			}
		}
	}

	/**
	 * Helper method for playGame:
	 * Returns the words from one of the optimal partitions,
	 *    that is a partition with the most dashes in its pattern.
	 * @param partitions the list of partitions.
	 * @return the optimal partition.
	 */
	private List<String> getWordsFromOptimalPartition(List<Partition> partitions) {
		List<String> optimalWords = new ArrayList<>();
		int mostDashes = 0;
		for (int i = 0; i < partitions.size(); i++) {
			if (partitions.get(i).getPatternDashCount() > mostDashes) {
				mostDashes = partitions.get(i).getPatternDashCount();
			}
		}
		for (int i = 0; i < partitions.size(); i++) {
			if (partitions.get(i).getPatternDashCount() == mostDashes) {
				optimalWords.addAll(partitions.get(i).getWords());
			}
		}
		return optimalWords;
	}

	/**
	 * Helper method for playGame:
	 * Creates a new string for solution.  If the ith letter of
	 * found equals letter, then the ith letter of solution is
	 * changed to letter; Otherwise it is unchanged.
	 * @param found the string to check for occurrences of letter.
	 * @param letter the letter to check for in found.
	 */
	private void substitute(String found, String letter) {
		for (int i = 0; i < found.length(); i++) {
			if (found.charAt(i) == letter.charAt(0)) {
				String begin = solution.substring(0, i);
				String end = solution.substring(i + 1);
				solution = begin + letter + end;
			}
		}
	}
}

package EvilHangman;

/**
 * EvilHangmanTest.java  06/04/2015
 *
 * @author - Robert Glen Martin
 * @author - School for the Talented and Gifted
 * @author - Dallas ISD
 *
 * JUnit tests for Partition.java
 * 1) Has exactly 2 instance variables.
 * 2) All instance variables are private.
 * 3) All instance variables have the original names.
 * 4) All instance variables have the original types.
 * 5) One parameter constructor works.
 * 6) Two parameter constructor works.
 * 7) addIfMatches works when pattern matches
 * 8) addIfMatches works when pattern doesn't match
 * 9) getWords works
 * 10) getPatternDashCount works
 *
 * JUnit tests for EvilHangman.java
 *
 * 11) Has exactly 7 instance variables.
 * 12) All instance variables are private.
 * 13) All instance variables have the original names.
 * 14) All instance variables have the original types.
 * 15) Constructor works correctly (word length 7).
 * 16) Constructor works correctly (word length 3).
 * 17) Constructor works correctly (illegal initial word lengths).
 * 18) Constructor works correctly (word length 4).
 * 19) toString works correctly (debug is false).
 * 20) toString works correctly (debug is true).
 * 21) inputLetter works correctly (a -> A).
 * 22) inputLetter works correctly (Z -> Z).
 * 23) inputLetter works correctly (MM A- Z+ x -> X).
 * 24) getPattern works correctly ("QQQQQ", "Q" -> "QQQQQ").
 * 25) getPattern works correctly ("QQQQQ", "R" -> "-----").
 * 26) getPartitionList works correctly.
 * 27) removeSmallerPartitions works correctly (1 largest)
 * 28) removeSmallerPartitions works correctly (3 largest)
 * 29) getWordsFromOptimalPartition works correctly
 * 30) substitute works correctly ("----", "ABCD", "E" -> "----").
 * 31) substitute works correctly ("----", "EBED", "E" -> "E-E-").
 * 32) substitute works correctly ("E-E-", "AMCM", "M" -> "EMEM").
 * 33-36) playGame works correctly.
 */

import junit.framework.TestSuite;
import junit.framework.TestCase;
import junit.textui.TestRunner;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.PrintStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;
import java.util.Collections;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.lang.reflect.AccessibleObject;

public class EvilHangmanTest extends TestCase
{
	private static Field[] fields;
	private static Method[] methods;
	private static Partition partition;
	private static EvilHangman evil;

	private static final String[] ARGS = new String[0];
	private static final String CRLF = "" + (char)13 + (char)10;

	// "System.out.print" output is captured in arrayStream
	private static ByteArrayOutputStream arrayStream =
		new ByteArrayOutputStream();
	private static PrintStream out =
		new PrintStream(arrayStream);

	public static void main(String[] args)
	{
		System.out.println("test.txt");

		TestSuite suite = new TestSuite(EvilHangmanTest.class);
		TestRunner.run(suite);
	}


	public void test01() throws java.io.IOException
	{
		Class c = Partition.class;
		fields = c.getDeclaredFields();
		methods = c.getDeclaredMethods();

		assertEquals("*** 2 instance variables ***", 2, fields.length);
	}

	public void test02()
	{
		for (Field field : fields)
			if (! Modifier.isPrivate(field.getModifiers()))
				fail("*** All instance variables private ***");
	}

	public void test03()
	{
		assertTrue("*** instance variable names ***",
			fields[0].getName().equals("wordPattern") &&
			fields[1].getName().equals("wordList"));
	}

	public void test04()
	{
		assertTrue("*** instance variable types ***",
			fields[0].getType().getName().equals("java.lang.String") &&
			fields[1].getType().getName().equals("java.util.List"));
	}

	public void test05() throws IllegalAccessException
	{
		setInOut("");
		partition = new Partition("PaTtErN");
		List<String> expectedWords = Arrays.asList(new String[]{});
		checkPartitionPIVs(
			"One Parameter Constructor works correctly",
			"PaTtErN", 			// pattern
			expectedWords); 	// words

		String expected = "";
		String actual = arrayStream.toString();
		assertEquals("*** One Parameter Constructor works correctly" +
				" - no output ***",
			"", actual);
	}

	public void test06() throws IllegalAccessException
	{
		setInOut("");
		partition = new Partition("pAtTeRn", "TheOneWord");
		List<String> expectedWords = Arrays.asList(new String[]{"TheOneWord"});
		checkPartitionPIVs(
			"Two Parameter Constructor works correctly",
			"pAtTeRn", 			// pattern
			expectedWords); 	// words

		String expected = "";
		String actual = arrayStream.toString();
		assertEquals("*** Two Parameter Constructor works correctly" +
				" - no output ***",
			"", actual);
	}

	public void test07() throws IllegalAccessException
	{
		setInOut("");
		partition = new Partition("pAtTeRn", "TheOneWord");

		boolean result = partition.addIfMatches("pAtTeRn", "TheOtherWord");
		assertEquals("*** addIfMatches works when pattern matches" +
				" - true return ***",
			true, result);
		result = partition.addIfMatches("pAtTeRn", "TheOtherOtherWord");
		assertEquals("*** addIfMatches works when pattern matches" +
				" - true return ***",
			true, result);

		List<String> expectedWords = Arrays.asList(
			new String[]{"TheOneWord", "TheOtherWord", "TheOtherOtherWord"});
		checkPartitionPIVs(
			"addIfMatches works when pattern matches - words correct",
			"pAtTeRn", 			// pattern
			expectedWords); 	// words

		String expected = "";
		String actual = arrayStream.toString();
		assertEquals("*** addIfMatches works when pattern matches" +
				" - no output ***",
			"", actual);
	}

	public void test08() throws IllegalAccessException
	{
		setInOut("");
		partition = new Partition("pAtTeRn", "TheOneWord");

		boolean result = partition.addIfMatches("PaTtErN", "TheOtherWord");
		assertEquals("*** addIfMatches works when pattern doesn't match" +
				" - true return ***",
			false, result);
		result = partition.addIfMatches("PaTtErN", "TheOtherOtherWord");
		assertEquals("*** addIfMatches works when pattern doesn't match" +
				" - true return ***",
			false, result);

		List<String> expectedWords = Arrays.asList(
			new String[]{"TheOneWord"});
		checkPartitionPIVs(
			"addIfMatches works when pattern matches - words correct",
			"pAtTeRn", 			// pattern
			expectedWords); 	// words

		String expected = "";
		String actual = arrayStream.toString();
		assertEquals("*** addIfMatches works when pattern matches" +
				" - no output ***",
			"", actual);
	}

	public void test09() throws IllegalAccessException
	{
		setInOut("");
		partition = new Partition("pAtTeRn", "TheOneWord");

		List<String> expectedWords = Arrays.asList(
			new String[]{"TheOneWord"});
		assertEquals("*** getWords works ***",
			expectedWords.toString(), partition.getWords().toString());

		String actual = arrayStream.toString();
		assertEquals("*** getWords works - no output ***",
			"", actual);
	}

	public void test10() throws IllegalAccessException
	{
		setInOut("");
		partition = new Partition("--p-A---t-T-e-R-n--", "TheOneWord");

		assertEquals("*** getPatternDashCount works ***",
			12, partition.getPatternDashCount());

		String actual = arrayStream.toString();
		assertEquals("*** getPatternDashCount works - no output ***",
			"", actual);
	}

	public void test11() throws java.io.IOException
	{
		Class c = EvilHangman.class;
		fields = c.getDeclaredFields();
		methods = c.getDeclaredMethods();

		assertEquals("*** 7 instance variables ***", 7, fields.length);
	}

	public void test12()
	{
		for (Field field : fields)
			if (! Modifier.isPrivate(field.getModifiers()))
				fail("*** All instance variables private ***");
	}

	public void test13()
	{
		assertTrue("*** instance variable names ***",
			fields[0].getName().equals("debug") &&
			fields[1].getName().equals("in") &&
			fields[2].getName().equals("wordList") &&
			fields[3].getName().equals("wordLength") &&
			fields[4].getName().equals("remainingGuesses") &&
			fields[5].getName().equals("solution") &&
			fields[6].getName().equals("guessedLetters"));
	}

	public void test14()
	{
		assertTrue("*** instance variable types ***",
			fields[0].getType().getName().equals("boolean") &&
			fields[1].getType().getName().equals("java.util.Scanner") &&
			fields[2].getType().getName().equals("java.util.List") &&
			fields[3].getType().getName().equals("int") &&
			fields[4].getType().getName().equals("int") &&
			fields[5].getType().getName().equals("java.lang.String") &&
			fields[6].getType().getName().equals("java.lang.String"));
	}

	public void test15()
		 throws FileNotFoundException, IllegalAccessException
	{
		setInOut("7 20");
		evil = new EvilHangman("test.txt", false);
		List<String> expectedWords = Arrays.asList(new String[]{"LENGTHY"});
		checkEvilHangmanPIVs(
			"Constructor works correctly (word length 7)",
			false, 			// debug
			expectedWords, 	// words
			7, 				// wordLength
			20,				// remainingGuesses
			"-------",		// solution
			"");			// guessedLetters

		String expected = "Word length? Number of guesses? ";
		String actual = arrayStream.toString();
		actual = actual.replaceAll(CRLF, " ");
		assertEquals("*** Constructor works correctly - prompts ***",
			expected, actual);
	}

	public void test16()
		 throws FileNotFoundException, IllegalAccessException
	{
		setInOut("3 20");
		evil = new EvilHangman("test.txt", true);
		List<String> expectedWords = Arrays.asList(new String[]{
			"BET", "GOO"});

		checkEvilHangmanPIVs(
			"Constructor works correctly (word length 3)",
			true, 			// debug
			expectedWords, 	// words
			3, 				// wordLength
			20,				// remainingGuesses
			"---",			// solution
			"");			// guessedLetters

		String expected = "Word length? Number of guesses? ";
		String actual = arrayStream.toString();
		actual = actual.replaceAll(CRLF, " ");
		assertEquals("*** Constructor works correctly - prompts ***",
			expected, actual);
	}

	public void test17()
		 throws FileNotFoundException, IllegalAccessException
	{
		setInOut("0 -5 10 3 20");
		evil = new EvilHangman("test.txt", false);
		List<String> expectedWords = Arrays.asList(new String[]{
			"BET", "GOO"});

		checkEvilHangmanPIVs(
			"Constructor works correctly (illegal initial word lengths)",
			false, 			// debug
			expectedWords, 	// words
			3, 				// wordLength
			20,				// remainingGuesses
			"---",			// solution
			"");			// guessedLetters

		String expected = "Word length? There are no words with 0 letters. ";
		expected += "Word length? There are no words with -5 letters. ";
		expected += "Word length? There are no words with 10 letters. ";
		expected += "Word length? Number of guesses? ";
		String actual = arrayStream.toString();
		actual = actual.replaceAll(CRLF, " ");
		assertEquals("*** Constructor works correctly - prompts ***",
			expected, actual);
	}

	public void test18()
		 throws FileNotFoundException, IllegalAccessException
	{
		setInOut("4 10");
		evil = new EvilHangman("test.txt", false);
		List<String> expectedWords = Arrays.asList(new String[]{
			"ALLY", "BETA", "COOL", "DEAL", "ELSE", "FLEW", "GOOD",
			"HOPE", "IBEX"});

		checkEvilHangmanPIVs(
			"Constructor works correctly (word length 4)",
			false, 			// debug
			expectedWords, 	// words
			4, 				// wordLength
			10,				// remainingGuesses
			"----",			// solution
			"");			// guessedLetters

		String expected = "Word length? Number of guesses? ";
		String actual = arrayStream.toString();
		actual = actual.replaceAll(CRLF, " ");
		assertEquals("*** Constructor works correctly - prompts ***",
			expected, actual);
	}

	public void test19()
	{
		String expected = "\nRemaining guesses: 10\n";
		expected += "Guessed letters: \n";
		expected += "Solution: ----\n";
		String actual = evil.toString();
		assertEquals("*** toString works correctly (debug is false) ***",
			expected, actual);
	}

	public void test20() throws FileNotFoundException
	{
		setInOut("4 10");
		evil = new EvilHangman("test.txt", true);
		String expected = "\nRemaining guesses: 10\n";
		expected += "Guessed letters: \n";
		expected += "Solution: ----\n";
		expected += "Remaining words: 9\n";
		String actual = evil.toString();
		assertEquals("*** toString works correctly (debug is true) ***",
			expected, actual);
	}

	@SuppressWarnings("unchecked")
	public void test21() throws FileNotFoundException,
		NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		setInOut("4 10 a");
		String expected = "A";

		evil = new EvilHangman("test.txt", true);
		Class c = EvilHangman.class;
		Method method = c.getDeclaredMethod("inputLetter");
		method.setAccessible(true);
		String actual = (String)method.invoke(evil);

		assertEquals("*** inputLetter works correctly (a -> A) ***",
			expected, actual);

		expected = "Word length? Number of guesses? ";
		expected += "Next letter? ";
		actual = arrayStream.toString();
		actual = actual.replaceAll(CRLF, " ");
		assertEquals("*** Constructor works correctly - prompts ***",
			expected, actual);
	}

	@SuppressWarnings("unchecked")
	public void test22() throws FileNotFoundException,
		NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		setInOut("4 10 Z");
		String expected = "Z";

		evil = new EvilHangman("test.txt", true);
		Class c = EvilHangman.class;
		Method method = c.getDeclaredMethod("inputLetter");
		method.setAccessible(true);
		String actual = (String)method.invoke(evil);

		assertEquals("*** inputLetter works correctly (Z -> Z) ***",
			expected, actual);

		expected = "Word length? Number of guesses? ";
		expected += "Next letter? ";
		actual = arrayStream.toString();
		actual = actual.replaceAll(CRLF, " ");
		assertEquals("*** Constructor works correctly - prompts ***",
			expected, actual);
	}

	@SuppressWarnings("unchecked")
	public void test23() throws FileNotFoundException,
		NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		setInOut("4 10 MM " + (char)('A' - 1) + " " + (char)('Z' + 1) + " x");
		String expected = "X";

		evil = new EvilHangman("test.txt", true);
		Class c = EvilHangman.class;
		Method method = c.getDeclaredMethod("inputLetter");
		method.setAccessible(true);
		String actual = (String)method.invoke(evil);

		assertEquals("*** inputLetter works correctly (MM A- Z+ x -> X) ***",
			expected, actual);

		expected = "Word length? Number of guesses? ";
		expected += "Next letter? Invalid input! ";
		expected += "Next letter? Invalid input! ";
		expected += "Next letter? Invalid input! ";
		expected += "Next letter? ";
		actual = arrayStream.toString();
		actual = actual.replaceAll(CRLF, " ");

		assertEquals("*** Constructor works correctly - prompts ***",
			expected, actual);
	}

	@SuppressWarnings("unchecked")
	public void test24() throws FileNotFoundException,
		NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Class c = EvilHangman.class;
		Method method = c.getDeclaredMethod(
			"getPattern", String.class, String.class);
		method.setAccessible(true);
		String actual = (String)method.invoke(evil, "QQQQQ", "Q");
		String expected = "QQQQQ";

		assertEquals("*** getPattern works correctly " +
			"(\"QQQQQ\", \"Q\" -> \"QQQQQ\") ***",
			expected, actual);
	}

	@SuppressWarnings("unchecked")
	public void test25() throws FileNotFoundException,
		NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Class c = EvilHangman.class;
		Method method = c.getDeclaredMethod(
			"getPattern", String.class, String.class);
		method.setAccessible(true);
		String actual = (String)method.invoke(evil, "QQQQQ", "R");
		String expected = "-----";

		assertEquals("*** getPattern works correctly " +
			"(\"QQQQQ\", \"R\" -> \"-----\") ***",
			expected, actual);
	}

	@SuppressWarnings("unchecked")
	public void test26() throws FileNotFoundException,
		NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		setInOut("");
		Class c = EvilHangman.class;
		Method method = c.getDeclaredMethod(
			"getPartitionList", String.class);
		method.setAccessible(true);
		List<String> patternsE = Arrays.asList(new String[] {
			"----", "-E--", "--E-", "---E", "E--E"});

		List<List<String>> wordGroupsE = new ArrayList<List<String>>();
		wordGroupsE.add(Arrays.asList(new String[] {"ALLY", "COOL", "GOOD"}));
		wordGroupsE.add(Arrays.asList(new String[] {"BETA", "DEAL"}));
		wordGroupsE.add(Arrays.asList(new String[] {"FLEW", "IBEX"}));
		wordGroupsE.add(Arrays.asList(new String[] {"HOPE"}));
		wordGroupsE.add(Arrays.asList(new String[] {"ELSE"}));
		List<Partition> partitionsA =
			(List<Partition>)method.invoke(evil, "E");
		assertEquals("*** getPartitionList works correctly" +
				" - 5 partitions returned ***",
			patternsE.size(), partitionsA.size());

		for (int i = 0; i < patternsE.size(); i++)
		{
			String patternE = patternsE.get(i);
			boolean found = false;
			for (Partition partitionA : partitionsA)
			{
				fields = Partition.class.getDeclaredFields();
				AccessibleObject.setAccessible(fields, true);
				String wordPatternA = (String)fields[0].get(partitionA);
				if (wordPatternA.equals(patternE))
				{
					found = true;
					List<String> wordsA = partitionA.getWords();
					List<String> wordsE = wordGroupsE.get(i);
					Collections.sort(wordsA);
					if (! wordsA.equals(wordsE))
					{
						assertEquals("*** getPartitionList works correctly" +
								" - words correct for pattern ***",
							wordsE.size() + wordsE.toString(),
							wordsA.size() + wordsA.toString());
					}
				}
			}
			if (! found)
			{
				assertEquals("*** getPartitionList works correctly" +
						" - missing pattern ***",
					patternE, "");
			}
		}

		String expected = "";
		String actual = arrayStream.toString();
		assertEquals("*** getPartitionList works correctly - no output ***",
			"", actual);
	}

	@SuppressWarnings("unchecked")
	public void test27() throws FileNotFoundException,
		NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		setInOut("");
		Class c = EvilHangman.class;
		Method method1 = c.getDeclaredMethod(
			"getPartitionList", String.class);
		method1.setAccessible(true);
		Method method2 = c.getDeclaredMethod(
			"removeSmallerPartitions", java.util.List.class);
		method2.setAccessible(true);

		List<String> patternsE = Arrays.asList(new String[] {
			"----"});
		List<List<String>> wordGroupsE = new ArrayList<List<String>>();
		wordGroupsE.add(Arrays.asList(new String[] {"ALLY", "COOL", "GOOD"}));
		List<Partition> partitionsA =
			(List<Partition>)method1.invoke(evil, "E");
		method2.invoke(evil, partitionsA);
		assertEquals(
			"*** removeSmallerPartitions works correctly (1 largest)" +
				" - 1 partition returned ***",
			patternsE.size(), partitionsA.size());

		for (int i = 0; i < patternsE.size(); i++)
		{
			String patternE = patternsE.get(i);
			boolean found = false;
			for (Partition partitionA : partitionsA)
			{
				fields = Partition.class.getDeclaredFields();
				AccessibleObject.setAccessible(fields, true);
				String wordPatternA = (String)fields[0].get(partitionA);
				if (wordPatternA.equals(patternE))
				{
					found = true;
					List<String> wordsA = partitionA.getWords();
					List<String> wordsE = wordGroupsE.get(i);
					Collections.sort(wordsA);
					if (! wordsA.equals(wordsE))
					{
						assertEquals(
							"*** removeSmallerPartitions works correctly (1 largest)" +
								" - words correct for pattern ***",
							wordsE.size() + wordsE.toString(),
							wordsA.size() + wordsA.toString());
					}
				}
			}
			if (! found)
			{
				assertEquals(
					"*** removeSmallerPartitions works correctly (1 largest)" +
						" - missing pattern ***",
					patternE, "");
			}
		}

		String expected = "";
		String actual = arrayStream.toString();
		assertEquals(
			"*** removeSmallerPartitions works correctly (1 largest)" +
				" - no output ***",
			"", actual);
	}

	@SuppressWarnings("unchecked")
	public void test28() throws FileNotFoundException,
		NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		setInOut("");
		Class c = EvilHangman.class;
		Method method1 = c.getDeclaredMethod(
			"getPartitionList", String.class);
		method1.setAccessible(true);
		Method method2 = c.getDeclaredMethod(
			"removeSmallerPartitions", java.util.List.class);
		method2.setAccessible(true);

		List<String> patternsE = Arrays.asList(new String[] {
			"----", "-E--", "--E-"});

		List<List<String>> wordGroupsE = new ArrayList<List<String>>();
		wordGroupsE.add(Arrays.asList(new String[] {"ALLY", "GOOD"})); // no COOL
		wordGroupsE.add(Arrays.asList(new String[] {"BETA", "DEAL"}));
		wordGroupsE.add(Arrays.asList(new String[] {"FLEW", "IBEX"}));
		List<Partition> partitionsA =
			(List<Partition>)method1.invoke(evil, "E");
		// Find and remove COOL
		for (Partition p : partitionsA)
		{
			List<String> words = p.getWords();
			for (int i = words.size() - 1; i >= 0; i--)
			{
				String w = words.get(i);
				if (w.equals("COOL"))
					words.remove(i);
			}
		}
		method2.invoke(evil, partitionsA);
		assertEquals(
			"*** removeSmallerPartitions works correctly (3 largest)" +
				" - 3 partitions returned ***",
			patternsE.size(), partitionsA.size());

		for (int i = 0; i < patternsE.size(); i++)
		{
			String patternE = patternsE.get(i);
			boolean found = false;
			for (Partition partitionA : partitionsA)
			{
				fields = Partition.class.getDeclaredFields();
				AccessibleObject.setAccessible(fields, true);
				String wordPatternA = (String)fields[0].get(partitionA);
				if (wordPatternA.equals(patternE))
				{
					found = true;
					List<String> wordsA = partitionA.getWords();
					List<String> wordsE = wordGroupsE.get(i);
					Collections.sort(wordsA);
					if (! wordsA.equals(wordsE))
					{
						assertEquals(
							"*** removeSmallerPartitions works correctly (3 largest" +
								") - words correct for pattern ***",
							wordsE.size() + wordsE.toString(),
							wordsA.size() + wordsA.toString());
					}
				}
			}
			if (! found)
			{
				assertEquals(
					"*** removeSmallerPartitions works correctly (3 largest)" +
						" - missing pattern ***",
					patternE, "");
			}
		}

		String expected = "";
		String actual = arrayStream.toString();
		assertEquals("*** removeSmallerPartitions works correctly (3 largest)" +
				" - no output ***",
			"", actual);
	}

	@SuppressWarnings("unchecked")
	public void test29() throws FileNotFoundException,
		NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		setInOut("");
		Class c = EvilHangman.class;
		Method method1 = c.getDeclaredMethod(
			"getPartitionList", String.class);
		method1.setAccessible(true);
		Method method2 = c.getDeclaredMethod(
			"removeSmallerPartitions", java.util.List.class);
		method2.setAccessible(true);
		Method method3 = c.getDeclaredMethod(
			"getWordsFromOptimalPartition", java.util.List.class);
		method3.setAccessible(true);

		List<String> wordsE = new ArrayList<String>();
		wordsE.add("ALLY");
		wordsE.add("GOOD");

		List<Partition> partitionsA =
			(List<Partition>)method1.invoke(evil, "E");
		// Find and remove COOL
		for (Partition p : partitionsA)
		{
			List<String> words = p.getWords();
			for (int i = words.size() - 1; i >= 0; i--)
			{
				String w = words.get(i);
				if (w.equals("COOL"))
					words.remove(i);
			}
		}
		method2.invoke(evil, partitionsA);
		List<String> wordsA =
			(List<String>)method3.invoke(evil, partitionsA);
		assertEquals("*** getWordsFromOptimalPartition - correct word count ***",
			wordsE.size(), wordsA.size());
		Collections.sort(wordsA);
		assertEquals("*** getWordsFromOptimalPartition - words correct ***",
			wordsE.size() + wordsE.toString(),
			wordsA.size() + wordsA.toString());

		String expected = "";
		String actual = arrayStream.toString();
		assertEquals("*** getWordsFromOptimalPartition - no output ***",
			"", actual);
	}

	@SuppressWarnings("unchecked")
	public void test30() throws FileNotFoundException,
		NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Class c = EvilHangman.class;
		fields = c.getDeclaredFields();
		methods = c.getDeclaredMethods();
		Method method = c.getDeclaredMethod(
			"substitute", String.class, String.class);
		method.setAccessible(true);

		method.invoke(evil, "ABCD", "E");

		AccessibleObject.setAccessible(fields, true);
		String actual = (String)fields[5].get(evil);
		String expected = "----";

		assertEquals("*** substitute works correctly ***",
			expected, actual);
	}

	@SuppressWarnings("unchecked")
	public void test31() throws FileNotFoundException,
		NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Class c = EvilHangman.class;
		Method method = c.getDeclaredMethod(
			"substitute", String.class, String.class);
		method.setAccessible(true);

		method.invoke(evil, "EBED", "E");

		AccessibleObject.setAccessible(fields, true);
		String actual = (String)fields[5].get(evil);
		String expected = "E-E-";

		assertEquals("*** substitute works correctly ***",
			expected, actual);
	}

	@SuppressWarnings("unchecked")
	public void test32() throws FileNotFoundException,
		NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Class c = EvilHangman.class;
		Method method = c.getDeclaredMethod(
			"substitute", String.class, String.class);
		method.setAccessible(true);

		method.invoke(evil, "AMCM", "M");

		AccessibleObject.setAccessible(fields, true);
		String actual = (String)fields[5].get(evil);
		String expected = "EMEM";

		assertEquals("*** substitute works correctly ***",
			expected, actual);
	}

	public void test33()
		 throws FileNotFoundException, IllegalAccessException
	{
		setInOut("4 1 E");
		evil = new EvilHangman("test.txt", true);
		List<String> expectedWords = Arrays.asList(new String[]{
			"ALLY", "BETA", "COOL", "DEAL", "ELSE", "FLEW", "GOOD",
			"HOPE", "IBEX"});

		checkEvilHangmanPIVs("Game works correctly (step 0)",
			true, 			// debug
			expectedWords, 	// words
			4, 				// wordLength
			1,				// remainingGuesses
			"----",			// solution
			"");			// guessedLetters

		evil.playGame();

		expectedWords = Arrays.asList(new String[]{
			"ALLY", "COOL", "GOOD"});
		checkEvilHangmanPIVs("Game works correctly (step 1)",
			true, 			// debug
			expectedWords, 	// words
			4, 				// wordLength
			0,				// remainingGuesses
			"----",			// solution
			"E");			// guessedLetters

		String expected = "Word length? Number of guesses? ";

		expected += " Remaining guesses: 1 ";
		expected += "Guessed letters:  ";
		expected += "Solution: ---- ";
		expected += "Remaining words: 9  ";

		expected += "Next letter? ";

		expected += "You lose, sorry! ";
		expected += "The word was \"GOOD\" ";

		String actual = arrayStream.toString();
		actual = actual.replaceAll(CRLF, " ");
		actual = actual.replaceAll("\n", " ");
		actual = actual.replaceAll("ALLY", "GOOD");
		actual = actual.replaceAll("COOL", "GOOD");

		assertEquals("*** Game works correctly (step 1) - prompts ***",
			expected, actual);
	}

	public void test34()
		 throws FileNotFoundException, IllegalAccessException
	{
		setInOut("4 2 E X");
		evil = new EvilHangman("test.txt", true);
		List<String> expectedWords = Arrays.asList(new String[]{
			"ALLY", "BETA", "COOL", "DEAL", "ELSE", "FLEW", "GOOD",
			"HOPE", "IBEX"});

		checkEvilHangmanPIVs("Game works correctly (step 0)",
			true, 			// debug
			expectedWords, 	// words
			4, 				// wordLength
			2,				// remainingGuesses
			"----",			// solution
			"");			// guessedLetters

		evil.playGame();

		expectedWords = Arrays.asList(new String[]{
			"ALLY", "COOL", "GOOD"});
		checkEvilHangmanPIVs("Game works correctly (step 2)",
			true, 			// debug
			expectedWords, 	// words
			4, 				// wordLength
			0,				// remainingGuesses
			"----",			// solution
			"EX");			// guessedLetters

		String expected = "Word length? Number of guesses? ";

		expected += " Remaining guesses: 2 ";
		expected += "Guessed letters:  ";
		expected += "Solution: ---- ";
		expected += "Remaining words: 9  ";

		expected += "Next letter? ";

		expected += " Remaining guesses: 1 ";
		expected += "Guessed letters: E ";
		expected += "Solution: ---- ";
		expected += "Remaining words: 3  ";

		expected += "Next letter? ";

		expected += "You lose, sorry! ";
		expected += "The word was \"GOOD\" ";

		String actual = arrayStream.toString();
		actual = actual.replaceAll(CRLF, " ");
		actual = actual.replaceAll("\n", " ");
		actual = actual.replaceAll("ALLY", "GOOD");
		actual = actual.replaceAll("COOL", "GOOD");

		assertEquals("*** Game works correctly (step 2) - prompts ***",
			expected, actual);
	}

	public void test35()
		 throws FileNotFoundException, IllegalAccessException
	{
		setInOut("4 3 E X O D");
		evil = new EvilHangman("test.txt", true);
		List<String> expectedWords = Arrays.asList(new String[]{
			"ALLY", "BETA", "COOL", "DEAL", "ELSE", "FLEW", "GOOD",
			"HOPE", "IBEX"});

		checkEvilHangmanPIVs("Game works correctly (step 0)",
			true, 			// debug
			expectedWords, 	// words
			4, 				// wordLength
			3,				// remainingGuesses
			"----",			// solution
			"");			// guessedLetters

		evil.playGame();

		expectedWords = Arrays.asList(new String[]{"COOL"});
		checkEvilHangmanPIVs("Game works correctly (step 4)",
			true, 			// debug
			expectedWords, 	// words
			4, 				// wordLength
			0,				// remainingGuesses
			"-OO-",			// solution
			"EXOD");		// guessedLetters

		String expected = "Word length? Number of guesses? ";

		expected += " Remaining guesses: 3 ";
		expected += "Guessed letters:  ";
		expected += "Solution: ---- ";
		expected += "Remaining words: 9  ";

		expected += "Next letter? ";

		expected += " Remaining guesses: 2 ";
		expected += "Guessed letters: E ";
		expected += "Solution: ---- ";
		expected += "Remaining words: 3  ";

		expected += "Next letter? ";

		expected += " Remaining guesses: 1 ";
		expected += "Guessed letters: EX ";
		expected += "Solution: ---- ";
		expected += "Remaining words: 3  ";

		expected += "Next letter? ";

		expected += " Remaining guesses: 1 ";
		expected += "Guessed letters: EXO ";
		expected += "Solution: -OO- ";
		expected += "Remaining words: 2  ";

		expected += "Next letter? ";

		expected += "You lose, sorry! ";
		expected += "The word was \"COOL\" ";

		String actual = arrayStream.toString();
		actual = actual.replaceAll(CRLF, " ");
		actual = actual.replaceAll("\n", " ");

		assertEquals("*** Game works correctly (step 4) - prompts ***",
			expected, actual);
	}

	public void test36()
		 throws FileNotFoundException, IllegalAccessException
	{
		setInOut("4 4 E X O D L C");
		evil = new EvilHangman("test.txt", true);
		List<String> expectedWords = Arrays.asList(new String[]{
			"ALLY", "BETA", "COOL", "DEAL", "ELSE", "FLEW", "GOOD",
			"HOPE", "IBEX"});

		checkEvilHangmanPIVs("Game works correctly (step 0)",
			true, 			// debug
			expectedWords, 	// words
			4, 				// wordLength
			4,				// remainingGuesses
			"----",			// solution
			"");			// guessedLetters

		evil.playGame();

		expectedWords = Arrays.asList(new String[]{"COOL"});
		checkEvilHangmanPIVs("Game works correctly (step 6)",
			true, 			// debug
			expectedWords, 	// words
			4, 				// wordLength
			1,				// remainingGuesses
			"COOL",			// solution
			"EXODLC");		// guessedLetters

		String expected = "Word length? Number of guesses? ";

		expected += " Remaining guesses: 4 ";
		expected += "Guessed letters:  ";
		expected += "Solution: ---- ";
		expected += "Remaining words: 9  ";

		expected += "Next letter? ";

		expected += " Remaining guesses: 3 ";
		expected += "Guessed letters: E ";
		expected += "Solution: ---- ";
		expected += "Remaining words: 3  ";

		expected += "Next letter? ";

		expected += " Remaining guesses: 2 ";
		expected += "Guessed letters: EX ";
		expected += "Solution: ---- ";
		expected += "Remaining words: 3  ";

		expected += "Next letter? ";

		expected += " Remaining guesses: 2 ";
		expected += "Guessed letters: EXO ";
		expected += "Solution: -OO- ";
		expected += "Remaining words: 2  ";

		expected += "Next letter? ";

		expected += " Remaining guesses: 1 ";
		expected += "Guessed letters: EXOD ";
		expected += "Solution: -OO- ";
		expected += "Remaining words: 1  ";

		expected += "Next letter? ";

		expected += " Remaining guesses: 1 ";
		expected += "Guessed letters: EXODL ";
		expected += "Solution: -OOL ";
		expected += "Remaining words: 1  ";

		expected += "Next letter? ";

		expected += "You win, congratulations! ";
		expected += "The word was \"COOL\" ";

		String actual = arrayStream.toString();
		actual = actual.replaceAll(CRLF, " ");
		actual = actual.replaceAll("\n", " ");

		assertEquals("*** Game works correctly (step 6) - prompts ***",
			expected, actual);
	}



	@SuppressWarnings("unchecked")
	private void checkPartitionPIVs(String msg,
		String pattern, List<String> words)
		 throws IllegalAccessException
	{
		AccessibleObject.setAccessible(fields, true);

		String partPattern = (String)fields[0].get(partition);
		assertEquals("*** " + msg + "- \"pattern\" is correct ***",
			pattern, partPattern);

		List<String> partWords = (List<String>)fields[1].get(partition);
		Collections.sort(words);
		Collections.sort(partWords);
		assertEquals("*** " + msg + "- \"words\" value is correct ***",
			words.size() + words.toString(),
			partWords.size() + partWords.toString());
	}

	@SuppressWarnings("unchecked")
	private void checkEvilHangmanPIVs(String msg,
		boolean debug, List<String> words, int wordLength,
		int remainingGuesses, String solution, String guessedLetters)
		 throws IllegalAccessException
	{
		AccessibleObject.setAccessible(fields, true);

		boolean ehDebug = (Boolean)fields[0].get(evil);
		assertEquals("*** " + msg + "- \"debug\" value is correct ***",
			debug, ehDebug);

		Scanner ehIn = (Scanner)fields[1].get(evil);
		assertNotNull("*** " + msg + "- \"in\" is not null ***", ehIn);

		List<String> ehWords = (List<String>)fields[2].get(evil);
		Collections.sort(ehWords);
		assertEquals("*** " + msg + "- \"words\" value is correct ***",
			words.toString(), ehWords.toString());

		int ehWordLength = (Integer)fields[3].get(evil);
		assertEquals("*** " + msg + "- \"wordLength\" value is correct ***",
			wordLength, ehWordLength);

		int ehRemainingGuesses = (Integer)fields[4].get(evil);
		assertEquals("*** " + msg + "- \"remainingGuesses\"" +
			"value is correct ***",
			remainingGuesses, ehRemainingGuesses);


		String ehSolution = (String)fields[5].get(evil);
		assertEquals("*** " + msg + "- \"solution\" value is correct ***",
			solution, ehSolution);

		String ehGuessedLetters = (String)fields[6].get(evil);
		assertEquals("*** " + msg + "- \"guessedLetters\" value is correct ***",
			guessedLetters, ehGuessedLetters);
	}


	private static void setInOut(String input)
	{
		// Reassign the "standard" input stream
		InputStream in = new ByteArrayInputStream(input.getBytes());
		System.setIn(in);

		// Reset and Reassign the "standard" output stream.
		arrayStream.reset();
		System.setOut(out);
	}
}

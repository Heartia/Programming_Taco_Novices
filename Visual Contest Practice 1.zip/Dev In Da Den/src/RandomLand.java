import java.awt.*;
import java.util.Random;
import javax.swing.*;

public class RandomLand extends RandomMap {

    private static final int WATER = 0;
    private static final int DEEPWATER = 1;
    private static final int SHALLOWWATER = 2;
    private static final int SAND = 3;
    private static final int STONE = 4;
    private static final int MESA = 5;
    private static final int DIRT = 6;
    private static final int GRASS = 7;
    private static final int SAVANNAH = 8;
    private static final int FOREST = 9;
    private static final int MARSH = 10;
    private static final int WOODS = 11;
    private static final int ICE = 12;
    private static final int SNOW = 13;
    private static final int ABYSS = 14;
    private static final int MOUNTAINTOP = 15;
    private static final int VOLCANROCK = 16;
    private static final int LAVA = 17;
    private static final int VOID = 18;

    private static final int LIGHTSAND = 19;
    private static final int DARKSAND = 20;
    private static final int LIGHTSTONE = 21;
    private static final int DARKSTONE = 22;
    private static final int LIGHTMESA = 23;
    private static final int DARKMESA = 24;
    private static final int LIGHTDIRT = 25;
    private static final int DARKDIRT = 26;
    private static final int LIGHTGRASS = 27;
    private static final int DARKGRASS = 28;
    private static final int LIGHTSAVANNAH = 29;
    private static final int DARKSAVANNAH = 30;
    private static final int LIGHTFOREST = 31;
    private static final int DARKFOREST = 32;
    private static final int LIGHTMARSH = 33;
    private static final int DARKMARSH = 34;
    private static final int LIGHTWOODS = 35;
    private static final int DARKWOODS = 36;
    private static final int LIGHTICE = 37;
    private static final int DARKICE = 38;
    private static final int LIGHTSNOW = 39;
    private static final int DARKSNOW = 40;
    private static final int LIGHTMOUNTAINTOP = 41;
    private static final int DARKMOUNTAINTOP = 42;
    // colors that corresponds to array type:
    public static Color[] colorof = {new Color(55, 120, 161), new Color(34, 74, 99),
            new Color(82, 177, 237), new Color(255, 231, 140), new Color(199, 167, 149),
            new Color(222, 98, 95), new Color(135, 81, 54), new Color(121, 181, 79),
            new Color(159, 181, 73), new Color(37, 117, 31), new Color(41, 117, 64),
            new Color(94, 68, 24), new Color(189, 252, 245), new Color(255, 251, 252),
            new Color(48, 31, 28), new Color(255, 207, 202), new Color(127, 16, 14),
            new Color(242, 78, 32), Color.BLACK,

            new Color(255, 241, 180), new Color(228, 192, 92), new Color(208, 188, 176),
            new Color(142, 117, 106), new Color(230, 149, 143), new Color(156, 60, 57),
            new Color(175, 115, 85), new Color(59, 38, 21), new Color(146, 181, 116),
            new Color(92, 136, 60), new Color(187, 204, 115), new Color(128, 151, 28),
            new Color(47, 153, 38), new Color(9, 87, 12), new Color(54, 155, 85),
            new Color(17, 68, 33), new Color(116, 100, 35), new Color(83, 68, 34),
            new Color(209, 252, 242), new Color(137, 252, 245), new Color(255, 255, 255),
            new Color(223, 228, 255), new Color(255, 237, 237), new Color(234, 141, 138)};
    //RandomMap w = new RandomMap(80,130); //When size was 10
    //RandomMap w = new RandomMap(105,175); //When size was 6
    //RandomMap w = new RandomMap(150,250); //When size was 4
    //For size 3
    //RandomMap w = new RandomMap(600, 1000); //When size was 1

    public RandomLand(int rows, int cols, int cellSize, String title) // takes arguments size of map
    {
        super(rows, cols, cellSize, title);
    }
    /* ******************************************************** */

    @Override
    public void genMap()  {
        int version = 1;
        map = fillMap(map, SAND);
        map = seedMap(map, WATER, 0.25f);

        int waterPotency1 = random.nextInt(4) + 4;
        int sandPotency = random.nextInt(10) + 10;
        int waterPotency2 = random.nextInt(5) + 5;

        map = spread(map, WATER, waterPotency1, 0.2f);
        map = spread(map, SAND, sandPotency, 0.15f);
        map = spread(map, WATER, waterPotency2, 0.2f);


        int potency = random.nextInt(rows / 3) + (rows / 4);
        map = seedMap(map, ABYSS, 0.000025f);
        map = spreadInDirections(map, ABYSS, new boolean[]{random.nextBoolean(),
                random.nextBoolean(), random.nextBoolean(), random.nextBoolean(),
                random.nextBoolean(), random.nextBoolean(), random.nextBoolean(),
                random.nextBoolean()}, potency, 0.1f);
        for (int p = 0; p < random.nextInt(3) + 1; p++) {
            map = seedMapAround(map, ABYSS, ABYSS, WATER, 0.5f);
        }
        map = spread(map, ABYSS, WATER, 0.1f);
        map = seedMapOnlyOn(map, SAND, ABYSS, 1.0f);

        int potency2 = random.nextInt(rows / 3) + (rows / 4);
        map = seedMap(map, VOID, 0.000025f);
        map = spreadInDirections(map, VOID, new boolean[]{random.nextBoolean(),
                random.nextBoolean(), random.nextBoolean(), random.nextBoolean(),
                random.nextBoolean(), random.nextBoolean(), random.nextBoolean(),
                random.nextBoolean()}, potency2, 0.1f);
        for (int p = 0; p < random.nextInt(3) + 1; p++) {
            map = seedMapAround(map, VOID, VOID, SAND, 0.5f);
        }
        map = spread(map, VOID, SAND, 0.1f);
        map = seedMapOnlyOn(map, WATER, VOID, 1.0f);


        map = seedMapAround(map, SHALLOWWATER, SAND, WATER, 1.0f);

        printMap(map, version);
        drawmap();
        version++;

        map = seedMapOnlyOn(map, DIRT, SAND, 0.7f);
        map = spreadOnlyOn(map, DIRT, SAND,5, 0.5f);
        map = seedMapOnlyOn(map, GRASS, DIRT, 0.8f);
        map = spreadOnlyOn(map, GRASS, SAND, 2, 0.8f);
        //map = seedMapOnlyOn(map, SAVANNAH, GRASS, 0.3f);
        //map = seedMapOnlyOn(map, STONE, SAND, 0.25f);

        map = seedMapOnlyOn(map, GRASS, SAND, 0, rows - (rows / 2), 0, cols, 0.2f);
        map = seedMapOnlyOn(map, GRASS, SAND, 0, rows / 2, 0, cols, 0.2f);
        map = seedMapOnlyOn(map, GRASS, SAND, 0, rows / 3, 0, cols, 0.2f);
        map = seedMapOnlyOn(map, GRASS, SAND, 0, rows / 4, 0, cols, 1.0f);

        map = seedMapAround(map, SAND, SHALLOWWATER, GRASS, 1.0f);

        printMap(map, version);
        drawmap();
        version++;

        boolean iceAge = false;

        if(random.nextBoolean()) {
            int divisor = random.nextInt(80) + 1;
            //if(random.nextBoolean()) {
            int minimum = random.nextInt(5) + 1;
            if(divisor == 1 && minimum == 1) {
                iceAge = true;
            }
            for (int d = divisor; d >= minimum; d--) {
                map = seedMapOnlyOn(map, ICE, WATER, 0, rows / d, 0, cols, 0.05f);
                map = seedMapOnlyOn(map, ICE, SHALLOWWATER, 0, rows / d, 0, cols, 0.05f);
                map = seedMapOnlyOn(map, SNOW, GRASS, 0, rows / d, 0, cols, 0.05f);
                map = seedMapOnlyOn(map, SNOW, DIRT, 0, rows / d, 0, cols, 0.05f);
                map = seedMapOnlyOn(map, SNOW, SAND, 0, rows / d, 0, cols, 0.05f);
            }
        }

        if(iceAge) {
            map = spreadOnlyOn(map, ICE, WATER, 3, 0.1f);
            map = spreadOnlyOn(map, ICE, SHALLOWWATER, 2, 0.2f);
            map = spreadOnlyOn(map, SNOW, GRASS, 2, 0.2f);
            map = spreadOnlyOn(map, SNOW, DIRT, 2, 0.2f);
            map = spreadOnlyOn(map, SNOW, SAND, 2, 0.2f);
        }

        map = seedMapAwayFrom(map, DEEPWATER, WATER, SHALLOWWATER, 3, 1.0f);
        map = seedMapOnlyOn(map, WATER, DEEPWATER, 0.001f);
        map = spreadOnlyOn(map, WATER, DEEPWATER, 3, 0.1f);

        printMap(map, version);
        drawmap();
        version++;

        map = spreadOnlyOn(map, SAND, GRASS, random.nextInt(random.nextInt(3) + 1), 0.1f);



        map = seedAndSpreadLopsided(map, SAVANNAH, GRASS, random.nextInt(rows / (random.nextInt(4) + 2)) +
                rows / (random.nextInt(4) + 2), 0.1f, 0.1f);
        map = spreadOnlyOn(map, SAVANNAH, DIRT, 3, 0.1f);
        map = seedMapOnlyOn(map, DARKSAVANNAH, SAVANNAH, 0.1f);
        map = spreadInDirectionsOnlyOn(map, DARKSAVANNAH, SAVANNAH, new boolean[]{random.nextBoolean(), random.nextBoolean(),
                random.nextBoolean(), random.nextBoolean(), random.nextBoolean(), random.nextBoolean(), random.nextBoolean(),
                random.nextBoolean()}, 4, 0.1f);
        map = seedMapOnlyOn(map, LIGHTSAVANNAH, SAVANNAH, 0.2f);
        map = spreadInDirectionsOnlyOn(map, LIGHTSAVANNAH, SAVANNAH, new boolean[]{random.nextBoolean(), random.nextBoolean(),
                random.nextBoolean(), random.nextBoolean(), random.nextBoolean(), random.nextBoolean(), random.nextBoolean(),
                random.nextBoolean()}, 5, 0.1f);



        map = seedAndSpreadLopsided(map, FOREST, GRASS, random.nextInt(rows / (random.nextInt(3) + 2)) +
                rows / (random.nextInt(3) + 2), 0.1f, 0.1f);
        map = spreadOnlyOn(map, FOREST, SAND, 3, 0.1f);
        map = spreadOnlyOn(map, FOREST, DIRT, 3, 0.1f);

        map = seedAndSpreadLopsided(map, MARSH, FOREST, random.nextInt(rows / (random.nextInt(3) + 2)) +
                rows / (random.nextInt(3) + 2), 0.1f, 0.1f);
        map = spreadOnlyOn(map, FOREST, SAND, 3, 0.1f);
        map = spreadOnlyOn(map, FOREST, DIRT, 3, 0.1f);

        map = seedAndSpreadLopsided(map, WOODS, FOREST, random.nextInt(rows / (random.nextInt(5) + 3)) +
                rows / (random.nextInt(5) + 3), 0.1f, 0.1f);
        map = spreadOnlyOn(map, WOODS, FOREST, 3, 0.1f);
        map = spreadOnlyOn(map, WOODS, MARSH, 5, 0.1f);

        map = seedMapOnlyOn(map, LIGHTWOODS, WOODS, 0.5f);
        map = seedMapOnlyOn(map, DARKWOODS, WOODS, 0.5f);

        map = seedMapAround(map, LIGHTFOREST, SHALLOWWATER, FOREST, 1f);
        map = seedMapAwayFrom(map, DARKFOREST, FOREST, SHALLOWWATER, 3, 0.3f);
        map = seedMapOnlyOn(map, LIGHTFOREST, FOREST, 0.2f);
        //map = seedMapOnlyOn(map, DARKFOREST, FOREST, 0.2f);
        map = spreadOnlyOn(map, DARKFOREST, FOREST, 3, 0.1f);
        map = spreadOnlyOn(map, LIGHTFOREST, FOREST, 3, 0.1f);

        map = seedMapOnlyOn(map, DEEPWATER, MARSH, 0.005f);
        map = spreadOnlyOn(map, DEEPWATER, MARSH, 3, 0.1f);
        map = seedMapAround(map, LIGHTMARSH, SHALLOWWATER, MARSH, 1f);
        map = seedMapAwayFrom(map, DARKMARSH, MARSH, SHALLOWWATER, 3, 0.3f);
        map = seedMapOnlyOn(map, LIGHTMARSH, MARSH, 0.2f);
        //map = seedMapOnlyOn(map, DARKFOREST, FOREST, 0.2f);
        map = spreadOnlyOn(map, DARKMARSH, MARSH, 3, 0.1f);
        map = spreadOnlyOn(map, LIGHTMARSH, MARSH, 3, 0.1f);



        map = seedMap(map, VOLCANROCK, 0.0001f);
        map = spread(map, VOLCANROCK, 1, 0.1f);
        map = spreadOnlyOn(map, VOLCANROCK, STONE, 3, 0.1f);
        map = seedMapOnlyOn(map, LAVA, VOLCANROCK, 0.05f);



        map = spreadOnlyOn(map, GRASS, DIRT, random.nextInt(4), 0.1f);
        map = spreadOnlyOn(map, GRASS, SAND, random.nextInt(2), 0.1f);

        map = seedAndSpreadLopsided(map, ABYSS, WATER, 3, 0.3f, 0.1f);
        map = seedMapOnlyOn(map, SHALLOWWATER, ABYSS, 1f);

        map = spreadOnlyOn(map, SAND, GRASS, random.nextInt(5) + 3, 0.1f);

        map = seedAndSpreadLopsided(map, STONE, SAND, random.nextInt(rows / (random.nextInt(3) + 2)) +
                rows / (random.nextInt(3) + 2), 0.1f, 0.1f);

        map = spreadOnlyOn(map, STONE, SAND, 3, 0.1f);
        map = spreadOnlyOn(map, STONE, GRASS, 5, 0.1f);

        map = seedAndSpreadLopsided(map, MESA, STONE, random.nextInt(rows / (random.nextInt(3) + 2)) +
                rows / (random.nextInt(3) + 2), 0.1f, 0.1f);
        map = spreadOnlyOn(map, MESA, STONE, random.nextInt(3) + 1, 0.1f);
        map = spreadOnlyOn(map, MESA, SAND, random.nextInt(5) + 1, 0.1f);
        map = seedMapOnlyOn(map, DARKMESA, MESA, 0.01f);
        map = spreadOnlyOn(map, DARKMESA, MESA, random.nextInt(3) + 5, 0.1f);
        map = seedMapAwayFrom(map, LIGHTMESA, DARKMESA, MESA, 3, 0.9f);
        map = spreadOnlyOn(map, DARKMESA, MESA, random.nextInt(3) + 3, 0.1f);

        map = seedMapOnlyOn(map, MOUNTAINTOP, STONE, 0.1f);
        map = spreadOnlyOn(map, MOUNTAINTOP, STONE, random.nextInt(3) + 1, 0.1f);

        map = seedMapAround(map, LIGHTSAND, SHALLOWWATER, SAND, 1f);
        map = spreadOnlyOn(map, GRASS, SAND, 5, 0.3f);

        map = seedMapAround(map, DARKGRASS, SAND, GRASS, 1f);
        map = spreadOnlyOn(map, DARKGRASS, GRASS, checkMap(map, GRASS) / 1000, 0.1f);
        map = seedMapAwayFrom(map, LIGHTGRASS, GRASS, SAND, random.nextInt(5) + 1, 0.8f);

        map = seedAndSpreadLopsided(map, SAND, GRASS, 5, 0f, 0.1f);
        map = seedMapOnlyOn(map, DARKSAND, SAND, 0.05f);

        map = seedMapOnlyOn(map, DARKDIRT, DIRT, 0.33f);
        map = seedMapOnlyOn(map, LIGHTDIRT, DIRT, 0.5f);

        printMap(map, version);
        drawmap();  // displays map on screen
        System.out.println("MAP FINISHED! <3");
        canvas.wait(10000);
    } //genmap

    public void drawmap()
    {
        for(int i=0;i<rows;i++) {

            canvas.wait(3);  // animation delay

            for (int j = 0; j < cols; j++) {
                canvas.setForegroundColor(RandomLand.colorof[map[i][j]]);
                canvas.fillRectangle(j * size, i * size, size, size);
            }
        }
    } //drawmap

}  // randommap


import java.awt.*;
import java.util.Random;

public class RandomScape extends RandomMap {

    private static final int DARK_VIOLET = 0;
    private static final int VIOLET = 1;
    private static final int LIGHT_VIOLET = 2;

    private static final int DARK_INDIGO = 3;
    private static final int INDIGO = 4;
    private static final int LIGHT_INDIGO = 5;

    private static final int DARK_BLUE = 6;
    private static final int BLUE = 7;
    private static final int LIGHT_BLUE = 8;

    private static final int DARK_CYAN = 9;
    private static final int CYAN = 10;
    private static final int LIGHT_CYAN = 11;

    private static final int DARK_MARSH = 12;
    private static final int MARSH = 13;
    private static final int LIGHT_MARSH = 14;

    private static final int DARK_GREEN = 15;
    private static final int GREEN = 16;
    private static final int LIGHT_GREEN = 17;

    private static final int DARK_THATCH = 18;
    private static final int THATCH = 19;
    private static final int LIGHT_THATCH = 20;

    private static final int DARK_YELLOW = 21;
    private static final int YELLOW = 22;
    private static final int LIGHT_YELLOW = 23;

    private static final int DARK_TANGERINE = 24;
    private static final int TANGERINE = 25;
    private static final int LIGHT_TANGERINE = 26;

    private static final int DARK_ORANGE = 27;
    private static final int ORANGE = 28;
    private static final int LIGHT_ORANGE = 29;

    private static final int DARK_RED_ORANGE = 30;
    private static final int RED_ORANGE = 31;
    private static final int LIGHT_RED_ORANGE = 32;

    private static final int DARK_RED = 33;
    private static final int RED = 34;
    private static final int LIGHT_RED = 35;

    private static final int DARK_MULBERRY = 36;
    private static final int MULBERRY = 37;
    private static final int LIGHT_MULBERRY = 38;

    protected static Color[] colorof = new Color[]{new Color(73, 0, 89), new Color(131, 0, 157), new Color(187, 0, 230),
            new Color(50, 0, 89), new Color(88, 0, 156), new Color(135, 0, 241),
            new Color(7, 0, 89), new Color(12, 0, 158), new Color(18, 0, 232),
            new Color(0, 74, 89), new Color(0, 130, 156), new Color(0, 200, 241),
            new Color(0, 89, 65), new Color(0, 159, 116), new Color(0, 242, 177),
            new Color(0, 89, 0), new Color(0, 163, 0), new Color(0, 241, 0),
            new Color(56, 89, 0), new Color(95, 153, 0), new Color(152, 241, 0),
            new Color(89, 89, 0), new Color(168, 168, 0), new Color(241, 241, 0),
            new Color(89, 74, 0), new Color(160, 133, 0), new Color(238, 198, 0),
            new Color(89, 52, 0), new Color(167, 98, 0), new Color(235, 137, 0),
            new Color(89, 2, 0), new Color(165, 4, 0), new Color(235, 5, 0),
            new Color(89, 0, 51), new Color(150, 0, 86), new Color(242, 0, 139)};

    private static Random random;

    private static int horizonLoc = 0, perX = 0;

    public RandomScape(int rows, int cols, int cellSize, String title) {
        super(rows, cols, cellSize, title);
        random = new Random();
        horizonLoc = random.nextInt(rows / 2) + (rows / 4);
        perX = random.nextInt(cols);
    }

    @Override
    public void genMap() {
        genSky(random.nextInt(3));
        drawmap();
    }

    public void drawmap()
    {
        for(int i=0;i<rows;i++) {

            canvas.wait(3);  // animation delay

            for (int j = 0; j < cols; j++) {
                canvas.setForegroundColor(RandomScape.colorof[map[i][j]]);
                canvas.fillRectangle(j * size, i * size, size, size);
            }
        }
    } //drawmap

    private void genSky(int type) {
        final int NIGHT = 0, EVENING = 1, MORNING = 2;

        System.out.println(type);

        if (type == NIGHT) {
            map = fillMap(map, DARK_VIOLET);
            map[horizonLoc][perX] = VIOLET;
            map = spread(map, VIOLET, 250, 0.1f);
            for (int c = 0; c < cols; c++) {
                map[horizonLoc][c] = VIOLET;
            }
            map = spread(map, VIOLET, 5, 0.1f);
            // UP = 0, UPRIGHT = 1, RIGHT = 2, DOWNRIGHT = 3, DOWN = 4, DOWNLEFT = 5, LEFT = 6, UPLEFT = 7
            map = spreadInDirections(map, VIOLET, new boolean[]{false, false, true, false, false, false, true, false}, 50, 0.9f);
        }
        else if (type == EVENING) {
            map = fillMap(map, DARK_ORANGE);
            map[horizonLoc][perX] = ORANGE;
            map = spread(map, ORANGE, 250, 0.1f);
            for (int c = 0; c < cols; c++) {
                map[horizonLoc][c] = ORANGE;
            }
            map = spread(map, ORANGE, 5, 0.1f);
            map = spreadInDirections(map, VIOLET, new boolean[]{false, false, true, false, false, false, true, false}, 50, 0.9f);
        }
        else if (type == MORNING) {
            map = fillMap(map, DARK_CYAN);
            map[horizonLoc][perX] = CYAN;
            map = spread(map, CYAN, 250, 0.1f);
            for (int c = 0; c < cols; c++) {
                map[horizonLoc][c] = CYAN;
            }
            map = spread(map, CYAN, 5, 0.1f);
            map = spreadInDirections(map, VIOLET, new boolean[]{false, false, true, false, false, false, true, false}, 50, 0.9f);
        }
    }

}

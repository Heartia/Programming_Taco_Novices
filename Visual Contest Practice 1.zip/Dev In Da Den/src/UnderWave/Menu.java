package UnderWave;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Random;

import static UnderWave.Game.gameState;

public class Menu extends MouseAdapter {

    ArrayList<String> splashText;
    ArrayList<String> gameOverText;
    String text;
    Random random;
    private Game game;
    private String finalGameOverText;
    private boolean hasReset;

    private int heartHeight;
    private boolean heightTurn;

    public Menu(Game game) {
        splashText = new ArrayList<>();
        gameOverText = new ArrayList<>();
        fillSplashText();
        fillGameOverText();
        random = new Random();
        finalGameOverText = gameOverText.get(random.nextInt(gameOverText.size()));
        text = splashText.get(random.nextInt(splashText.size()));
        this.game = game;
        heartHeight = 0;
        heightTurn = false;
        hasReset = false;
    }

    public void mousePressed(MouseEvent e) {
        int mx = e.getX();
        int my = e.getY();

        // Play button
        if (gameState == Game.STATE.Menu) {
            if (hasReset) {
                hasReset = false;
            }
            if (mouseOver(mx, my, Game.getGameWidth() / 2 - 200, Game.getGameHeight() / 2 - 100, 400, 100)) {
                gameState = Game.STATE.Game;
            }

            // Help button
            if (mouseOver(mx, my, Game.getGameWidth() / 2 - 200, Game.getGameHeight() / 2 + 25, 400, 100)) {
                gameState = Game.STATE.Help;
            }

            // Quit button
            if (mouseOver(mx, my, Game.getGameWidth() / 2 - 200, Game.getGameHeight() / 2 + 150, 400, 100)) {
                System.exit(0);
            }
        }

        // Back Button for Help
        if (gameState == Game.STATE.Help) {
            if (mouseOver(mx, my, Game.getGameWidth() / 2 - 200, Game.getGameHeight() / 2 + 150, 400, 100)) {
                gameState = Game.STATE.Menu;
            }
        }

        if (gameState == Game.STATE.Over) {
            if (mouseOver(mx, my, Game.getGameWidth() / 2 - 200, Game.getGameHeight() / 2 + 150, 400, 100)) {
                gameState = Game.STATE.Menu;
                if (!hasReset) {
                    game.reset();
                    hasReset = true;
                }
            }
        }
    }

    public void mouseReleased(MouseEvent e) {

    }

    private boolean mouseOver(int mx, int my, int x, int y, int width, int height) {
        if (mx > x && mx < x + width) {
            return my > y && my < y + height;
        }
        return false;
    }

    public void tick() {
        if (heightTurn) {
            heartHeight--;
            if (heartHeight <= 0) {
                heightTurn = false;
            }
        }
        else {
            heartHeight++;
            if (heartHeight > 50) {
                heightTurn = true;
            }
        }
    }

    private void fillSplashText() {
        splashText.add("Cowabunga!");
        splashText.add("Determination.");
        splashText.add("Hmmm...???!!!");
        splashText.add("Check out Mayro!");
        splashText.add("IT'S THE CORE!");
        splashText.add("Oh no");
        splashText.add("Praise The Dog!");
        splashText.add("VVVVVV");
        splashText.add("With Knuckles!");
        splashText.add("YEEEEEEET");
    }

    private void fillGameOverText() {
        gameOverText.add("You cannot give up just yet...");
        gameOverText.add("Stay determined...");
        gameOverText.add("This is just a bad dream...");
        gameOverText.add("Wave up! It's not over...");
        gameOverText.add("You have to stay determined...");
        gameOverText.add("Please don't give up...");
        gameOverText.add("Have some determination");
        gameOverText.add("You can't quit! Stay determined!");
        gameOverText.add("Is this a kind of joke?");
        gameOverText.add("Cut it out! Wake up!");
        gameOverText.add("It's not time to leave!");
        gameOverText.add("Hold on! Gather your strength.");
        gameOverText.add("Stay determined!");
        gameOverText.add("You have to keep going.");
        gameOverText.add("Our fate rests upon you.");
        gameOverText.add("You;re going to be alright!");
        gameOverText.add("Don't lose hope!");
        gameOverText.add("It can't end now!");
        gameOverText.add("Refuse! Come back!");
        gameOverText.add("Looks like you got dunked on. Oof.");
    }

    public void render(Graphics g) {
        if (gameState == Game.STATE.Menu) {
            g.setColor(Color.WHITE);
            g.setFont(new Font("Tahoma", Font.BOLD, 100));
            g.drawString("UNDERWAVE", 250, 200);
            g.setFont(new Font("Tahoma", Font.BOLD, 50));
            g.setColor(Color.YELLOW);
            g.drawString(text, Game.getGameWidth() - 450, 75);


            g.drawRect(Game.getGameWidth() / 2 - 200, Game.getGameHeight() / 2 - 100, 400, 100);
            g.drawRect(Game.getGameWidth() / 2 - 200, Game.getGameHeight() / 2 + 25, 400, 100);
            g.drawRect(Game.getGameWidth() / 2 - 200, Game.getGameHeight() / 2 + 150, 400, 100);
            g.setColor(Color.WHITE);
            g.drawString("Play", Game.getGameWidth() / 2 - 60, Game.getGameHeight() / 2 - 40);
            g.drawString("Help", Game.getGameWidth() / 2 - 60, Game.getGameHeight() / 2 + 85);
            g.drawString("Quit", Game.getGameWidth() / 2 - 60, Game.getGameHeight() / 2 + 210);


            int pixelSize = 16;

            g.setColor(Color.RED);
            g.fillRect(600 - pixelSize, 40 + heartHeight, pixelSize, pixelSize);
            g.fillRect(600 + pixelSize, 40 + heartHeight, pixelSize, pixelSize);

            g.fillRect(600 - pixelSize, 40 + heartHeight + pixelSize, pixelSize, pixelSize);

            g.fillRect(600, 40 + heartHeight + pixelSize, pixelSize, pixelSize);
            g.fillRect(600 + pixelSize, 40 + heartHeight + pixelSize, pixelSize, pixelSize);

            g.fillRect(600, 40 + heartHeight + (2 * pixelSize), pixelSize, pixelSize);
        }
        else if (gameState == Game.STATE.Help) {
            g.setColor(Color.WHITE);
            g.setFont(new Font("Tahoma", Font.BOLD, 100));
            g.drawString("HELP", 475, 200);
            g.setFont(new Font("Tahoma", Font.BOLD, 25));

            g.drawString("Welcome to UnderWave! You see that heart up there?", 275, 240);
            g.drawString("That's the culmination of your soul! Keep it alive!", 275, 270);
            g.drawString("Make sure to avoid all attacks that approach you!", 275, 300);
            g.drawString("Blue attacks can be dodged by staying still!", 275, 360);
            g.drawString("Orange attacks can be dodged by moving a lot!", 275, 390);
            g.drawString("White attacks are pretty normal - just avoid!", 275, 420);
            g.drawString("Red attacks do a lot of damage!", 275, 450);
            g.drawString("Heal with green attacks!", 275, 480);

            g.setFont(new Font("Tahoma", Font.BOLD, 50));

            g.drawString("Back", Game.getGameWidth() / 2 - 60, Game.getGameHeight() / 2 + 210);
            g.setColor(Color.YELLOW);
            g.drawRect(Game.getGameWidth() / 2 - 200, Game.getGameHeight() / 2 + 150, 400, 100);

            int pixelSize = 16;

            g.setColor(Color.RED);
            g.fillRect(600 - pixelSize, 50, pixelSize, pixelSize);
            g.fillRect(600 + pixelSize, 50, pixelSize, pixelSize);

            g.fillRect(600 - pixelSize, 50 + pixelSize, pixelSize, pixelSize);

            g.fillRect(600, 50 + pixelSize, pixelSize, pixelSize);
            g.fillRect(600 + pixelSize, 50 + pixelSize, pixelSize, pixelSize);

            g.fillRect(600, 50 + (2 * pixelSize), pixelSize, pixelSize);
        }
        else if (gameState == Game.STATE.Over) {
            g.setColor(Color.WHITE);
            g.setFont(new Font("Tahoma", Font.BOLD, 100));
            g.drawString("GAME OVER", 300, 200);
            g.setFont(new Font("Tahoma", Font.BOLD, 25));

            g.setFont(new Font("Tahoma", Font.BOLD, 40));
            g.drawString(finalGameOverText, 350, 340);

            g.setFont(new Font("Tahoma", Font.BOLD, 50));

            g.drawString("Continue", Game.getGameWidth() / 2 - 110, Game.getGameHeight() / 2 + 210);
            g.setColor(Color.YELLOW);
            g.drawRect(Game.getGameWidth() / 2 - 200, Game.getGameHeight() / 2 + 150, 400, 100);

            int pixelSize = 16;

            g.setColor(Color.RED);
            g.fillRect(600 - (2 * pixelSize) + heartHeight, 50, pixelSize, pixelSize);
            g.fillRect(600 + heartHeight, 50, pixelSize, pixelSize);

            g.fillRect(600 - (2 * pixelSize) + heartHeight, 50 + pixelSize, pixelSize, pixelSize);

            g.fillRect(600 - pixelSize + heartHeight, 50 + pixelSize, pixelSize, pixelSize);
            g.fillRect(600 + heartHeight, 50 + pixelSize, pixelSize, pixelSize);

            g.fillRect(600 - pixelSize + heartHeight, 50 + (2 * pixelSize), pixelSize, pixelSize);
        }
    }

}
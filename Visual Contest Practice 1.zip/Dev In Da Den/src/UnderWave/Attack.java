package UnderWave;

import java.awt.*;

public abstract class Attack extends GameObject {

    public static final int BOUNCE = 0, SMART = 1;
    protected int type;
    protected GameObject player;

    public Attack(float x, float y, float velX, float velY, int pixelSize, int type, ID id, Handler handler, boolean debug) {
        super(x, y, id, handler, debug);

        this.pixelSize = pixelSize;
        this.velX = velX;
        this.velY = velY;
        this.type = type;

        if (type == Attack.SMART) {
            natVelX = velX;
            natVelY = velY;
            for (int i = 0; i < handler.objects.size(); i++) {
                if (handler.objects.get(i).getId() == ID.Player) player = handler.objects.get(i);
            }
        }
    }

    @Override
    public void tick() {
        x += velX;
        y += velY;
        if (type == Attack.BOUNCE) {
            if (x <= 0 || x >= Game.getGameWidth() - 16) {
                velX *= -1;
            }
            if (y <= 0 || y >= Game.getGameHeight() - 40) {
                velY *= -1;
            }
        }
        else if (type == Attack.SMART) {
            if (player != null) {
                float diffX = x - player.getX() - (pixelSize / 2f);
                float diffY = y - player.getY() - (pixelSize / 2f);
                float distance = (float) Math.sqrt(Math.pow(x - player.getX(), 2) + Math.pow(y - player.getY(), 2));

                velX = (float) (((-1.0 / distance) * diffX) * natVelX);
                velY = (float) (((-1.0 / distance) * diffY) * natVelY);
            }
        }

        Toolkit.getDefaultToolkit().sync();
    }

}

package UnderWave;

import java.awt.*;
import java.util.Random;

public class Opponent extends Attack {

    private int health, maxHealth;
    private int redValue, greenValue;
    private Random random;
    private String name;

    public Opponent(String name, int x, int y, int velX, int velY, int attack, int pixelSize, int type, int health, Handler handler, boolean debug) {
        super(x, y, velX, velY, pixelSize, type, ID.BasicAttack, handler, debug);
        this.attack = attack;
        this.health = health;
        maxHealth = health;
        redValue = 32;
        greenValue = 255;
        random = new Random();
        this.name = name;
        if (name.equalsIgnoreCase("Froggit")) {
            for (int i = 0; i < 3; i++) {
                handler.addObject(new BasicAttack(random.nextInt(Game.getGameWidth() - 100) + 50, random.nextInt(Game.getGameHeight() - 100) + 50,
                        5, 5, 1, 8, Attack.BOUNCE, handler, debug));
            }
        }
    }

    @Override
    public void render(Graphics g) {
        g.setColor(Color.RED);
        g.fillRect((Game.getGameWidth() / 2) - 100, 15, 200, 30);
        g.setColor(new Color(redValue, greenValue, 0));
        g.fillRect((Game.getGameWidth() / 2) - 100, 15, (int)(((double)health / maxHealth) * 200), 30);
        g.setColor(Color.WHITE);
        g.drawString(name, (Game.getGameWidth() / 2) - 150, 30);

        if (attack >= 10) {
            g.setColor(Color.red);
        }
        else {
            g.setColor(Color.white);
        }
        g.fillRect((int)x, (int)y, pixelSize, pixelSize);

        if (debug) {
            Graphics2D g2d = (Graphics2D) g;
            g.setColor(Color.GREEN);
            g2d.draw(getBounds());
        }

        Toolkit.getDefaultToolkit().sync();
    }

    @Override
    public void tick() {
        greenValue = Game.clamp(greenValue, 0, 255);
        greenValue = (int)(((double) health / maxHealth) * 255);
        health--;
        if (health == 0) {
            handler.removeObject(this);
            handler.clear();
        }
        Toolkit.getDefaultToolkit().sync();
    }

}


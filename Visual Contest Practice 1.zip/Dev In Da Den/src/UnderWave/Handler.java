package UnderWave;

import java.awt.*;
import java.util.LinkedList;

public class Handler {

    LinkedList<GameObject> objects = new LinkedList<>();

    public synchronized void tick() {
        for (int i = 0; i < objects.size(); i++) {
            GameObject tempObject = objects.get(i);

            tempObject.tick();
        }
    }

    public synchronized void render(Graphics g) {
        for (int i = 0; i < objects.size(); i++) {
            GameObject tempObject = objects.get(i);

            tempObject.render(g);
        }
    }

    public boolean addObject(GameObject object) {
        return objects.add(object);
    }

    public boolean removeObject(GameObject object) {
        return objects.remove(object);
    }

    public void clear() {
        int index = 0;
        while (objects.size() > 1) {
            if (index >= objects.size()) {
                return;
            }
            if (objects.get(index).id == ID.Player || objects.get(index).id == ID.GreenHeal) {
                index++;
                continue;
            }
            objects.remove(index);
        }
    }

}

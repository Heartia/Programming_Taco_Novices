package UnderWave;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferStrategy;
import java.util.ArrayList;
import java.util.Random;

public class Game extends Canvas implements Runnable {

    private static final long serialVersionUID = -3446954826066955554L;
    private Thread thread;
    private boolean running = false;
    private static int width, height;
    private static int rCol, gCol, bCol;
    private static boolean bColVal;
    private static boolean debug;

    private Random random;
    private Handler handler;
    private Spawner spawner;
    private Player player;
    private static HUD hud;
    private Menu menu;

    public enum STATE {
        Menu,
        Help,
        Game,
        Over
    }


    public static STATE gameState = STATE.Menu;

    public Game(String title) {
        instantiate(1000, 1000 / 16 * 9, title);
    }

    public Game(int width, String title) {
        instantiate(width, width / 16 * 9, title);
    }

    public Game(int width, int height, String title) {
        instantiate(width, height, title);
    }

    private void instantiate(int width, int height, String title) {
        debug = true;
        handler = new Handler();
        player = new Player(width / 2 - 16, height / 2 - 16, handler, debug);
        handler.addObject(player);
        menu = new Menu(this);
        this.addKeyListener(new KeyInput(handler));

        hud = new HUD(player.getMaxHealth());

        this.width = width;
        this.height = height;

        spawner = new Spawner(handler, hud, debug);

        rCol = gCol = bCol = 0;
        bColVal = true;

        new Window(width, height, title, this);
        this.addMouseListener(menu);
    }

    public synchronized void start() {
        thread = new Thread(this);
        thread.start();
        running = true;
    }

    public synchronized void stop() {
        try {
            thread.join();
            running = false;
        } catch(Exception e) {
            thread = new Thread(this);
            thread.start();
        }
    }

    private synchronized void tick() {
        if (handler != null) handler.tick();
        if (gameState == STATE.Game) {
            if (hud != null) hud.tick();
            if (spawner != null) spawner.tick();
        }
        else if (gameState == STATE.Menu || gameState == STATE.Over) {
            menu.tick();
        }

        Toolkit.getDefaultToolkit().sync();
    }

    private synchronized void render() {
        BufferStrategy bs = this.getBufferStrategy();

        if (bs == null) {
            this.createBufferStrategy(3);
            return;
        }

        Graphics g = bs.getDrawGraphics();

        if (bColVal) {
            bCol++;
            if (bCol >= 50) {
                bColVal = false;
            }
        }
        else {
            bCol--;
            if (bCol <= 1) {
                bColVal = true;
            }
        }

        g.setColor(new Color(rCol, gCol, bCol));
        g.fillRect(0, 0, width, height);

        if (gameState == STATE.Game) {
            handler.render(g);

            hud.render(g);
        }
        else if (gameState == STATE.Menu || gameState == STATE.Help || gameState == STATE.Over) {
            menu.render(g);
        }

        g.dispose();
        bs.show();

        Toolkit.getDefaultToolkit().sync();
    }

    @Override
    public void run() {
        this.requestFocus();

        long lastTime = System.nanoTime();
        double amountOfTicks = 60.0;
        double ns = 1000000000 / amountOfTicks;
        double delta = 0;
        long timer = System.currentTimeMillis();
        int frames = 0;
        while(running) {
            long now = System.nanoTime();
            delta += (now - lastTime) / ns;
            lastTime = now;
            while(delta >= 1) {
                tick();
                delta--;
            }
            if(running) {
                render();
            }
            frames++;

            if(System.currentTimeMillis() - timer > 1000) {
                timer += 1000;
                System.out.println("FPS: "+ frames);
                if (gameState == STATE.Game && debug) {
                    hud.setFrames(frames);
                }
                frames = 0;
            }
        }
        stop();
    }

    public static int clamp(int var, int min, int max) {
        if (var >= max) {
            return var = max;
        }
        else if (var <= min) {
            return var = min;
        }
        else {
            return var;
        }
    }

    public void reset() {
        handler.clear();
        player.reset();
    }

    public static int getGameWidth() {
        return width;
    }

    public static void setGameWidth(int width) {
        Game.width = width;
    }

    public static int getGameHeight() {
        return height;
    }

    public static void setGameHeight(int height) {
        Game.height = height;
    }

    public static HUD getHud() {
        return hud;
    }

    public static void setHud(HUD hud) {
        Game.hud = hud;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }
}

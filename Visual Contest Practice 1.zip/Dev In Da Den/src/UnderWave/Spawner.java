package UnderWave;

import java.util.Random;

public class Spawner {

    private Handler handler;
    private HUD hud;
    private Random random = new Random();
    private int ticks, totalticks;
    private boolean debug;

    public Spawner(Handler handler, HUD hud, boolean debug) {
        this.handler = handler;
        this.hud = hud;
        this.debug = debug;
    }

    public synchronized void tick() {
        if (Game.gameState == Game.STATE.Game) {
            totalticks++;
            if (random.nextInt(5096) == 1) {
                handler.addObject(new GreenHeal(random.nextInt(Game.getGameWidth() - 100) + 50, random.nextInt(Game.getGameHeight() - 100) + 50, 2, 2, hud.getLove() * 5,
                        32, Attack.BOUNCE, handler, debug));
            }
            if (totalticks == 1) {
                handler.addObject(new Opponent("Froggit", random.nextInt(Game.getGameWidth() - 50) + 50, random.nextInt(Game.getGameHeight() - 50) + 50,
                        1, 1, 1, 32, Attack.BOUNCE, 100 + (hud.getLove() * 1000),
                        handler, debug));
            }
            if (hud.getExp() % 123 == 0 && hud.getExp() != 0) {
                ticks++;
                if (ticks == 5) {
                    // int x, int y, int velX, int velY, int attack, Handler handler, boolean debug
                    for (int i = 0; i < (hud.getLove() / 5) + 1; i++) {
                        handler.addObject(new Opponent("Froggit", random.nextInt(Game.getGameWidth() - 50) + 50, random.nextInt(Game.getGameHeight() - 50) + 50,
                                hud.getExp() / 123, hud.getExp() / 123, hud.getExp() / 246, 32, Attack.BOUNCE, 100 + (hud.getLove() * 1000),
                                handler, debug));
                    }
                    ticks = 0;
                }
            }
        }
    }
}

package UnderWave;

import java.awt.*;

public class BasicAttack extends Attack {

    public BasicAttack(int x, int y, int velX, int velY, int attack, int pixelSize, int type, Handler handler, boolean debug) {
        super(x, y, velX, velY, pixelSize, type, ID.BasicAttack, handler, debug);
        this.attack = attack;
    }

    @Override
    public void render(Graphics g) {
        if (attack >= 10) {
            g.setColor(Color.red);
        }
        else {
            g.setColor(Color.white);
        }
        g.fillRect((int)x, (int)y, pixelSize, pixelSize);

        if (debug) {
            Graphics2D g2d = (Graphics2D) g;
            g.setColor(Color.GREEN);
            g2d.draw(getBounds());
        }

        Toolkit.getDefaultToolkit().sync();
    }

}

package UnderWave;

public enum ID {

    Player(),
    BasicAttack(),
    Trail(),
    BlueAttack(),
    OrangeAttack(),
    GreenHeal()

}

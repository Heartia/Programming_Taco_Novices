package UnderWave;

import java.awt.*;

public class Trail extends GameObject {

    private float alpha = 1;
    private Handler handler;
    private Color color;

    private float life; // Value between 0.01 - 0.1

    public Trail(int x, int y, int pixelSize, float life, Color color, Handler handler, boolean debug) {
        super(x, y, ID.Trail, handler, debug);
        this.color = color;
        this.life = life;
        this.pixelSize = pixelSize;
    }

    @Override
    public void tick() {
        if (alpha > life) {
            alpha -= (life - 0.0001f);
        }
        else {
            handler.removeObject(this);
        }
    }

    private AlphaComposite makeTransparent(float alpha) {
        int type = AlphaComposite.SRC_OVER;
        return(AlphaComposite.getInstance(type, alpha));
    }

    @Override
    public void render(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setComposite(makeTransparent(alpha));

        g.setColor(color);
        g.fillRect((int)x, (int)y, pixelSize, pixelSize);

        g2d.setComposite(makeTransparent(1));
    }
}

package UnderWave;

import java.awt.*;

public class GreenHeal extends Attack {

    public GreenHeal(int x, int y, int velX, int velY, int attack, int pixelSize, int type, Handler handler, boolean debug) {
        super(x, y, velX, velY, pixelSize, type, ID.GreenHeal, handler, debug);
        this.attack = attack;
    }

    @Override
    public synchronized void render(Graphics g) {
        g.setColor(Color.green);
        g.fillRect((int)x, (int)y, pixelSize, pixelSize);

        if (debug) {
            Graphics2D g2d = (Graphics2D) g;
            g.setColor(Color.GREEN);
            g2d.draw(getBounds());
        }

        Toolkit.getDefaultToolkit().sync();
    }

}

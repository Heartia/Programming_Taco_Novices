package UnderWave;

import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

public class Player extends GameObject {

    private int health, maxHealth, love, exp, ticks, totalTicks;
    private String name;
    private ArrayList<String> names;
    private Random random;

    public Player(int x, int y, Handler handler, boolean debug) {
        super(x, y, ID.Player, handler, debug);
        setPixelSize(8);
        natVelX = 4;
        natVelY = 4;
        maxHealth = 20;
        health = 20;
        love = 1;
        exp = 0;
        random = new Random();
        names = new ArrayList<>();
        fillNames();
        name = names.get(random.nextInt(names.size())).toUpperCase();
    }

    @Override
    public synchronized void tick() {
        Game.getHud().setName(name);

        if (health != 0) {
            x += velX;
            y += velY;
        }
        else {
            Game.gameState = Game.STATE.Over;
        }

        x = Game.clamp((int)x, 0, Game.getGameWidth() - (pixelSize * 5));
        y = Game.clamp((int)y, 0, Game.getGameHeight() - (pixelSize * 8));

        maxHealth = 20 + ((love - 1) * 4);
        health = Game.clamp(health, 0, maxHealth);
        Game.getHud().setHealth(health);
        Game.getHud().setMaxHealth(maxHealth);

        if (Game.gameState == Game.STATE.Game) {
            ticks++;
            totalTicks++;
        }
        if (ticks >= 25) {
            exp++;
            ticks = 0;
        }
        exp = Game.clamp(exp, 0, love * 248);
        if (exp >= love * 248) {
            exp = 0;
            love++;
            health += 4;
        }

        Game.getHud().setExp(exp);
        Game.getHud().setLove(love);

        collision();

        //handler.addObject(new Trail(x, y, pixelSize, 0.01f, Color.RED, handler, debug));
        Toolkit.getDefaultToolkit().sync();
    }

    private void collision() {
        for (int i = 0; i < handler.objects.size(); i++) {
            GameObject tempObject = handler.objects.get(i);

            if (tempObject.getId() == ID.BasicAttack) {
                if (getBounds().intersects(tempObject.getBounds())) {
                    health = Game.clamp(health - tempObject.getAttack(), 0, maxHealth);
                }
            }
            else if (tempObject.getId() == ID.BlueAttack && (velX > 0 || velY > 0)) {
                if (getBounds().intersects(tempObject.getBounds())) {
                    health = Game.clamp(health - tempObject.getAttack(), 0, maxHealth);
                }
            }
            else if (tempObject.getId() == ID.OrangeAttack && (velX == 0 && velY == 0)) {
                if (getBounds().intersects(tempObject.getBounds())) {
                    health = Game.clamp(health - tempObject.getAttack(), 0, maxHealth);
                }
            }
            else if (tempObject.getId() == ID.GreenHeal) {
                if (getBounds().intersects(tempObject.getBounds())) {
                    health = Game.clamp(health + tempObject.getAttack(), 0, maxHealth);
                    handler.removeObject(tempObject);
                }
            }
        }
    }

    @Override
    public void render(Graphics g) {
        g.setColor(Color.RED);
        g.fillRect((int)x, (int)y, pixelSize, pixelSize);
        g.fillRect((int)x + (2 * pixelSize), (int)y, pixelSize, pixelSize);

        g.fillRect((int)x, (int)y + pixelSize, pixelSize, pixelSize);
        if (health != 0) {

            g.fillRect((int)x + pixelSize, (int)y + pixelSize, pixelSize, pixelSize);
            g.fillRect((int)x + (2 * pixelSize), (int)y + pixelSize, pixelSize, pixelSize);

            g.fillRect((int)x + pixelSize, (int)y + (2 * pixelSize), pixelSize, pixelSize);

        }
        else {

            g.fillRect((int)x + pixelSize + 4, (int)y + pixelSize + 8, pixelSize, pixelSize);
            g.fillRect((int)x + (2 * pixelSize) + 4, (int)y + pixelSize + 8, pixelSize, pixelSize);

            g.fillRect((int)x + pixelSize + 4, (int)y + (2 * pixelSize) + 8, pixelSize, pixelSize);

        }

        if (debug) {
            Graphics2D g2d = (Graphics2D) g;
            g.setColor(Color.GREEN);
            g2d.draw(getBounds());

            g.drawString("X: " + x + " Y: " + y, 15, 15);
        }

        Toolkit.getDefaultToolkit().sync();
    }

    private void fillNames() {
        names.add("Alice");
        names.add("Andrea");
        names.add("Asgore");
        names.add("Asriel");
        names.add("Cereb");
        names.add("Chara");
        names.add("Clover");
        names.add("Doggo");
        names.add("Emma");
        names.add("Fib");
        names.add("Frisk");
        names.add("Gaster");
        names.add("Isabelle");
        names.add("Jessica");
        names.add("Jevil");
        names.add("Kid");
        names.add("Kris");
        names.add("Lancer");
        names.add("MadMew");
        names.add("Metta");
        names.add("MewMew");
        names.add("Muffet");
        names.add("Mya");
        names.add("Noelle");
        names.add("Papyru");
        names.add("Porna");
        names.add("Ralsei");
        names.add("Red");
        names.add("Sans");
        names.add("Sara");
        names.add("Shiko");
        names.add("Shreya");
        names.add("Shruti");
        names.add("Suhas");
        names.add("Susie");
        names.add("Toriel");
        names.add("Toby");
        names.add("T. Dog");
        names.add("T. Fox");
        names.add("Undyne");
        names.add("Venom");
        names.add("Venuka");
    }

    public void reset() {
        maxHealth = 20;
        health = 20;
        love = 1;
        exp = 0;
        name = names.get(random.nextInt(names.size())).toUpperCase();
        velX = 0;
        velY = 0;
    }

    public String getName() {
        return name;
    }

    @Override
    public Rectangle getBounds() {
        return new Rectangle((int)x + (pixelSize / 2), (int)y + (pixelSize / 2), pixelSize * 2, pixelSize * 2);
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getMaxHealth() {
        return maxHealth;
    }

    public void setMaxHealth(int maxHealth) {
        this.maxHealth = maxHealth;
    }
}

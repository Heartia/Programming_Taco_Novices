package UnderWave;

import java.awt.*;

public class HUD {

    private static int health, maxHealth;
    private int redValue = 255, greenValue = 255;
    private int exp = 0, love = 1;
    private int frames = -1;
    private String name = "";
    private Graphics g;

    public HUD(int health) {
        this.health = maxHealth = health;
    }

    public synchronized void tick() {
        greenValue = Game.clamp(greenValue, 0, 255);
        redValue = Game.clamp(redValue, 0, 255);
        greenValue = (int)(((double) health / maxHealth) * 255);
        redValue = (int)(((double) health / maxHealth) * 128) + 127;
    }

    public synchronized void render(Graphics g) {
        this.g = g;
        g.setColor(Color.GREEN);
        if (frames != -1) {
            g.drawString("FPS: " + frames, 15, 30);
        }
        g.setColor(Color.RED);
        g.fillRect((Game.getGameWidth() / 2) - 100, Game.getGameHeight() - 100, 200, 30);
        g.setColor(new Color(redValue, greenValue, 0));
        g.fillRect((Game.getGameWidth() / 2) - 100, Game.getGameHeight() - 100, (int)(((double)health / maxHealth) * 200), 30);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Tahoma", Font.BOLD, 20));
        g.drawString(name, (Game.getGameWidth() / 2) - 240, Game.getGameHeight() - 75);
        g.drawString("HP", (Game.getGameWidth() / 2) - 135, Game.getGameHeight() - 75);
        g.drawString(health + "/     " + maxHealth, Game.getGameWidth() / 2, Game.getGameHeight() - 110);
        g.drawString("LV " + love, 50, Game.getGameHeight() - 80);

        g.setFont(new Font("Tahoma", Font.BOLD, 15));
        g.drawString("* You have " + exp + " exp", Game.getGameWidth() - 200, 30);
    }

    public void setFrames(int frames) {
        this.frames = frames;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        HUD.health = health;
    }

    public int getMaxHealth() {
        return maxHealth;
    }

    public void setMaxHealth(int maxHealth) {
        HUD.maxHealth = maxHealth;
    }

    public int getExp() {
        return exp;
    }

    public void setExp(int exp) {
        this.exp = exp;
    }

    public int getLove() {
        return love;
    }

    public void setLove(int love) {
        this.love = love;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

public class SnowBig extends Tile {
    public SnowBig(int id) {super(Assets.bigSnow, id);}
}
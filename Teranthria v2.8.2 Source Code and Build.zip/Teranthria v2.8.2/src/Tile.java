import java.awt.*;
import java.awt.image.BufferedImage;

public class Tile {

    //STATIC STUFF HERE

    public static Tile[] tiles = new Tile[256];
    public static Tile grassTile = new GrassTile(0);
    public static Tile dirtTile = new DirtTile(1);
    public static Tile sandTile = new SandTile(2);
    public static Tile stoneTile = new StoneTile(3);
    public static Tile treeTile = new TreeTile(4);
    public static Tile waterTile = new WaterTile(5);

    /**----------------------------------------------------------------------*/

    public static Tile tree2Tile = new TileTree(10);
    public static Tile dirtwalkTile = new TileDirt(11);

    public static Tile tallgrass = new TileGrassTall(12);
    public static Tile grass = new TileGrass(13);

    public static Tile water = new TileWater(14);
    public static Tile shallowWater = new TileShallowWater(15);

    public static Tile woodbridgeup = new TileWoodBridgeUp(16);
    public static Tile woodbridgedown = new TileWoodBridgeDown(17);
    public static Tile woodbridge = new TileWoodBridge(18);

    public static Tile cliffup = new TileCliffUp(19);
    public static Tile cliffdown = new TileCliffDown(20);
    public static Tile cliffright = new TileCliffRight(21);
    public static Tile cliffleft = new TileCliffLeft(22);

    public static Tile caveOpening = new TileCaveOpening(23);

    /**----------------------------------------------------------------------*/

    public static Tile snowBrick = new SnowBrick(30);
    public static Tile openDoor = new SnowODoor(31);
    public static Tile closeDoor = new SnowCDoor(32);
    public static Tile openWindow = new SnowOWindow(33);
    public static Tile closeWindow = new SnowCWindow(34);
    public static Tile ice = new SnowIce(35);
    public static Tile snow = new Snow(36);
    public static Tile bigSnow = new SnowBig(37);
    public static Tile snowLeft = new SnowLeft(38);
    public static Tile snowRight = new SnowRight(39);

    //MA CLASS BOI

    public static final int TILEWIDTH = 64, TILEHEIGHT = 64;

    protected BufferedImage texture;
    protected final int id;

    public Tile(BufferedImage texture, int id){
        this.texture = texture;
        this.id = id;

        tiles[id] = this;
    }

    public void tick(){

    }

    public void render(Graphics g, int x, int y){
        g.drawImage(texture, x, y, TILEWIDTH, TILEHEIGHT, null);
    }

    public boolean isSolid(){
        return false;
    }

    public int getId(){
        return id;
    }

    public boolean isHurtable(){
        return false;
    }
}
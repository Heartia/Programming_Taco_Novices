import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class InfoState extends State {

    private UIManager uiManager;
    private Image splash, info1, info2, info3, info4, info5, info6, info7, info8;
    private int cStage = 0;

    public InfoState(Handler handler){
        super(handler);
        
        info1 = new ImageIcon("Resources/Textures/Info 1").getImage();
        info2 = new ImageIcon("Resources/Textures/Info 2").getImage();
        info3 = new ImageIcon("Resources/Textures/Info 3").getImage();
        info4 = new ImageIcon("Resources/Textures/Info 4").getImage();
        info5 = new ImageIcon("Resources/Textures/Info 5").getImage();
        info6 = new ImageIcon("Resources/Textures/Info 6").getImage();
        info7 = new ImageIcon("Resources/Textures/Info 7").getImage();
        info8 = new ImageIcon("Resources/Textures/Info 8").getImage();

        
        uiManager = new UIManager(handler);
        handler.getMouseManager().setUIManager(uiManager);
        uiManager.addObject(new UIImageButton(500, 600, 256, 128, Assets.MenuBtns, new ClickListener(){
            @Override
            public void onClick() {
                cStage++;
                if(cStage==9){
                handler.getMouseManager().setUIManager(null);
                State.setState(handler.getGame().gameState);}
            }
        }));
    }

    @Override
    public void tick() {
        uiManager.tick();
    }

    @Override
    public void render(Graphics g) {
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, 1280, 832);
        switch (cStage) {
            case 1:
                g.drawImage(info1, 75, 0, null);
                break;
            case 2:
                g.drawImage(info2, 75, 0, null);
                break;
            case 3:
                g.drawImage(info3, 75, 0, null);
                break;
            case 4:
                g.drawImage(info4, 75, 0, null);
                break;
            case 5:
                g.drawImage(info5, 75, 0, null);
                break;
            case 6:
                g.drawImage(info6, 75, 0, null);
                break;
            case 7:
                g.drawImage(info7, 75, 0, null);
                break;
            case 8:
                g.drawImage(info8, 75, 0, null);
                break;
            default:
                cStage = 9;
                break;
        }
        uiManager.render(g);
    }
}
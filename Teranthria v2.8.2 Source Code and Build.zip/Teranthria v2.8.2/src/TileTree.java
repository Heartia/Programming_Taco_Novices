public class TileTree extends Tile {
    public TileTree(int id) {
        super(Assets.tree2, id);
    }

    @Override
    public boolean isSolid(){
        return true;
    }
}
import java.awt.Graphics;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

public class GameState extends State {

    private Player player;
    private Stage stage1, stage2, stage3, stage4, stage5, stage6, currentStage;
    private Stage stageU, stageB, stageBL, stageL, stageBR, stageUR, stageUL, stageR, stageMain, stageNN1, stageNN2;
    //Stats Display

    private boolean isOn;

    public GameState(Handler handler){
        super(handler);
        stageB = Assets.loadStages(handler, "stageB");
        stageU = Assets.loadStages(handler, "stageU");
        stageBL = Assets.loadStages(handler, "stageBL");
        stageL = Assets.loadStages(handler, "stageL");
        stageBR = Assets.loadStages(handler, "stageBR");
        stageUR = Assets.loadStages(handler, "stageUR");
        stageUL = Assets.loadStages(handler, "stageUL");
        stageR = Assets.loadStages(handler, "stageR");

        stage1 = Assets.loadStages(handler, "stage1");
        stage2 = Assets.loadStages(handler, "stage2");
        stage3 = Assets.loadStages(handler, "stage3");
        stage4 = Assets.loadStages(handler, "stage4");
        stage5 = Assets.loadStages(handler, "stage5");
        stage6 = Assets.loadStages(handler, "stage6");

        stageMain = Assets.loadStages(handler, "stageMain");

        stageNN1 = Assets.loadStages(handler, "stageNN1");
        stageNN2 = Assets.loadStages(handler, "stageNN2");
        Random r = new Random();
        int rv = r.nextInt(16)+1;
        if(rv==1){
            currentStage = stageU;
        } else if(rv==2){
            currentStage = stageB;
        } else if(rv==3){
            currentStage = stageBL;
        } else if(rv==4){
            currentStage = stageL;
        } else if(rv==5){
            currentStage = stageBR;
        } else if(rv==6){
            currentStage = stage1;
        } else if(rv==7){
            currentStage = stage2;
        } else if(rv==8){
            currentStage = stage3;
        } else if(rv==9){
            currentStage = stage4;
        } else if(rv==10){
            currentStage = stage5;
        } else if(rv==11){
            currentStage = stage6;
        } else if(rv==12){
            currentStage = stageUR;
        } else if(rv==13){
            currentStage = stageUL;
        } else if(rv==14){
            currentStage = stageR;
        } else if(rv==15){
            currentStage = stageNN1;
        } else{
            currentStage = stageNN2;
        }
        handler.setStage(currentStage);
        //game.getCamera().move(0, 0);
    }

    @Override
    public void tick() {
        currentStage.tick();
        //game.getCamera().move(0, 1);
        /*if(handler.getStage().getEntityManager().getPlayer().getX()<=0){
            currentStage = stage6;
            if(handler.getStage().getEntityManager().getPlayer().getX()>=handler.getStage().getWidth()){
        }
        }*/
        //changeStage();
    }

    public void changeStage(){
        /*Stage oldStage = currentStage;
        if(currentStage==stageUL){
            if(handler.getStage().getEntityManager().getPlayer().getX()>=handler.getStage().getWidth()*64){
                currentStage = stageU;
                handler.getStage().getEntityManager().getEntities().clear();
            } if(handler.getStage().getEntityManager().getPlayer().getY()>=handler.getStage().getHeight()*64){
                currentStage = stageL;
                handler.getStage().getEntityManager().getEntities().clear();
            }
        } else if(currentStage==stageU){
            if(handler.getStage().getEntityManager().getPlayer().getX()<=0){
                currentStage = stageUL;
                handler.getStage().getEntityManager().getEntities().clear();
            } if(handler.getStage().getEntityManager().getPlayer().getX()>=handler.getStage().getWidth()*64){
                currentStage = stageUR;
                handler.getStage().getEntityManager().getEntities().clear();
            }
        } else if(currentStage==stageUR){
            if(handler.getStage().getEntityManager().getPlayer().getX()<=0){
                currentStage = stageU;
                handler.getStage().getEntityManager().getEntities().clear();
            } if(handler.getStage().getEntityManager().getPlayer().getY()>=handler.getStage().getHeight()*64){
                currentStage = stageR;
                handler.getStage().getEntityManager().getEntities().clear();
            }
        } else if(currentStage==stageR){
            if(handler.getStage().getEntityManager().getPlayer().getY()<=0){
                currentStage = stageUR;
                handler.getStage().getEntityManager().getEntities().clear();
            } if(handler.getStage().getEntityManager().getPlayer().getY()>=handler.getStage().getHeight()*64){
                currentStage = stageBR;
                handler.getStage().getEntityManager().getEntities().clear();
            }
        } else if(currentStage==stageBR){
            if(handler.getStage().getEntityManager().getPlayer().getY()<=0){
                currentStage = stageR;
                handler.getStage().getEntityManager().getEntities().clear();
            } if(handler.getStage().getEntityManager().getPlayer().getX()<=0){
                currentStage = stageB;
                handler.getStage().getEntityManager().getEntities().clear();
            }
        } else if(currentStage==stageB){
            if(handler.getStage().getEntityManager().getPlayer().getX()>=handler.getStage().getWidth()*62+16){
                currentStage = stageBR;
                handler.getStage().getEntityManager().getEntities().clear();
            } if(handler.getStage().getEntityManager().getPlayer().getX()<=0){
                currentStage = stageBL;
                handler.getStage().getEntityManager().getEntities().clear();
            }
        } else if(currentStage==stageBL){
            if(handler.getStage().getEntityManager().getPlayer().getX()>=handler.getStage().getWidth()*64){
                currentStage = stageB;
                handler.getStage().getEntityManager().getEntities().clear();
            } if(handler.getStage().getEntityManager().getPlayer().getY()<=0){
                currentStage = stageL;
                handler.getStage().getEntityManager().getEntities().clear();
            }
        } else if(currentStage==stageL){
            if(handler.getStage().getEntityManager().getPlayer().getY()>=handler.getStage().getHeight()*64){
                currentStage = stageBL;
                handler.getStage().getEntityManager().getEntities().clear();
            } if(handler.getStage().getEntityManager().getPlayer().getY()<=0){
                currentStage = stageUL;
                handler.getStage().getEntityManager().getEntities().clear();
            }
        }

        if (currentStage != oldStage)
            System.out.println(currentStage.getStageString());*/
    }

    @Override
    public void render(Graphics g) {
        currentStage.render(g);
    }

    public Player getPlayer(){
        return player;
    }

    public boolean isOn() {
        return isOn;
    }

    public void setOn(boolean on) {
        isOn = on;
    }
}
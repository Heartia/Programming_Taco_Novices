public class TileDirt extends Tile {
    public TileDirt(int id) {
        super(Assets.dirt2, id);
    }
}
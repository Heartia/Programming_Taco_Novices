public class Launcher {

    public static void main(String[] args){
        Game game = new Game("Teranthria", 1280, 832);
        game.start();
    }
}
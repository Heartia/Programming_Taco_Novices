public class SnowCWindow extends Tile {
    public SnowCWindow(int id) {super(Assets.closeWindow, id);}

    @Override
    public boolean isSolid() {return true;}
}
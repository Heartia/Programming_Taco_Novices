public class TileWoodBridgeDown extends Tile {
    public TileWoodBridgeDown(int id) {
        super(Assets.woodbridgedown, id);
    }

    @Override
    public boolean isSolid(){
        return true;
    }
}
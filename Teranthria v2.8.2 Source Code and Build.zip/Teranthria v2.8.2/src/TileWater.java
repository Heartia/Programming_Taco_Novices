public class TileWater extends Tile {
    public TileWater(int id) {
        super(Assets.water2, id);
    }

    @Override
    public boolean isSolid(){
        return true;
    }
}
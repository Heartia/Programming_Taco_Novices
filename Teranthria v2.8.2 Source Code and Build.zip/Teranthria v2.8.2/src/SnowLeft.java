public class SnowLeft extends Tile {
    public SnowLeft(int id) {super(Assets.snowLeft, id);}

    @Override
    public boolean isSolid() {
        return true;
    }
}
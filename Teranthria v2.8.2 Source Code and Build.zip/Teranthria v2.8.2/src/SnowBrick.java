public class SnowBrick extends Tile {
    public SnowBrick(int id) {super(Assets.brick, id);}

    @Override
    public boolean isSolid() {return true;}
}
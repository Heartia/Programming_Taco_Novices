public class SnowODoor extends Tile {
    public SnowODoor(int id) {super(Assets.openDoor, id);}
}
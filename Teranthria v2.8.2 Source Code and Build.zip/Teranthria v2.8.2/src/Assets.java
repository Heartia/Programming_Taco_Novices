import java.awt.*;
import java.awt.image.BufferedImage;

public class Assets {

    private static final int width = 16, height = 16;
    private static final int pwidth = 417, pheight = 417;
    private static final int bwidth = 384, bheight = 280;
    private static final int ewidth = 540, eheight = 540;
    private static final int gwidth = 312, gheight = 312;
    private static final int hwidth = 500, hheight = 125;
    private static final int widhei = 24;
    private static final int pwidhei = 625;
    private static final int iwidhei = 833;
    private static final int twidhei = 32;

    public static Font font56;

    public static BufferedImage dirt, grass, stone, tree, sand, water, rocks /**player*/;
    public static BufferedImage wood, pebbles, gems, heart;
    public static BufferedImage[] player_down, player_up, player_left, player_right, player_attack, player_bow;
    public static BufferedImage[] MenuBtns, goldCoins, HPhearts;
    public static BufferedImage[] Fly_S, Ant_S, Bee_S, Beetle_S, Mosquito_S, Ladybird_S;
    public static BufferedImage[] FlyBoss_S, AntBoss_S, BeeBoss_S, BeetleBoss_S, MosquitoBoss_S, LadybirdBoss_S;
    public static BufferedImage inventoryScreen, gameOverScreen, punchIcon, potionIcon, bowIcon, gamePause;
    public static BufferedImage snow, bigSnow, snowLeft, snowRight, ice, brick, openDoor, closeDoor, openWindow, closeWindow;

    private static Stage stage1, stage2, stage3, stage4, stage5, stage6, currentStage;

    private static Stage stageU, stageB, stageBL, stageL, stageBR, stageUR, stageUL, stageR, stageMain, stageNN1, stageNN2;

    public static BufferedImage tree2, dirt2, tallgrass, grass2, water2, woodbridge, woodbridgeup, woodbridgedown, shallowwater, cliffup, cliffright, cliffdown, cliffleft, caveopening, force;

    public static Animation goldC;

    public static void init(){
        font56 = FontLoader.loadFont("Resources/Fonts/Abandon Alphabeta.zip", 56);

        SpriteSheet tiles = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Basic Tiles.png"));
        SpriteSheet enemies = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Enemy Spritesheet.png"));
        SpriteSheet players = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Player Animations.png"));
        SpriteSheet MenuButs = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Button Spritesheet.png"));
        SpriteSheet ForestTown = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Town Forest.png"));
        SpriteSheet Desert = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Desert.png"));
        SpriteSheet GameOver = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Game Over Screen Beta.png"));

        SpriteSheet Ants = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Ant spritesheet.png"));
        SpriteSheet Bees = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Bee spritesheet.png"));
        SpriteSheet Ladybirds = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Ladybird spritesheet.png"));
        SpriteSheet Beetles = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Beetle spritesheet.png"));
        SpriteSheet Flies = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Fly spritesheet.png"));
        SpriteSheet Mosquitoes = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Mosquito spritesheet.png"));

        SpriteSheet GoldCoins = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Gold Coin Sprites.png"));
        SpriteSheet Heartia = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Pixel heart.png"));
        SpriteSheet HP = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Heart Sprites.png"));

        SpriteSheet PBowNArrow = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Arrow Sprites.png"));

        SpriteSheet Field = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Minish Cap Field Sprites.png"));

        SpriteSheet TopInven = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Inventory Icons.png"));

        SpriteSheet Force = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Gemstone Force.png"));
        inventoryScreen = ImageLoader.loadImage("Resources/Textures/Inventory 1.png");
        gamePause = ImageLoader.loadImage("Resources/Textures/Game Pause.png");

        SpriteSheet SnowTown = new SpriteSheet(ImageLoader.loadImage("Resources/Textures/Snow Town.png"));

        wood = ForestTown.crop(width*4, height*12, width*2, height*2);
        pebbles = tiles.crop(width*4, height*8, width, height);
        gems = tiles.crop(width*5, height*8, width, height);
        heart = Heartia.crop(0, 0, 1024, 1024);
        force = Force.crop(100, 0, 760, 720);

        punchIcon = TopInven.crop(iwidhei, 0, iwidhei, iwidhei);
        bowIcon = TopInven.crop(0, 0, iwidhei, iwidhei);
        potionIcon = TopInven.crop(iwidhei*2, 0, iwidhei, iwidhei);

        gameOverScreen = GameOver.crop(0, 0, 1280, 832);

        HPhearts = new BufferedImage[20];
        HPhearts[0] = HP.crop(0, 0, hwidth, hheight);
        HPhearts[1] = HP.crop(0, hheight, hwidth, hheight);
        HPhearts[2] = HP.crop(0, hheight*2, hwidth, hheight);
        HPhearts[3] = HP.crop(0, hheight*3, hwidth, hheight);
        HPhearts[4] = HP.crop(hwidth, 0, hwidth, hheight);
        HPhearts[5] = HP.crop(hwidth, hheight, hwidth, hheight);
        HPhearts[6] = HP.crop(hwidth, hheight*2, hwidth, hheight);
        HPhearts[7] = HP.crop(hwidth, hheight*3, hwidth, hheight);
        HPhearts[8] = HP.crop(hwidth*2, 0, hwidth, hheight);
        HPhearts[9] = HP.crop(hwidth*2, hheight, hwidth, hheight);
        HPhearts[10] = HP.crop(hwidth*2, hheight*2, hwidth, hheight);
        HPhearts[11] = HP.crop(hwidth*2, hheight*3, hwidth, hheight);
        HPhearts[12] = HP.crop(hwidth*3, 0, hwidth, hheight);
        HPhearts[13] = HP.crop(hwidth*3, hheight, hwidth, hheight);
        HPhearts[14] = HP.crop(hwidth*3, hheight*2, hwidth, hheight);
        HPhearts[15] = HP.crop(hwidth*3, hheight*3, hwidth, hheight);
        HPhearts[16] = HP.crop(hwidth*4, 0, hwidth, hheight);
        HPhearts[17] = HP.crop(hwidth*4, hheight, hwidth, hheight);
        HPhearts[18] = HP.crop(hwidth*4, hheight*2, hwidth, hheight);
        HPhearts[19] = HP.crop(hwidth*4, hheight*3, hwidth, hheight);

        goldCoins = new BufferedImage[8];
        goldCoins[0] = GoldCoins.crop(0, 0, gwidth, gheight);
        goldCoins[1] = GoldCoins.crop(gwidth, 0, gwidth, gheight);
        goldCoins[2] = GoldCoins.crop(gwidth*2, 0, gwidth, gheight);
        goldCoins[3] = GoldCoins.crop(gwidth*3, 0, gwidth, gheight);
        goldCoins[4] = GoldCoins.crop(gwidth*4, 0, gwidth, gheight);
        goldCoins[5] = GoldCoins.crop(gwidth*5, 0, gwidth, gheight);
        goldCoins[6] = GoldCoins.crop(gwidth*6, 0, gwidth, gheight);
        goldCoins[7] = GoldCoins.crop(gwidth*7, 0, gwidth, gheight);

        goldC = new Animation(100, goldCoins);

        player_bow = new BufferedImage[8];
        player_bow[0] = PBowNArrow.crop(0, 0, pwidhei, pwidhei);
        player_bow[1] = PBowNArrow.crop(pwidhei, 0, pwidhei, pwidhei);
        player_bow[2] = PBowNArrow.crop(pwidhei*2, 0, pwidhei, pwidhei);
        player_bow[3] = PBowNArrow.crop(pwidhei*3, 0, pwidhei, pwidhei);
        player_bow[4] = PBowNArrow.crop(0, pwidhei, pwidhei, pwidhei);
        player_bow[5] = PBowNArrow.crop(pwidhei, pwidhei, pwidhei, pwidhei);
        player_bow[6] = PBowNArrow.crop(pwidhei*2, pwidhei, pwidhei, pwidhei);
        player_bow[7] = PBowNArrow.crop(pwidhei*3, pwidhei, pwidhei, pwidhei);

        Ant_S = new BufferedImage[4];
        Ant_S[0] = Ants.crop(0, eheight*2, ewidth, eheight);
        Ant_S[1] = Ants.crop(0, eheight*3, ewidth, eheight);
        Ant_S[2] = Ants.crop(ewidth, eheight*2, ewidth, eheight);
        Ant_S[3] = Ants.crop(ewidth, eheight*3, ewidth, eheight);

        AntBoss_S = new BufferedImage[4];
        AntBoss_S[0] = Ants.crop(ewidth*2, 0, ewidth, eheight);
        AntBoss_S[1] = Ants.crop(ewidth*2, eheight, ewidth, eheight);
        AntBoss_S[2] = Ants.crop(ewidth*3, 0, ewidth, eheight);
        AntBoss_S[3] = Ants.crop(ewidth*3, eheight, ewidth, eheight);

        Bee_S = new BufferedImage[4];
        Bee_S[0] = Bees.crop(0, eheight*2, ewidth, eheight);
        Bee_S[1] = Bees.crop(0, eheight*3, ewidth, eheight);
        Bee_S[2] = Bees.crop(ewidth, eheight*2, ewidth, eheight);
        Bee_S[3] = Bees.crop(ewidth, eheight*3, ewidth, eheight);

        Beetle_S = new BufferedImage[4];
        Beetle_S[0] = Beetles.crop(0, eheight*2, ewidth, eheight);
        Beetle_S[1] = Beetles.crop(0, eheight*3, ewidth, eheight);
        Beetle_S[2] = Beetles.crop(ewidth, eheight*2, ewidth, eheight);
        Beetle_S[3] = Beetles.crop(ewidth, eheight*3, ewidth, eheight);

        Fly_S = new BufferedImage[4];
        Fly_S[0] = Flies.crop(0, eheight*2, ewidth, eheight);
        Fly_S[1] = Flies.crop(0, eheight*3, ewidth, eheight);
        Fly_S[2] = Flies.crop(ewidth, eheight*2, ewidth, eheight);
        Fly_S[3] = Flies.crop(ewidth, eheight*3, ewidth, eheight);

        Ladybird_S = new BufferedImage[4];
        Ladybird_S[0] = Ladybirds.crop(0, eheight*2, ewidth, eheight);
        Ladybird_S[1] = Ladybirds.crop(0, eheight*3, ewidth, eheight);
        Ladybird_S[2] = Ladybirds.crop(ewidth, eheight*2, ewidth, eheight);
        Ladybird_S[3] = Ladybirds.crop(ewidth, eheight*3, ewidth, eheight);

        Mosquito_S = new BufferedImage[4];
        Mosquito_S[0] = Mosquitoes.crop(0, eheight*2, ewidth, eheight);
        Mosquito_S[1] = Mosquitoes.crop(0, eheight*3, ewidth, eheight);
        Mosquito_S[2] = Mosquitoes.crop(ewidth, eheight*2, ewidth, eheight);
        Mosquito_S[3] = Mosquitoes.crop(ewidth, eheight*3, ewidth, eheight);

        MenuBtns = new BufferedImage[4];
        MenuBtns[0] = MenuButs.crop(0, 0, bwidth*4, bheight*2);
        MenuBtns[1] = MenuButs.crop(0, 0, bwidth*4, bheight*2);
        MenuBtns[2] = MenuButs.crop(0, 0, bwidth*4, bheight);
        MenuBtns[3] = MenuButs.crop(0, 0, bwidth*4, bheight);

        player_down = new BufferedImage[5];
        player_up = new BufferedImage[5];
        player_right = new BufferedImage[5];
        player_left = new BufferedImage[5];
        player_attack = new BufferedImage[5];

        player_down[0] = players.crop(0, pheight, pwidth, pheight);
        player_down[1] = players.crop(pwidth, pheight, pwidth, pheight);
        player_down[2] = players.crop(pwidth*2, pheight, pwidth, pheight);
        player_down[3] = players.crop(pwidth*3, pheight, pwidth, pheight);
        player_down[4] = players.crop(pwidth*4, pheight, pwidth, pheight);

        player_up[0] = players.crop(0, 0, pwidth, pheight);
        player_up[1] = players.crop(pwidth, 0, pwidth, pheight);
        player_up[2] = players.crop(pwidth*2, 0, pwidth, pheight);
        player_up[3] = players.crop(pwidth*3, 0, pwidth, pheight);
        player_up[4] = players.crop(pwidth*4, 0, pwidth, pheight);

        player_right[0] = players.crop(0, pheight*2, pwidth, pheight);
        player_right[1] = players.crop(pwidth, pheight*2, pwidth, pheight);
        player_right[2] = players.crop(pwidth*2, pheight*2, pwidth, pheight);
        player_right[3] = players.crop(pwidth*3, pheight*2, pwidth, pheight);
        player_right[4] = players.crop(pwidth*4, pheight*2, pwidth, pheight);

        player_left[0] = players.crop(0, pheight*3, pwidth, pheight);
        player_left[1] = players.crop(pwidth, pheight*3, pwidth, pheight);
        player_left[2] = players.crop(pwidth*2, pheight*3, pwidth, pheight);
        player_left[3] = players.crop(pwidth*3, pheight*3, pwidth, pheight);
        player_left[4] = players.crop(pwidth*4, pheight*3, pwidth, pheight);

        player_attack[0] = players.crop(0, pheight*4, pwidth, pheight);
        player_attack[1] = players.crop(pwidth, pheight*4, pwidth, pheight);
        player_attack[2] = players.crop(pwidth*2, pheight*4, pwidth, pheight);
        player_attack[3] = players.crop(pwidth*3, pheight*4, pwidth, pheight);
        player_attack[4] = players.crop(pwidth*4, pheight*4, pwidth, pheight);

        dirt = ForestTown.crop(width*14, 0, width*2, height*2);
        tree = ForestTown.crop(0, height*12, width*4, height*4);
        grass = ForestTown.crop(width*2, height*2, width*2, height*2);
        sand = Desert.crop(width*10, 0, width*4, height*4);
        stone = tiles.crop(width*7, height, width, height);
        water = tiles.crop(width*5, height*2, width, height);
        rocks = tiles.crop(width*2, height*7, width, height);

        brick = SnowTown.crop(0, 0, twidhei, twidhei);
        openDoor = SnowTown.crop(twidhei, 0, twidhei, twidhei);
        closeDoor = SnowTown.crop(twidhei*2, 0, twidhei, twidhei);
        openWindow = SnowTown.crop(twidhei*3, 0, twidhei, twidhei);
        closeWindow = SnowTown.crop(twidhei*4, 0, twidhei, twidhei);
        ice = SnowTown.crop(twidhei*7, 0, twidhei, twidhei);
        snow = SnowTown.crop(0, twidhei, twidhei, twidhei);
        bigSnow = SnowTown.crop(twidhei, twidhei, twidhei, twidhei);
        snowLeft = SnowTown.crop(twidhei*2, twidhei*2, twidhei, twidhei);
        snowRight = SnowTown.crop(twidhei*7, twidhei*2, twidhei, twidhei);

        /**player = players.crop(0, 0, pwidth, pheight);*/


        /**Minish Cap Field Sprites
         *
         *
         *
         */

        tree2 = Field.crop(widhei*23, widhei*7, widhei*2, widhei*2);
        dirt2 = Field.crop(widhei*3+10, widhei*5, widhei-8, widhei);
        grass2 = Field.crop(widhei*4+11, widhei*5, widhei*2-2, widhei*2);
        tallgrass = Field.crop(widhei*16, widhei*18, widhei-8, widhei-8);
        //dirt2 = Field.crop(widhei*16, widhei*7, widhei, widhei);
        water2 = Field.crop(widhei*9, widhei*9, widhei, widhei);
        woodbridge = Field.crop(widhei*9, widhei*4-3, widhei, widhei);
        woodbridgeup = Field.crop(widhei*9, widhei*4-16, widhei, widhei);
        woodbridgedown = Field.crop(widhei*9, widhei*4+7, widhei, widhei);
        shallowwater = Field.crop(widhei*6+17, widhei*12, widhei-7, widhei);
        cliffup = Field.crop(widhei*13, widhei*12+5, widhei, widhei-12);
        cliffdown = Field.crop(widhei*12, widhei*6, widhei, widhei);
        cliffleft = Field.crop(widhei*7-5, widhei*7, widhei-12, widhei);
        cliffright = Field.crop(widhei*15-6, widhei*7, widhei-10, widhei);
        caveopening = Field.crop(widhei*2-7, widhei*33+12, widhei+10, widhei);

        //Highest Score = 118000
    }

    public static BufferedImage getImage(BufferedImage[] images, int index){
        return images[index];
    }

    public static BufferedImage getAttackImage(int index){
        return player_attack[index];
    }
    public static BufferedImage getStandingImage(int index, int type){
        if(type==0){
            return player_down[index];
        } else if(type==1){
            return player_left[index];
        } else if(type==2) {
            return player_right[index];
        } else if(type==3) {
            return player_up[index];
        } return player_down[index];
    }

    public static Stage loadStages(Handler handler, String stageName){
        stage1 = new Stage(handler, "Resources/Stages/Stage1.lvl");
        stage2 = new Stage(handler, "Resources/Stages/Stage2.lvl");
        stage3 = new Stage(handler, "Resources/Stages/Stage3.lvl");
        stage4 = new Stage(handler, "Resources/Stages/Stage4.lvl");
        stage5 = new Stage(handler, "Resources/Stages/Stage5.lvl");
        stage6 = new Stage(handler, "Resources/Stages/Stage6.lvl");

        stageL = new Stage(handler, "Resources/Stages/Antol Field.lvl");
        stageBR = new Stage(handler, "Resources/Stages/Betsle Field.lvl");
        stageUR = new Stage(handler, "Resources/Stages/Greater Prithvi.lvl");
        stageUL = new Stage(handler, "Resources/Stages/Prithvi Highlands.lvl");
        stageR = new Stage(handler, "Resources/Stages/Minour Prithvi.lvl");
        stageB = new Stage(handler, "Resources/Stages/South Prithvi Plains.lvl");
        stageU = new Stage(handler, "Resources/Stages/North Prithvi Plains.lvl");
        stageBL = new Stage(handler, "Resources/Stages/Prithvi Valley.lvl");
        stageNN1 = new Stage(handler, "Resources/Stages/StageNN1.lvl");
        stageNN2 = new Stage(handler, "Resources/Stages/StageNN2.lvl");
        if(stageName=="stageB"){
            return stageB;
        } if(stageName=="stageU"){
            return stageU;
        } if(stageName=="stageBL"){
            return stageBL;
        } if(stageName=="stageBR"){
            return stageBR;
        } if(stageName=="stageL"){
            return stageL;
        } if(stageName=="stageUR"){
            return stageUR;
        } if(stageName=="stageUL"){
            return stageUL;
        } if(stageName=="stageR"){
            return stageR;
        } if(stageName=="stage1"){
            return stage1;
        } if(stageName=="stage2"){
            return stage2;
        } if(stageName=="stage3"){
            return stage3;
        } if(stageName=="stage4"){
            return stage4;
        } if(stageName=="stage5"){
            return stage5;
        } if(stageName=="stage6"){
            return stage6;
        } if(stageName=="stageMain"){
            return stageMain;
        } if(stageName=="stageNN1"){
            return stageNN1;
        } if(stageName=="stageNN2"){
            return stageNN2;
        }
        return null;
    }
}
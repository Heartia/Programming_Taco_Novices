public class SnowIce extends Tile {
    public SnowIce(int id) {super(Assets.ice, id);}
}
public class Snow extends Tile {
    public Snow(int id) {super(Assets.snow, id);}
}
import javax.swing.*;
import java.awt.*;

public class MenuState extends State {

    private UIManager uiManager;
    private Image splash;

    public MenuState(Handler handler){
        super(handler);

        uiManager = new UIManager(handler);
        handler.getMouseManager().setUIManager(uiManager);
        splash = new ImageIcon("Resources/Textures/Splash Screen.png").getImage();
        uiManager.addObject(new UIImageButton(500, 600, 256, 128, Assets.MenuBtns, new ClickListener(){
            @Override
            public void onClick() {
                handler.getMouseManager().setUIManager(null);
                State.setState(handler.getGame().gameState);
            }
        }));
    }

    @Override
    public void tick() {
        uiManager.tick();
    }

    @Override
    public void render(Graphics g) {
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, 1280, 832);
        g.drawImage(splash, 75, 0, null);
        uiManager.render(g);
    }

}
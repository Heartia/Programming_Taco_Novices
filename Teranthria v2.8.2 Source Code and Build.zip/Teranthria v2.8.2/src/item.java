import java.awt.*;
import java.awt.image.BufferedImage;

public class item {
    //Handler
    public static item[] items = new item[256];
    public static item wooditem = new item(Assets.wood, "Wood", 0);
    public static item rockitem = new item(Assets.pebbles, "rocks", 1);
    public static item gemitem = new item(Assets.gems, "gemstones", 2);
    public static item coinitem = new item(Assets.goldCoins[0], "gold coins", 3);
    public static item heartitem = new item(Assets.heart, "heart", 4);

    protected Rectangle bounds;

    //Ma CLASS
    public static final int ITEMWIDTH = 32, ITEMHEIGHT = 32;

    protected Handler handler;
    protected BufferedImage texture;
    protected Animation textures;
    protected String name;
    protected int id;

    protected int x, y, count;
    public boolean pickedUp = false;

    public item(BufferedImage texture, String name, int id){
        this.texture = texture;
        this.name = name;
        this.id = id;
        count = 1;

        bounds = new Rectangle(x, y, ITEMWIDTH, ITEMHEIGHT);

        items[id] = this;
    }

    public item(Animation textures, String name, int id){
        this.textures = textures;
        this.name = name;
        this.id = id;
        count = 1;

        bounds = new Rectangle(x, y, ITEMWIDTH, ITEMHEIGHT);

        items[id] = this;
    }

    public void tick(){
        if(handler.getStage().getEntityManager().getPlayer().getCollisionBounds(0f, 0f).intersects(bounds)){
            pickedUp = true;
            handler.getStage().getEntityManager().getPlayer().getInventory().addItem(this);
        }
    }

    public void render(Graphics g){
        if(handler == null){return;}
        render(g, (int) (x - handler.getCamera().getxOffset()), (int) (y - handler.getCamera().getyOffset()));
    }

    public void render(Graphics g, int x, int y){
        g.drawImage(texture, x, y, ITEMWIDTH, ITEMHEIGHT, null);
    }

    public item createNew(int x, int y){
        item i = new item(texture, name, id);
        i.setPosition(x, y);
        return i;
    }

    public item createNew(int count){
        item i = new item(texture, name, id);
        i.setPickedUp(true);
        i.setCount(count);
        return i;
    }

    public void setPosition(int x, int y){
        this.x = x;
        this.y = y;
        bounds.x = x;
        bounds.y = y;
    }

    //GETTIES Y ME SETTIES

    public Handler getHandler() {
        return handler;
    }

    public void setHandler(Handler handler) {
        this.handler = handler;
    }

    public BufferedImage getTexture() {
        return texture;
    }

    public void setTexture(BufferedImage texture) {
        this.texture = texture;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public boolean isPickedUp() {
        return pickedUp;
    }

    public void setPickedUp(boolean pickedUp) {
        this.pickedUp = pickedUp;
    }
}
import java.awt.*;
import java.util.Random;

public class AntBoss extends Character {
    private float xon;
    private float yon;

    //Attack Timer
    private long lastAttackTimer, attackCooldown = 500, attackTimer = attackCooldown;

    private Player player;
    public AntBoss(Handler handler, float x, float y, Player player) {
        super(handler, x, y, Tile.TILEWIDTH*2, Tile.TILEHEIGHT*2);

        this.player = player;

        bounds.x = 50;
        bounds.y = (int) ((height / 4.5f)*2);
        bounds.width = (width - 50)*2;
        bounds.height = (int) ((height - height / 4.5f)*2);

        health = 1500;
        DEFAULT_HEALTH = 1500;
    }

    @Override
    public void tick() {
        this.checkAttacks();

        xon = player.getX();
        yon = player.getY();
        if((Math.abs(xon)>Math.abs(yon))){
            if(x<xon){
                x+=4;
                if(y<yon){
                    y+=4;
                } if(y>yon){
                    y-=4;
                }
            } if(x>xon){
                x-=4;
                if(y<yon){
                    y+=4;
                } if(y>yon){
                    y-=4;
                }
            }
        }

        if((Math.abs(xon)<Math.abs(yon))){
            if(y<yon){
                y+=4;
                if(x<xon){
                    x+=4;
                } if(x>xon){
                    x-=4;
                }
            } if(y>yon){
                y-=4;
                if(x<xon){
                    x+=4;
                } if(x>xon){
                    x-=4;
                }
            }
        }

            /*Random shouldX = new Random();
            int sxvalue = shouldX.nextInt(2)+1;
            Random shouldY = new Random();
            int syvalue = shouldY.nextInt(2)+1;
            if(sxvalue>1){
                Random moveX = new Random();
                int mxvalue = moveX.nextInt(8)+1;
                Random UD = new Random();
                int udvalue = UD.nextInt(2)+1;
                if(udvalue>1){
                    x+=mxvalue;
                } else{
                    x-=mxvalue;
                }
            } if(syvalue>1){
                Random moveY = new Random();
                int myvalue = moveY.nextInt(8)+1;
                y+=myvalue;
                Random UD = new Random();
                int udvalue = UD.nextInt(2)+1;
                if(udvalue>1){
                    y+=myvalue;
                } else{
                    y-=myvalue;
                }
            }*/
    }

    private void checkAttacks(){
        attackTimer += System.currentTimeMillis() - lastAttackTimer;
        lastAttackTimer = System.currentTimeMillis();
        if(attackTimer<attackCooldown){
            return;
        }

        Rectangle cb = getCollisionBounds(0, 0);
        Rectangle ar = new Rectangle();
        int arSize = 300;
        ar.width = arSize;
        ar.height = arSize;

        if((Math.abs(xon)>Math.abs(yon))){
            if(x<xon){
                ar.x = cb.x - arSize;
                ar.y = cb.y + cb.height / 2 - arSize / 2;
            } if(x>xon){
                ar.x = cb.x + cb.width;
                ar.y = cb.y + cb.height / 2 - arSize / 2;
            }
        }

        if((Math.abs(xon)<Math.abs(yon))){
            if(y<yon){
                ar.x = cb.x + cb.width / 2 - arSize / 2;
                ar.y = cb.y + cb.height;
            } if(y>yon){
                ar.x = cb.x + cb.width / 2 - arSize / 2;
                ar.y = cb.y - arSize;
            }
        }

        attackTimer = 0;

        for(Entity e : handler.getStage().getEntityManager().getEntities()){
            if(e.equals(this)){
                continue;
            } if(e.getCollisionBounds(0, 0).intersects(ar)){
                if(e.equals(player)){
                    int hp = player.getHealth()-4;
                    player.setHealth(hp);
                }
                e.hurt(0);
                return;
            }
        }
    }

    @Override
    public void render(Graphics g) {
        g.drawImage(Assets.Ant_S[0], (int) (x - handler.getCamera().getxOffset()), (int) (y - handler.getCamera().getyOffset()), width*2, height*2, null);
        if((Math.abs(xon)>Math.abs(yon))) {
            if (x < xon) {
                g.drawImage(Assets.AntBoss_S[2], (int) (x - handler.getCamera().getxOffset()), (int) (y - handler.getCamera().getyOffset()), width*2, height*2, null);
            }
            if (x > xon) {
                g.drawImage(Assets.AntBoss_S[0], (int) (x - handler.getCamera().getxOffset()), (int) (y - handler.getCamera().getyOffset()), width*2, height*2, null);
            } else if ((Math.abs(xon) < Math.abs(yon))) {
                if (y < yon) {
                    g.drawImage(Assets.AntBoss_S[1], (int) (x - handler.getCamera().getxOffset()), (int) (y - handler.getCamera().getyOffset()), width*2, height*2, null);
                    if (y > yon) {
                        g.drawImage(Assets.AntBoss_S[3], (int) (x - handler.getCamera().getxOffset()), (int) (y - handler.getCamera().getyOffset()), width*2, height*2, null);
                    }
                } else {
                    g.drawImage(Assets.AntBoss_S[0], (int) (x - handler.getCamera().getxOffset()), (int) (y - handler.getCamera().getyOffset()), width*2, height*2, null);
                }
            }
        }
    }

    @Override
    public void die() {
        Random drop = new Random();
        int value = drop.nextInt(10)+1;
        int count = handler.getStage().getCount();
        count--;
        handler.getStage().setCount(count);
        if(handler.getStage().getEntityManager().getPlayer().getIsActive()){
        if((value < 8) && (value > 5)){
            handler.getStage().getItemManager().addItem(item.coinitem.createNew((int)x, (int)y));
            handler.getStage().getItemManager().addItem(item.coinitem.createNew((int)x-50, (int)y-50));
            int jigglyCoins = handler.getStage().getEntityManager().getPlayer().getCoinCount();
            handler.getStage().getEntityManager().getPlayer().setCoinCount(jigglyCoins+20);
            int jigglyPoints = handler.getStage().getEntityManager().getPlayer().getPoints();
            handler.getStage().getEntityManager().getPlayer().setPoints(jigglyPoints+20000);
        } else if(value>=8){
            handler.getStage().getItemManager().addItem(item.heartitem.createNew((int)x, (int)y));
            Random heal = new Random();
            int fillHeal = heal.nextInt(20)+1;
            if(fillHeal>17){
                handler.getStage().getEntityManager().getPlayer().setChemies(handler.getStage().getEntityManager().getPlayer().getChemies()+4);
            }
        } else if(value<=5&&value>2){
            handler.getStage().getItemManager().addItem(item.coinitem.createNew((int)x, (int)y));
            int jigglyCoins = handler.getStage().getEntityManager().getPlayer().getCoinCount();
            handler.getStage().getEntityManager().getPlayer().setCoinCount(jigglyCoins+10);
            int jigglyPoints = handler.getStage().getEntityManager().getPlayer().getPoints();
            handler.getStage().getEntityManager().getPlayer().setPoints(jigglyPoints+10000);
        }}
    }
}
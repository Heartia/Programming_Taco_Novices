import java.awt.image.BufferedImage;

public class AntTile extends Tile {
    public AntTile(BufferedImage texture, int id) {
        super(Assets.Ant_S[0], id);
    }

    public AntTile(int id) {
        super(Assets.Ant_S[0], id);
    }

    @Override
    public boolean isSolid(){
        return true;
    }

    @Override
    public boolean isHurtable(){
        return true;
    }
}
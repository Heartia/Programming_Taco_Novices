import java.awt.*;
import java.util.Random;

public class Rock extends EntityStatic {

    private static Rock Rock;

    public Rock(Handler handler, float x, float y) {
        super(handler, x, y, Tile.TILEWIDTH, Tile.TILEHEIGHT);
    }

    @Override
    public void tick() {

    }

    @Override
    public void render(Graphics g) {
        g.drawImage(Assets.rocks, (int)(x-handler.getCamera().getxOffset()), (int)(y-handler.getCamera().getyOffset()), width, height, null);
    }

    @Override
    public void die() {
        Random drop = new Random();
        int value = drop.nextInt(10)+1;
        if(value>8){
            handler.getStage().getItemManager().addItem(item.gemitem.createNew((int)x, (int)y));
            int jigglyCoins = handler.getStage().getEntityManager().getPlayer().getCoinCount();
            handler.getStage().getEntityManager().getPlayer().setCoinCount(jigglyCoins+5);
            int jigglyPoints = handler.getStage().getEntityManager().getPlayer().getPoints();
            handler.getStage().getEntityManager().getPlayer().setPoints(jigglyPoints+5000);
        } else{
            handler.getStage().getItemManager().addItem(item.rockitem.createNew((int)x, (int)y));
            int jigglyCoins = handler.getStage().getEntityManager().getPlayer().getCoinCount();
            handler.getStage().getEntityManager().getPlayer().setCoinCount(jigglyCoins+3);
            int jigglyPoints = handler.getStage().getEntityManager().getPlayer().getPoints();
            handler.getStage().getEntityManager().getPlayer().setPoints(jigglyPoints+3000);
        }
    }

    public static Rock getRock(){
        return Rock;
    }
}
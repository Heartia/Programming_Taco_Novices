public class TileWoodBridgeUp extends Tile {
    public TileWoodBridgeUp(int id) {
        super(Assets.woodbridgeup, id);
    }

    @Override
    public boolean isSolid(){
        return true;
    }
}
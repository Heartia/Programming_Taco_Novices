public class SnowOWindow extends Tile {
    public SnowOWindow(int id) {super(Assets.openWindow, id);}

    @Override
    public boolean isSolid() {return true;}
}
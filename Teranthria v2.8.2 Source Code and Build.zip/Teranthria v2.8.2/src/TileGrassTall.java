public class TileGrassTall extends Tile {
    public TileGrassTall(int id) {
        super(Assets.tallgrass, id);
    }

    @Override
    public boolean isSolid(){
        return true;
    }
}
public class TileShallowWater extends Tile {
    public TileShallowWater(int id) {
        super(Assets.shallowwater, id);
    }
}
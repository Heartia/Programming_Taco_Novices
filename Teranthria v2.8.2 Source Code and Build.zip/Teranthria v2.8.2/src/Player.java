import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Random;

public class Player extends Character {
    //Animations
    private Animation animDown, animUp, animLeft, animRight;
    private Graphics g;

    //Attack Timer
    private long lastAttackTimer, attackCooldown = 50, attackTimer = attackCooldown;

    //Ma Tory of the Inven
    private Inventory inventory;

    //Standing Animation
    private int sDir = 0;

    //Pts System
    private int points = 0;
    private int coinCount = 0;
    private int forcePieces = 0;
    private int MAX_HEALTH = 20;

    //Bow, Potion or Punch?
    private boolean bow, punch, potion;
    private int arrows, chemies;
    
    private boolean isActive;
    
    private int endScore;

    public Player(Handler handler, float x, float y) {
        super(handler, x, y, Character.DEFAULT_CHARACTER_WIDTH, Character.DEFAULT_CHARACTER_HEIGHT);
        this.handler = handler;
        
        isActive = true;

        bow = false;
        punch = true;
        potion = false;

        arrows = 200;
        chemies = 12;

        bounds.x = 10;
        bounds.y = 30;
        bounds.width = 40;
        bounds.height = 34;

        //Animations
        animDown = new Animation(250, Assets.player_down);
        animUp = new Animation(250, Assets.player_up);
        animRight = new Animation(250, Assets.player_right);
        animLeft = new Animation(250, Assets.player_left);

        inventory = new Inventory(handler);

        attack = 1f;

        health = 20;
    }

    public void die(){

    }

    @Override
    public void tick() {
        /*if(game.getKeyManager().up)
            y -= 4;
        if(game.getKeyManager().down)
            y += 4;
        if(game.getKeyManager().left)
            x -= 4;
        if(game.getKeyManager().right)
            x += 4;*/
        //Animations
        animDown.tick();
        animUp.tick();
        animRight.tick();
        animLeft.tick();

        //Movement
        getInput();
        move();
        handler.getCamera().centerOnEntity(this);

        //Attack
        checkAttacks();

        //Ma Tory of the Inven
        inventory.tick();

        if(health == 0){
            this.die();
            isActive = false;
            endScore = points;
        }
    }

    private void checkAttacks(){
        attackTimer += System.currentTimeMillis() - lastAttackTimer;
        lastAttackTimer = System.currentTimeMillis();
        if(attackTimer<attackCooldown){
            return;
        }

        Rectangle cb =  getCollisionBounds(0, 0);
        Rectangle ar = new Rectangle();
        int arSize = 20;
        ar.width = arSize;
        ar.height = arSize;

        if(handler.getKeyManager().bAtk){
            bow = true;
            punch = false;
            potion = false;
        } if(handler.getKeyManager().aAtk){
            bow = false;
            punch = true;
            potion = false;
        } if(handler.getKeyManager().pHeal){
            bow = false;
            punch = false;
            potion = true;
        }

        if(punch){
            if(handler.getKeyManager().aUp){
                ar.x = cb.x + cb.width / 2 - arSize / 2;
                ar.y = cb.y - arSize;
            } else if(handler.getKeyManager().aDown){
                ar.x = cb.x + cb.width / 2 - arSize / 2;
                ar.y = cb.y + cb.height;
            } else if(handler.getKeyManager().aLeft){
                ar.x = cb.x - arSize;
                ar.y = cb.y + cb.height / 2 - arSize / 2;
            } else if(handler.getKeyManager().aRight){
                ar.x = cb.x + cb.width;
                ar.y = cb.y + cb.height / 2 - arSize / 2;
            } else {
                return;
            }}

        if(bow){
            if(handler.getKeyManager().aUp){
                ar.x = cb.x + cb.width / 2 - arSize / 2;
                ar.y = cb.y - cb.height;
            } else if(handler.getKeyManager().aDown){
                ar.x = cb.x + cb.width / 2 - arSize / 2;
                ar.y = cb.y + cb.height;
            } else if(handler.getKeyManager().aLeft){
                ar.x = cb.x - arSize;
                ar.y = cb.y + cb.height / 2 - arSize / 2;
            } else if(handler.getKeyManager().aRight){
                ar.x = cb.x + cb.width;
                ar.y = cb.y + cb.height / 2 - arSize / 2;
            } else {
                return;
            }
        }

        if(potion){
            if(handler.getKeyManager().xChoose){
                if(chemies>0){
                    if(health+16>=20){
                        health = 20;
                    } else{
                        health+=16;
                    }
                }
            }
        }

        attackTimer = 0;

        for(Entity e : handler.getStage().getEntityManager().getEntities()){
            if(e.equals(this)){
                continue;
            } if(e.getCollisionBounds(0, 0).intersects(ar)){
                e.hurt((int)attack);
                Random er = new Random();
                int erVal = er.nextInt(50)+1;
                if(erVal==7){
                    if(health+4>=20){
                        health = 20;
                    } else{
                        health+=4;
                    }
                }
                points+=100;
                if(e.equals(Rock.getRock())){
                    return;
                }

                if(x>e.getX()){
                    e.setX(e.getX()-20);
                } if(x<e.getX()){
                    e.setX(e.getX()+20);
                }

                if(y>e.getY()){
                    e.setY(e.getY()-20);
                } if(y<e.getY()){
                    e.setY(e.getY()+20);
                }

                return;
            }
        }
    }

    private void getInput(){
        xMove = 0;
        yMove = 0;

        if((handler.getKeyManager().up||handler.getKeyManager().rUp)&&
                (handler.getKeyManager().aUp||handler.getKeyManager().aDown||
                        handler.getKeyManager().aLeft||handler.getKeyManager().aRight)){
            yMove = -(speed/3);
            sDir = 3;
        }
        else if(handler.getKeyManager().rUp){
            yMove = -speed*2;
        }else if(handler.getKeyManager().up){
            yMove = -speed;
        }

        if((handler.getKeyManager().down||handler.getKeyManager().rDown)&&
                (handler.getKeyManager().aUp||handler.getKeyManager().aDown||
                        handler.getKeyManager().aLeft||handler.getKeyManager().aRight)){
            yMove = +(speed/3);
            sDir = 0;
        }
        else if(handler.getKeyManager().rDown){
            yMove = +speed*2;
        }else if(handler.getKeyManager().down){
            yMove = +speed;
        }

        if((handler.getKeyManager().left||handler.getKeyManager().rLeft)&&
                (handler.getKeyManager().aUp||handler.getKeyManager().aDown||
                        handler.getKeyManager().aLeft||handler.getKeyManager().aRight)){
            xMove = -(speed/3);
            sDir = 1;
        }
        else if(handler.getKeyManager().rLeft){
            xMove = -speed*2;
        }else if(handler.getKeyManager().left){
            xMove = -speed;
        }

        if((handler.getKeyManager().right||handler.getKeyManager().rRight)&&
                (handler.getKeyManager().aUp||handler.getKeyManager().aDown||
                        handler.getKeyManager().aLeft||handler.getKeyManager().aRight)){
            xMove = +(speed/3);
            sDir = 2;
        }
        else if(handler.getKeyManager().rRight){
            xMove = +speed*2;
        }else if(handler.getKeyManager().right){
            xMove = +speed;
        }

        this.checkEdges();
    }

    public void checkEdges(){
        if(this.getX()>Tile.TILEWIDTH*39){
            x = Tile.TILEWIDTH*39;
            handler.getGame().getGameState();
        } else if(this.getX()<0){
            x = 0;
            handler.getGame().getGameState();
        }

        if(this.getY()>Tile.TILEHEIGHT*38){
            y = Tile.TILEHEIGHT*38;
            handler.getGame().getGameState();
        } else if(this.getY()<0-10){
            y = 0-10;
            handler.getGame().getGameState();
        }
    }

    @Override
    public void render(Graphics g) {
        if(bow){
            if(handler.getKeyManager().aUp){
                g.drawImage(Assets.player_bow[6], (int) (x-handler.getCamera().getxOffset()),
                        (int) (y-handler.getCamera().getyOffset()), width, height, null);
                arrows--;
                for(int d = 0; d<1000; d++){
                    g.drawImage(Assets.player_bow[2], (int) (x-handler.getCamera().getxOffset()),
                            (int) (y-handler.getCamera().getyOffset()) - d, width, height, null);
                }
            } else if(handler.getKeyManager().aDown){
                g.drawImage(Assets.player_bow[7], (int) (x-handler.getCamera().getxOffset()),
                        (int) (y-handler.getCamera().getyOffset()), width, height, null);
                arrows--;
                for(int d = 0; d<1000; d++){
                    g.drawImage(Assets.player_bow[3], (int) (x-handler.getCamera().getxOffset()),
                            (int) (y-handler.getCamera().getyOffset()) + d, width, height, null);
                }
            } else if(handler.getKeyManager().aLeft){
                g.drawImage(Assets.player_bow[4], (int) (x-handler.getCamera().getxOffset()),
                        (int) (y-handler.getCamera().getyOffset()), width, height, null);
                arrows--;
                for(int d = 0; d<1000; d++){
                    g.drawImage(Assets.player_bow[1], (int) (x-handler.getCamera().getxOffset()) - d,
                            (int) (y-handler.getCamera().getyOffset()), width, height, null);
                }
            } else if(handler.getKeyManager().aRight){
                g.drawImage(Assets.player_bow[5], (int) (x-handler.getCamera().getxOffset()),
                        (int) (y-handler.getCamera().getyOffset()), width, height, null);
                arrows--;
                for(int d = 0; d<1000; d++){
                    g.drawImage(Assets.player_bow[0], (int) (x-handler.getCamera().getxOffset() + d),
                            (int) (y-handler.getCamera().getyOffset()), width, height, null);
                }
            } else{ g.drawImage(getCurrentAnimationFrame(), (int) (x - handler.getCamera().getxOffset()),
                    (int) (y - handler.getCamera().getyOffset()), width, height,null);}
        }

        if(punch){
            if(handler.getKeyManager().aUp||handler.getKeyManager().aDown||handler.getKeyManager().aLeft||handler.getKeyManager().aRight){
                g.drawImage(getCurrentAttackFrame(), (int) (x-handler.getCamera().getxOffset()),
                        (int) (y-handler.getCamera().getyOffset()), width, height, null);}
            else{ g.drawImage(getCurrentAnimationFrame(), (int) (x - handler.getCamera().getxOffset()),
                    (int) (y - handler.getCamera().getyOffset()), width, height,null);}
        }

        if(potion){
            g.drawImage(getCurrentAnimationFrame(), (int) (x - handler.getCamera().getxOffset()),
                    (int) (y - handler.getCamera().getyOffset()), width, height,null);
        }
    }

    public void postRender(Graphics g){
        g.setColor(Color.BLACK);
        g.fillRect(315, 15, 700, 75);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Tahoma", Font.BOLD, 50));
        g.drawString("Points: " + points, 365, 70);
        g.setColor(Color.BLACK);
        g.fillRect(15, 70, 700, 90);
        g.setColor(Color.WHITE);
        g.drawImage(Assets.goldCoins[0], 30, 95, 50, 50, null);
        g.drawString("" + coinCount, 100, 140);
        g.drawImage(Assets.force, 430, 100, 50, 50, null);
        g.drawString("" + forcePieces, 500, 140);
        g.setFont(new Font("Tahoma", Font.BOLD, 75));
        g.setColor(new Color(0, 169, 255));

        if(handler.getGame().isPaused){
            g.drawImage(Assets.gamePause, 100, 100, 1080, 620, null);
        }

        if(punch){
            g.drawImage(Assets.punchIcon, 1050, 15, 75, 75, null);
        } if(bow){
            g.setFont(new Font("Tahoma", Font.BOLD, 15));
            if(handler.getKeyManager().aUp||handler.getKeyManager().aDown||handler.getKeyManager().aRight||handler.getKeyManager().aLeft){
                if(arrows>0){
                    arrows--;
                } else{
                    arrows=0;
                }
            }
            g.drawImage(Assets.bowIcon, 1050, 15, 75, 75, null);
            g.drawString(arrows/4 + "", 1060, 35);
            g.setFont(new Font("Tahoma", Font.BOLD, 75));
        } if(potion){
            g.setFont(new Font("Tahoma", Font.BOLD, 15));
            if(handler.getKeyManager().xChoose){
                if(chemies>0){
                    chemies--;}
            }
            g.drawImage(Assets.potionIcon, 1050, 15, 75, 75, null);
            g.drawString(chemies/4 + "", 1060, 35);
            g.setFont(new Font("Tahoma", Font.BOLD, 75));
        }

        inventory.render(g);

        if(health>=20){
            g.drawImage(Assets.HPhearts[19], 15, 15, 300, 75, null);}
        else if(health==19){
            g.drawImage(Assets.HPhearts[18], 15, 15, 300, 75,null);
        } else if(health==18){
            g.drawImage(Assets.HPhearts[17], 15, 15, 300, 75,null);
        } else if(health==17){
            g.drawImage(Assets.HPhearts[16], 15, 15, 300, 75,null);
        } else if(health==16){
            g.drawImage(Assets.HPhearts[15], 15, 15,  300, 75,null);
        } else if(health==15){
            g.drawImage(Assets.HPhearts[14], 15, 15,  300, 75,null);
        } else if(health==14){
            g.drawImage(Assets.HPhearts[13], 15, 15,  300, 75,null);
        } else if(health==13){
            g.drawImage(Assets.HPhearts[12], 15, 15,  300, 75,null);
        } else if(health==12){
            g.drawImage(Assets.HPhearts[11], 15, 15, 300, 75, null);
        } else if(health==11){
            g.drawImage(Assets.HPhearts[10], 15, 15, 300, 75, null);
        } else if(health==10){
            g.drawImage(Assets.HPhearts[9], 15, 15,  300, 75,null);
        } else if(health==9){
            g.drawImage(Assets.HPhearts[8], 15, 15, 300, 75, null);
        } else if(health==8){
            g.drawImage(Assets.HPhearts[7], 15, 15,  300, 75,null);
        } else if(health==7){
            g.drawImage(Assets.HPhearts[6], 15, 15,  300, 75,null);
        } else if(health==6){
            g.drawImage(Assets.HPhearts[5], 15, 15,  300, 75,null);
        } else if(health==5){
            g.drawImage(Assets.HPhearts[4], 15, 15,  300, 75,null);
        } else if(health==4){
            g.drawImage(Assets.HPhearts[3], 15, 15,  300, 75,null);
        } else if(health==3){
            g.drawImage(Assets.HPhearts[2], 15, 15,  300, 75,null);
        } else if(health==2){
            g.drawImage(Assets.HPhearts[1], 15, 15,  300, 75,null);
        } else if(health==1){
            g.drawImage(Assets.HPhearts[0], 15, 15,  300, 75,null);
        } else{
            int scoreHigh = determineHighScore();
            points = endScore;
            health = 0;
            g.drawImage(Assets.gameOverScreen, 0, 0, 1280, 832, null);
            g.drawString("HI-SCORE: " + points, 10, 490);
            g.setFont(new Font("Tahoma", Font.BOLD, 50));
            g.drawString("ALL TIME", 12, 272);
            g.drawString("HI-SCORE: ", 12, 322);
            g.drawString("" + scoreHigh, 12, 372);
            g.setColor(new Color(0, 15, 186));
            g.setFont(new Font("Tahoma", Font.BOLD, 75));
            g.drawString("HI-SCORE: " + points, 20, 500);
            g.setFont(new Font("Tahoma", Font.BOLD, 50));
            g.drawString("ALL TIME", 20, 280);
            g.drawString("HI-SCORE: ", 20, 330);
            g.drawString("" + scoreHigh, 20, 380);
            g.setColor(new Color(0, 20, 255));
            g.setFont(new Font("Tahoma", Font.BOLD, 75));
            g.drawString("HI-SCORE: " + points, 15, 495);
            g.setFont(new Font("Tahoma", Font.BOLD, 50));
            g.drawString("ALL TIME", 15, 275);
            g.drawString("HI-SCORE: ", 15, 325);
            g.drawString("" + scoreHigh, 15, 375);
        }
    }

    private BufferedImage getCurrentAnimationFrame(){
        if(xMove<0){
            sDir = 1;
            return animLeft.getCurrentFrame();
        } else if(xMove>0){
            sDir = 2;
            return animRight.getCurrentFrame();
        } else if(yMove<0){
            sDir = 3;
            return animUp.getCurrentFrame();
        } else if(yMove>0) {
            sDir = 0;
            return animDown.getCurrentFrame();
        } else{
            return Assets.getStandingImage(0, sDir);
        }
    }

    private BufferedImage getCurrentAttackFrame(){
        if(handler.getKeyManager().aUp){
            return Assets.getAttackImage(3);
        }
        if(handler.getKeyManager().aDown){
            return Assets.getAttackImage(2);
        }
        if(handler.getKeyManager().aLeft){
            return Assets.getAttackImage(0);
        }
        if(handler.getKeyManager().aRight){
            return Assets.getAttackImage(1);
        }
        return null;
    }

    public int determineHighScore(){
        // determine the high score
        int highScore = 0;
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Resources/Hi-Score.txt"));
            String line = reader.readLine();
            while (line != null)                 // read the score file line by line
            {
                try {
                    int score = Integer.parseInt(line.trim());   // parse each line as an int
                    if (score > highScore)                       // and keep track of the largest
                    {
                        highScore = score;
                    }
                } catch (NumberFormatException e1) {
                    // ignore invalid scores
                    //System.err.println("ignoring invalid score: " + line);
                }
                line = reader.readLine();
            }
            reader.close();

        } catch (IOException ex) {
            System.err.println("ERROR reading scores from file");
        }

        // display the high score
        /*if (points > highScore)
        {
            System.out.println("You now have the new high score! The previous high score was " + highScore);
        } else if (points == highScore) {
            System.out.println("You tied the high score!");
        } else {
            System.out.println("The all time high score was " + highScore);
        }*/

        // append the last score to the end of the file
        try {
            BufferedWriter output = new BufferedWriter(new FileWriter("Resources/Hi-Score.txt", true));
            output.newLine();
            output.append("" + points);
            output.close();

        } catch (IOException ex1) {
            System.out.printf("ERROR writing score to file: %s\n", ex1);
        }

        return highScore;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public int getHealth() { return health; }

    public float getX(){
        return x;
    }

    public void setX(float x){
        this.x = x;
    }

    public float getY(){
        return y;
    }

    public void setY(float y){
        this.y = y;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public int getCoinCount() {
        return coinCount;
    }

    public void setCoinCount(int coinCount) {
        this.coinCount = coinCount;
    }

    public int getForcePieces() {
        return forcePieces;
    }

    public void setForcePieces(int forcePieces) {
        this.forcePieces = forcePieces;
    }

    public int getMAX_HEALTH() {
        return MAX_HEALTH;
    }

    public void setMAX_HEALTH(int MAX_HEALTH) {
        this.MAX_HEALTH = MAX_HEALTH;
    }

    public int getChemies() {
        return chemies;
    }

    public void setChemies(int chemies) {
        this.chemies = chemies;
    }
    
    public boolean getIsActive(){
        return isActive;
    }
}
import java.awt.*;
import java.util.Random;

public class Tree extends EntityStatic {

    public Tree(Handler handler, float x, float y) {
        super(handler, x, y, Tile.TILEWIDTH*2, Tile.TILEHEIGHT*3);

        bounds.x = 48;
        bounds.y = (int) (height / 1.5f);
        bounds.width = width - 96;
        bounds.height = (int) (height - height / 1.5f);
    }

    @Override
    public void tick() {

    }

    @Override
    public void render(Graphics g) {
        g.drawImage(Assets.tree, (int)(x-handler.getCamera().getxOffset()), (int)(y-handler.getCamera().getyOffset()), width, height, null);
    }

    @Override
    public void die() {
        Random drop = new Random();
        int value = drop.nextInt(10)+1;
        if(value>7){
            handler.getStage().getItemManager().addItem(item.wooditem.createNew((int)x, (int)y));
            handler.getStage().getItemManager().addItem(item.wooditem.createNew((int)x-20, (int)y-20));
            int jigglyCoins = handler.getStage().getEntityManager().getPlayer().getCoinCount();
            handler.getStage().getEntityManager().getPlayer().setCoinCount(jigglyCoins+3);
            int jigglyPoints = handler.getStage().getEntityManager().getPlayer().getPoints();
            handler.getStage().getEntityManager().getPlayer().setPoints(jigglyPoints+3000);
        } else{
            handler.getStage().getItemManager().addItem(item.wooditem.createNew((int)x, (int)y));
            int jigglyCoins = handler.getStage().getEntityManager().getPlayer().getCoinCount();
            handler.getStage().getEntityManager().getPlayer().setCoinCount(jigglyCoins+2);
            int jigglyPoints = handler.getStage().getEntityManager().getPlayer().getPoints();
            handler.getStage().getEntityManager().getPlayer().setPoints(jigglyPoints+2000);
        }
    }
}
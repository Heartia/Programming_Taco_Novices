import java.awt.*;

public class Text_1 {
    public static void drawString(Graphics g, String text, int xPos, int yPos, Color c){
        g.setColor(c);
        g.setFont(new Font("TimesRoman", Font.BOLD, 50));
        int x = xPos;
        int y = yPos;
        g.drawString(text, x, y);
    }
}

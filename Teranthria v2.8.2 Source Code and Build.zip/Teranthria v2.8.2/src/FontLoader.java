import java.awt.*;
import java.io.File;
import java.io.IOException;

public class FontLoader {
    public static Font loadFont(String path, float size){
        return Font.getFont("Helvetica");
    }
}
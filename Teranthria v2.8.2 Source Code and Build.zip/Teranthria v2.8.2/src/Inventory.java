import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

public class Inventory {
    private int invX = 100, invY = 100, invWidth = 1080, invHeight = 632,
            invListCenterX = invX + 171, invListCenterY = invY + invHeight / 2 + 15,
            invListSpacing = 65;

    private int invImageX = 452, invImageY = 82,
            invImageWidth = 64, invImageHeight = 64;

    private int invCountX = 484, invCountY = 172;

    private int selectedItem = 0;

    private Handler handler;
    private boolean active = false;
    private ArrayList<item> inventoryItems;

    public Inventory(Handler handler){
        this.handler = handler;
        inventoryItems = new ArrayList<>();

        //addItem(Item.rockItem.createNew(5));
    }

    public void tick() {
        if (handler.getKeyManager().keyJustPressed(KeyEvent.VK_I)) {
            active = !active;
        }
        if (!active) {
            return;
        }

        System.out.println("INVENTORY:");
        for(item i : inventoryItems){
            System.out.println(i.getName() + " " + i.getCount());
        }
    }

    public void render(Graphics g){
        if(!active){
            return;
        } g.drawImage(Assets.inventoryScreen, invX, invY, invWidth, invHeight, null);

        int len = inventoryItems.size();
        if(len == 0){
            return;
        } /**for(int i = 0; i<3; i++){
            if(selectedItem + 1<0||selectedItem + 1>=len){
                continue;
            }
            Text.drawString(g, inventoryItems.get(selectedItem + i).getName(), invListCenterX, invListCenterY + i * invListSpacing, Color.WHITE);
        }*/
        for(item i : inventoryItems){
            Text_1.drawString(g, inventoryItems.get(selectedItem).getName(), invListCenterX, invListCenterY + invListSpacing, Color.WHITE);
        }
    }

    //Methods of the tory's inven

    public void addItem(item item){
        for(item i : inventoryItems){
            if(i.getId()==item.getId()){
                i.setCount(i.getCount() + item.getCount());
                return;
            }
        } inventoryItems.add(item);
    }

    //GETTIES N SETTIES

    public Handler getHandler() {
        return handler;
    }

    public void setHandler(Handler handler) {
        this.handler = handler;
    }
}
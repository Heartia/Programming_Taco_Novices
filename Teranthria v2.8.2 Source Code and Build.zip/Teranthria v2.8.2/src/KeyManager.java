import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyManager implements KeyListener {

    private boolean[] keys, justPressed, cantPress;
    public boolean up, down, left, right;
    public boolean aUp, aDown, aLeft, aRight;
    public boolean rUp, rDown, rLeft, rRight;
    public boolean bAtk, aAtk, pHeal, xChoose;
    public boolean restart, pause;

    public KeyManager(){
        keys = new boolean[256];
        justPressed = new boolean[keys.length];
        cantPress = new boolean[keys.length];
    }

    public boolean keyJustPressed(int keyCode){
        if(keyCode<0||keyCode>=keys.length){
            return false;
        } return justPressed[keyCode];
    }

    public void tick(){
        for(int i = 0; i < keys.length; i++){
            if(cantPress[i]&&!keys[i]){
                cantPress[i] = false;
            } else if(justPressed[i]){
                cantPress[i] = true;
                justPressed[i] = false;
            } if(!cantPress[i]&&keys[i]){
                justPressed[i] = true;
            }
        }

        up = keys[KeyEvent.VK_W]||keys[KeyEvent.VK_UP];
        down = keys[KeyEvent.VK_S]||keys[KeyEvent.VK_DOWN];
        left = keys[KeyEvent.VK_A]||keys[KeyEvent.VK_LEFT];
        right = keys[KeyEvent.VK_D]||keys[KeyEvent.VK_RIGHT];

        rUp = (keys[KeyEvent.VK_W]||keys[KeyEvent.VK_UP])&&keys[KeyEvent.VK_Z];
        rDown = (keys[KeyEvent.VK_S]||keys[KeyEvent.VK_DOWN])&&keys[KeyEvent.VK_Z];
        rLeft = (keys[KeyEvent.VK_A]||keys[KeyEvent.VK_LEFT])&&keys[KeyEvent.VK_Z];
        rRight = (keys[KeyEvent.VK_D]||keys[KeyEvent.VK_RIGHT])&&keys[KeyEvent.VK_Z];

        aUp = keys[KeyEvent.VK_T];
        aDown = keys[KeyEvent.VK_G];
        aLeft = keys[KeyEvent.VK_F];
        aRight = keys[KeyEvent.VK_H];

        bAtk = keys[KeyEvent.VK_2]||keys[KeyEvent.VK_NUMPAD2];
        aAtk = keys[KeyEvent.VK_1]||keys[KeyEvent.VK_NUMPAD1];
        pHeal = keys[KeyEvent.VK_3]||keys[KeyEvent.VK_NUMPAD3];
        xChoose = keys[KeyEvent.VK_X];

        restart = keys[KeyEvent.VK_P];
        pause = keys[KeyEvent.VK_R];
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode()<0||e.getKeyCode()>=keys.length){
            return;
        }
        keys[e.getKeyCode()] = true;
    }

    @Override
    public void keyReleased(KeyEvent e) {
        keys[e.getKeyCode()] = false;
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

}
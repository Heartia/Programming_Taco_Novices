public class TileWoodBridge extends Tile {
    public TileWoodBridge(int id) {
        super(Assets.woodbridge, id);
    }
}
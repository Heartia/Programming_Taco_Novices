public class TileCliffRight extends Tile {
    public TileCliffRight(int id) {
        super(Assets.cliffright, id);
    }

    @Override
    public boolean isSolid(){
        return true;
    }
}
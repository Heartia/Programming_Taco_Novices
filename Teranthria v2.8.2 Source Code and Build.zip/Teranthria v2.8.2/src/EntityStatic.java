public abstract class EntityStatic extends Entity {
    public EntityStatic(Handler handler, float x, float y, int width, int height){
        super(handler, x, y, width, height);
    }
}
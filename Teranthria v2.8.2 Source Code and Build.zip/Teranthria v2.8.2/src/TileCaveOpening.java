public class TileCaveOpening extends Tile {
    public TileCaveOpening(int id) {
        super(Assets.caveopening, id);
    }

    @Override
    public boolean isSolid(){
        return true;
    }
}
public class TileCliffDown extends Tile {
    public TileCliffDown(int id) {
        super(Assets.cliffdown, id);
    }

    @Override
    public boolean isSolid(){
        return true;
    }
}
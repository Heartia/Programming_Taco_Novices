import java.awt.*;
import java.util.Random;

public class Stage {
    private long lastAttackTimer, attackCooldown = 15000, attackTimer = attackCooldown;

    private Handler handler;
    private int width, height;
    private int spawnX, spawnY;
    private int[][] tiles;
    //Entities
    private EntityManager entityManager;

    //Items
    private ItemManager itemManager;

    private int bossCount;

    //Respawning of entities
    private Random randX = new Random();
    private Random randY = new Random();
    private Random randA1 = new Random();
    private Random randA2 = new Random();
    private Random randType = new Random();
    private int count = 0;

    private String stageString;

    private int spawnCount = 3;
    private int enemiesSpawn = 0;

    public Stage(Handler handler, String path){
        this.handler = handler;
        entityManager = new EntityManager(handler, new Player(handler, 100, 100));
        itemManager = new ItemManager(handler);

        int ra2 = randA2.nextInt(5)+10;

        for(int i = 0; i<ra2; i++){
            int rx = randX.nextInt(2560)+1;
            int ry = randY.nextInt(2496)+1;
            entityManager.addEntity(new Tree(handler, rx, ry));
            rx = randX.nextInt(2560)+1;
            ry = randY.nextInt(2496)+1;
            entityManager.addEntity(new Rock(handler, rx, ry));
        }

        loadStage(path);

        entityManager.getPlayer().setX(spawnX);
        entityManager.getPlayer().setY(spawnY);
    }

    public void tick(){
        itemManager.tick();
        entityManager.tick();
        respawn();
    }

    public void render(Graphics g){
        int xStart = (int) Math.max(0, handler.getCamera().getxOffset() / Tile.TILEWIDTH);
        int xEnd = (int) Math.min(width, (handler.getCamera().getxOffset() + handler.getWidth()) / Tile.TILEWIDTH +1);
        int yStart = (int) Math.max(0, handler.getCamera().getyOffset()/ Tile.TILEHEIGHT);
        int yEnd = (int) Math.min(width, (handler.getCamera().getyOffset() + handler.getHeight()) / Tile.TILEHEIGHT +1);;

        for(int y = yStart; y<yEnd-1; y++){
            for(int x = xStart; x<xEnd; x++){
                getTile(x, y).render(g, (int)(x * Tile.TILEWIDTH - handler.getCamera().getxOffset()),
                        (int)(y * Tile.TILEHEIGHT - handler.getCamera().getyOffset()));
            }
        }
        //ITEMIES
        itemManager.render(g);
        //ENTITIES
        entityManager.render(g);
    }

    public void respawn(){
        if(count>30){
            return;
        }
        attackTimer += System.currentTimeMillis() - lastAttackTimer;
        lastAttackTimer = System.currentTimeMillis();
        if(attackTimer<attackCooldown){
            return;
        }

        int ra = randA1.nextInt(4)+spawnCount;
        if(enemiesSpawn>=12){
            spawnCount++;
            enemiesSpawn = 0;
        }

        for(int i = 0; i<ra; i++) {
            int rx = randX.nextInt(2560) + 1;
            int ry = randY.nextInt(2496) + 1;
            int rt = randType.nextInt(6)+1;
            switch (rt) {
                case 1:
                    entityManager.addEntity(new Ant(handler, rx, ry, entityManager.getPlayer()));
                    enemiesSpawn++;
                    break;
                case 2:
                    entityManager.addEntity(new Bee(handler, rx, ry, entityManager.getPlayer()));
                    enemiesSpawn++;
                    break;
                case 3:
                    entityManager.addEntity(new Beetle(handler, rx, ry, entityManager.getPlayer()));
                    enemiesSpawn++;
                    break;
                case 4:
                    entityManager.addEntity(new Fly(handler, rx, ry, entityManager.getPlayer()));
                    enemiesSpawn++;
                    break;
                case 5:
                    entityManager.addEntity(new Mosquito(handler, rx, ry, entityManager.getPlayer()));
                    enemiesSpawn++;
                    break;
                case 6:
                    entityManager.addEntity(new Ladybird(handler, rx, ry, entityManager.getPlayer()));
                    enemiesSpawn++;
                    break;
                default:
                    entityManager.addEntity(new Ant(handler, rx, ry, entityManager.getPlayer()));
                    break;
            }
            count++;
        }
        if(this.getEntityManager().getPlayer().getPoints() > 50000 && bossCount == 0){
            entityManager.addEntity(new AntBoss(handler, 1280, 832, entityManager.getPlayer()));
                for(int i = 0; i<3; i++){
                    int rx = randX.nextInt(2560)+1;
                    int ry = randY.nextInt(2496)+1;
                    entityManager.addEntity(new Tree(handler, rx, ry));
                    rx = randX.nextInt(2560)+1;
                    ry = randY.nextInt(2496)+1;
                    entityManager.addEntity(new Rock(handler, rx, ry));
                }
            bossCount++;
        }

        if(this.getEntityManager().getPlayer().getPoints() > 100000 && bossCount == 1){
            entityManager.addEntity(new AntBoss(handler, 1280, 832, entityManager.getPlayer()));
            for(int i = 0; i<3; i++){
                int rx = randX.nextInt(2560)+1;
                int ry = randY.nextInt(2496)+1;
                entityManager.addEntity(new Tree(handler, rx, ry));
                rx = randX.nextInt(2560)+1;
                ry = randY.nextInt(2496)+1;
                entityManager.addEntity(new Rock(handler, rx, ry));
            }
            bossCount++;
        }

        if(this.getEntityManager().getPlayer().getPoints() > 150000 && bossCount == 2){
            entityManager.addEntity(new AntBoss(handler, 1280, 832, entityManager.getPlayer()));
            for(int i = 0; i<3; i++){
                int rx = randX.nextInt(2560)+1;
                int ry = randY.nextInt(2496)+1;
                entityManager.addEntity(new Tree(handler, rx, ry));
                rx = randX.nextInt(2560)+1;
                ry = randY.nextInt(2496)+1;
                entityManager.addEntity(new Rock(handler, rx, ry));
            }
            bossCount++;
        }

        if(this.getEntityManager().getPlayer().getPoints() > 200000 && bossCount == 3){
            entityManager.addEntity(new AntBoss(handler, 1280, 832, entityManager.getPlayer()));
            for(int i = 0; i<3; i++){
                int rx = randX.nextInt(2560)+1;
                int ry = randY.nextInt(2496)+1;
                entityManager.addEntity(new Tree(handler, rx, ry));
                rx = randX.nextInt(2560)+1;
                ry = randY.nextInt(2496)+1;
                entityManager.addEntity(new Rock(handler, rx, ry));
            }
            bossCount++;
        }

        if(this.getEntityManager().getPlayer().getPoints() > 250000 && bossCount == 4){
            entityManager.addEntity(new AntBoss(handler, 1280, 832, entityManager.getPlayer()));
            for(int i = 0; i<3; i++){
                int rx = randX.nextInt(2560)+1;
                int ry = randY.nextInt(2496)+1;
                entityManager.addEntity(new Tree(handler, rx, ry));
                rx = randX.nextInt(2560)+1;
                ry = randY.nextInt(2496)+1;
                entityManager.addEntity(new Rock(handler, rx, ry));
            }
            bossCount++;
        }
        
        if(this.getEntityManager().getPlayer().getPoints() > 50000 && bossCount == 5){
            entityManager.addEntity(new AntBoss(handler, 1280, 832, entityManager.getPlayer()));
                for(int i = 0; i<3; i++){
                    int rx = randX.nextInt(2560)+1;
                    int ry = randY.nextInt(2496)+1;
                    entityManager.addEntity(new Tree(handler, rx, ry));
                    rx = randX.nextInt(2560)+1;
                    ry = randY.nextInt(2496)+1;
                    entityManager.addEntity(new Rock(handler, rx, ry));
                }
            bossCount++;
        }

        if(this.getEntityManager().getPlayer().getPoints() > 550000 && bossCount == 6){
            entityManager.addEntity(new AntBoss(handler, 1280, 832, entityManager.getPlayer()));
            for(int i = 0; i<3; i++){
                int rx = randX.nextInt(2560)+1;
                int ry = randY.nextInt(2496)+1;
                entityManager.addEntity(new Tree(handler, rx, ry));
                rx = randX.nextInt(2560)+1;
                ry = randY.nextInt(2496)+1;
                entityManager.addEntity(new Rock(handler, rx, ry));
            }
            bossCount++;
        }

        if(this.getEntityManager().getPlayer().getPoints() > 600000 && bossCount == 7){
            entityManager.addEntity(new AntBoss(handler, 1280, 832, entityManager.getPlayer()));
            for(int i = 0; i<3; i++){
                int rx = randX.nextInt(2560)+1;
                int ry = randY.nextInt(2496)+1;
                entityManager.addEntity(new Tree(handler, rx, ry));
                rx = randX.nextInt(2560)+1;
                ry = randY.nextInt(2496)+1;
                entityManager.addEntity(new Rock(handler, rx, ry));
            }
            bossCount++;
        }

        if(this.getEntityManager().getPlayer().getPoints() > 650000 && bossCount == 8){
            entityManager.addEntity(new AntBoss(handler, 1280, 832, entityManager.getPlayer()));
            for(int i = 0; i<3; i++){
                int rx = randX.nextInt(2560)+1;
                int ry = randY.nextInt(2496)+1;
                entityManager.addEntity(new Tree(handler, rx, ry));
                rx = randX.nextInt(2560)+1;
                ry = randY.nextInt(2496)+1;
                entityManager.addEntity(new Rock(handler, rx, ry));
            }
            bossCount++;
        }

        if(this.getEntityManager().getPlayer().getPoints() > 700000 && bossCount == 9){
            entityManager.addEntity(new AntBoss(handler, 1280, 832, entityManager.getPlayer()));
            for(int i = 0; i<3; i++){
                int rx = randX.nextInt(2560)+1;
                int ry = randY.nextInt(2496)+1;
                entityManager.addEntity(new Tree(handler, rx, ry));
                rx = randX.nextInt(2560)+1;
                ry = randY.nextInt(2496)+1;
                entityManager.addEntity(new Rock(handler, rx, ry));
            }
            bossCount++;
        }

        attackTimer = 0;
    }

    public Tile getTile(int x, int y){
        Tile t = Tile.tiles[tiles[x][y]];
        if(x < 0 || y < 0 || x >= width || y >= height){
            return Tile.grassTile;
        }

        if(t==null){
            return Tile.grassTile;
        }

        return t;
    }

    public void loadStage(String path){
//        System.out.println("loadStage()");
//        StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
//        for(StackTraceElement s : stackTraceElements) {
//            System.out.println(s);
//        }
        String file = Utilities.loadFileAsString(path);
        String[] tokens = file.split("\\s+");
        width = Utilities.parseInt(tokens[0]);
        height = Utilities.parseInt(tokens[1]);
        spawnX = Utilities.parseInt(tokens[2]);
        spawnY = Utilities.parseInt(tokens[3]);
        String s = "loadStage:\n";
        tiles = new int[width][height];
        for(int y = 0; y<height; y++){
            for(int x = 0; x<width; x++){
                tiles[x][y] = Utilities.parseInt(tokens[(x + y * width) + 4]);
                s += tiles[x][y] + " ";
            }
            s += "\n";
        }

        stageString = s;
        //System.out.println(s);
    }

    public String getStageString() {
        return stageString;
    }

    public void generateStage(){
        Random r = new Random();
        int index = 0;
        for(int x = 0; x<width; x++){
            for(int y = 0; y<height; y++){
                index = r.nextInt(4);

                if(index == 0){
                    tiles[x][y] = 0;
                } else if(index == 1){
                    tiles[x][y] = 1;
                } else if(index == 2){
                    tiles[x][y] = 2;
                } else if(index == 3){
                    tiles[x][y] = 3;
                } else if(index == 5){
                    tiles[x][y] = 5;
                } else if(index == 10){
                    tiles[x][y] = 10;
                } else if(index == 11){
                    tiles[x][y] = 11;
                } else if(index == 12){
                    tiles[x][y] = 12;
                } else if(index == 13){
                    tiles[x][y] = 13;
                } else if(index == 14){
                    tiles[x][y] = 14;
                } else if(index == 15){
                    tiles[x][y] = 15;
                } else if(index == 16){
                    tiles[x][y] = 16;
                } else if(index == 17){
                    tiles[x][y] = 17;
                } else if(index == 18){
                    tiles[x][y] = 18;
                } else if(index == 19){
                    tiles[x][y] = 19;
                } else if(index == 20){
                    tiles[x][y] = 20;
                } else if(index == 21){
                    tiles[x][y] = 21;
                } else if(index == 22){
                    tiles[x][y] = 22;
                } else if(index == 23){
                    tiles[x][y] = 23;
                } else{
                    tiles[x][y] = 0;
                }
            }
        }
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public ItemManager getItemManager() {
        return itemManager;
    }

    public void setItemManager(ItemManager itemManager) {
        this.itemManager = itemManager;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
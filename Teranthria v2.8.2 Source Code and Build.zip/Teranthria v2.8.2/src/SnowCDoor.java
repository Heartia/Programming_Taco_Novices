public class SnowCDoor extends Tile {
    public SnowCDoor(int id) {super(Assets.closeDoor, id);}

    @Override
    public boolean isSolid() {return true;}
}
public class SnowRight extends Tile {
    public SnowRight(int id) {super(Assets.snowRight, id);}

    @Override
    public boolean isSolid() {
        return true;
    }
}
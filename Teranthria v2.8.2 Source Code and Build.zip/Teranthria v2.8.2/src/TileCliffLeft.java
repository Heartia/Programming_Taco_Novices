public class TileCliffLeft extends Tile {
    public TileCliffLeft(int id) {
        super(Assets.cliffleft, id);
    }

    @Override
    public boolean isSolid(){
        return true;
    }
}
public class TileCliffUp extends Tile {
    public TileCliffUp(int id) {
        super(Assets.cliffup, id);
    }

    @Override
    public boolean isSolid(){
        return true;
    }
}
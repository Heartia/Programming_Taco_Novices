// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    document.getElementById("myBtn").style.display = "block";
  } else {
    document.getElementById("myBtn").style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0; // For Safari
  document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
}

/*************************************************************************** */

var endDate = new Date("May 27, 2021 12:05:00").getTime();
var timer = setInterval(function() {
    let now = new Date().getTime();
    let t = endDate - now;

    if (t >= 0) {
        let months = Math.floor(t / (1000 * 60 * 60 * 24 * 30.48333));
        let weeks = Math.floor(t / (1000 * 60 * 60 * 24 * 7));
        let days = Math.floor(t / ((1000 * 60 * 60 * 24)));
        let hours = Math.floor((t % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        let mins = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
        let secs = Math.floor((t % (1000 * 60)) / 1000);

        document.getElementById("timer-months").innerHTML = months + 
            " <span class='label'>Month(s)</span>";

        document.getElementById("timer-weeks").innerHTML = ("0" + weeks).slice(-2) + 
            " <span class='label'>Week(s)</span>";

        document.getElementById("timer-days").innerHTML = ("0" + days).slice(-2) + 
            " <span class='label'>Day(s)</span>";

        document.getElementById("timer-hours").innerHTML= ("0" + hours).slice(-2) +
            " <span class='label'>Hr(s)</span>";

        document.getElementById("timer-mins").innerHTML= ("0" + mins).slice(-2) +
            " <span class='label'>Min(s)</span>";

        document.getElementById("timer-secs").innerHTML= ("0" + secs).slice(-2) +
            " <span class='label'>Sec(s)</span>";
    }
    else {
        document.getElementById("timer").innerHTML = "The countdown is over! I have graduated high school! Now for a timer for college.";
    }
}, 1000);

import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 153732
 */
public class JumperBug extends Bug {
    public JumperBug() {
        
    }
    
    @Override
    public void act()
    {
        if (canJump()) jump();
        else if (canMoveTwice()) moveDouble();
        else if (canMove()) move();
        else turn();
    }
    
    @Override
    public void move()
    {
        Grid<Actor> gr = getGrid();
        if (gr == null) {
            return;
        }
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        if (gr.isValid(next)) moveTo(next);
    }
    
    public void moveDouble()
    {
        move();
        move();
    }
    
    public void jump()
    {
        Grid<Actor> gr = getGrid();
        if (gr == null) {
            turn();
            return;
        }
        Location loc = getLocation();
        int dir = getDirection();
        loc = loc.getAdjacentLocation(dir);
        loc = loc.getAdjacentLocation(dir);
        if (!gr.isValid(loc)) {
            turn();
            return;
        }
        moveTo(loc);
    }
    
    public boolean canJump()
    {
        Grid<Actor> gr = getGrid();
        if (gr == null) {
            return false;
        }
        Location loc = getLocation();
        int dir = getDirection();
        loc = loc.getAdjacentLocation(dir);
        Location next = loc.getAdjacentLocation(dir);
        if (!gr.isValid(loc) && !gr.isValid(next)) {
            return false;
        }
        Actor neighbour = gr.get(loc);
        return (neighbour instanceof Flower) || (neighbour instanceof Rock);
    }
    
    public boolean canMoveTwice()
    {
        Grid<Actor> gr = getGrid();
        if (gr == null) {
            return false;
        }
        Location loc = getLocation();
        int dir = getDirection();
        loc = loc.getAdjacentLocation(dir);
        loc = loc.getAdjacentLocation(dir);
        if (!gr.isValid(loc)) {
            return false;
        }
        Actor neighbour = gr.get(loc);
        return neighbour == null;
    }
}

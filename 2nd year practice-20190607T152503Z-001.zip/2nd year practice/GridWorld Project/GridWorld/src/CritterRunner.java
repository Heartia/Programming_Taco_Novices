
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Rock;
import java.awt.Color;
import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 153732
 */
public class CritterRunner {
    public static void main(String[] args) {
        Random r = new Random();
        ActorWorld world = new ActorWorld();
        
        /*BoxBug box = new BoxBug(5);
        box.setColor(Color.YELLOW);
        world.add(box);
        
        CircleBug circle = new CircleBug(5);
        circle.setColor(Color.BLUE);
        world.add(circle);
        
        DancingBug dancer = new DancingBug(5, new int[]{r.nextInt(10), r.nextInt(10), r.nextInt(10), r.nextInt(10)});
        dancer.setColor(Color.GREEN);
        world.add(dancer);
        
        SpiralBug spiral = new SpiralBug(5);
        spiral.setColor(Color.RED);
        world.add(spiral);
        
        ZBug zMover = new ZBug(5, 5);
        spiral.setColor(Color.ORANGE);
        world.add(zMover);*/
        
        PolyBug poly = new PolyBug(5, 5);
        poly.setColor(Color.MAGENTA);
        world.add(poly);
        
        world.add(new ChameleonCritter());
        world.add(new ChameleonKid());
        world.add(new RockHound());
        world.add(new BlusterCritter(2));
        world.add(new CrabCritter());
        world.add(new QuickCrab());
        world.add(new KingCrab());
        
        for (int i = 0; i < 10; i++) {
            world.add(new ChameleonCritter());
        }
        
        world.show();
    }
}

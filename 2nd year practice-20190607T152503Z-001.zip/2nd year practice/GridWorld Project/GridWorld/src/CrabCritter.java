
import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import java.awt.Color;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 153732
 */
public class CrabCritter extends Critter {
    
    public CrabCritter() {
        setColor(Color.RED);
    }
    
    
    @Override
    public ArrayList<Actor> getActors() {
        ArrayList<Actor> actors = new ArrayList<>();
        int[] dirs = {Location.AHEAD, Location.HALF_LEFT, Location.HALF_RIGHT};
        
        for (Location loc : getLocationsInDirections(dirs)) {
            Actor a = getGrid().get(loc);
            if (a != null) actors.add(a);
        }
        
        return actors;
    }

    @Override
    public ArrayList<Location> getMoveLocations() {
        ArrayList<Location> locs = new ArrayList<>();
        int[] dirs = {Location.LEFT, Location.RIGHT};
        for (Location loc : getLocationsInDirections(dirs)) {
            if (getGrid().get(loc) == null) locs.add(loc);
        }
        
        return locs;
    }
    
    @Override
    public void makeMove(Location loc) {
        if (loc.equals(getLocation())) {
            double r = Math.random();
            int angle;
            if (r < 0.5) angle = Location.LEFT;
            else angle = Location.RIGHT;
            setDirection(getDirection() + angle);
        }
        else super.makeMove(loc);
    }
    
    public ArrayList<Location> getLocationsInDirections(int[] directions) {
        ArrayList<Location> locs = new ArrayList<>();
        Grid gr = getGrid();
        Location loc = getLocation();
        for (int d : directions) {
            Location neighbourLoc = loc.getAdjacentLocation(getDirection() + d);
            if (gr.isValid(neighbourLoc)) locs.add(neighbourLoc);
        }
        return locs;
    }
    
}

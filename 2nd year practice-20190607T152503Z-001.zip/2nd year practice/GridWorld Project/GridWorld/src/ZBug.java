import info.gridworld.actor.Bug;

public class ZBug extends Bug {
    
    private int sideLength;
    private int zLength;
    private int steps;
    private int moveAmount;
    private boolean zTurning, moving;
    
    public ZBug(int length, int zLength) {
        steps = 0;
        sideLength = length;
        this.zLength = zLength;
        zTurning = false;
        moveAmount = 0;
    }
    
    @Override
    public void act()
    {
        while (moveAmount < 3) {
            if (!zTurning) {
                if (getDirection() != 90) {
                    turn();
                    return;
                }
                if (steps != sideLength && canMove()) {
                    move();
                    steps++;
                    return;
                }
                zTurning = true;
                steps = 1;
                moveAmount++;
            }
            else {
                if (getDirection() != 225) {
                    turn();
                    return;
                }
                if (steps != zLength && canMove()) {
                    move();
                    steps++;
                    return;
                }
                zTurning = false;
                steps = 0;
                moveAmount++;
            }
        }
    }
    
    /*@Override
    public void act()
    {
        while (getDirection() % 360 != 90) {
            turn();
        }
        while (steps != sideLength && canMove()) {
            move();
            steps++;
        }
        steps = 0;
        while (getDirection() % 360 != 225) {
            turn();
        }
        while (steps != zLength && canMove()) {
            move();
            steps++;
        }
        steps = 0;
        while (getDirection() % 360 != 90) {
            turn();
        }
        while (steps != sideLength && canMove()) {
            move();
            steps++;
        }
    }*/
}
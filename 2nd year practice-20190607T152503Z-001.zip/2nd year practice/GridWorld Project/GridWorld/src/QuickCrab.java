
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import java.awt.Color;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 153732
 */
public class QuickCrab extends CrabCritter {
    
    public QuickCrab() {
        setColor(Color.PINK);
    }
    
    @Override
    public ArrayList<Location> getLocationsInDirections(int[] directions) {
        ArrayList<Location> locs = new ArrayList<>();
        Grid gr = getGrid();
        Location loc = getLocation();
        for (int d : directions) {
            Location neighbourLoc = loc.getAdjacentLocation(getDirection() + d);
            Location bigNeighbourLoc = neighbourLoc.getAdjacentLocation(getDirection() + d);
            if ((gr.isValid(bigNeighbourLoc)) && gr.get(neighbourLoc) == null) locs.add(bigNeighbourLoc);
        }
        return locs;
    }
    
}

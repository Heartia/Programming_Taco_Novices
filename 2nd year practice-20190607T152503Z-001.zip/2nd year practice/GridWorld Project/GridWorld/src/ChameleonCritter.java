
import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 153732
 */
public class ChameleonCritter extends Critter {
    
    @Override
    public void processActors(ArrayList<Actor> actors) {
        int n = actors.size();
        if (n <= 0) {
            setColor(getColor().darker());
            return;
        }
        int r = (int) (Math.random() * n);
        
        Actor other = actors.get(r);
        setColor(other.getColor());
    }
    
    @Override
    public void makeMove(Location loc) {
        setDirection(getLocation().getDirectionToward(loc));
        super.makeMove(loc);
    }
    
}


import info.gridworld.actor.Actor;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 153732
 */
public class ChameleonKid extends ChameleonCritter {
    
    @Override
    public void processActors(ArrayList<Actor> actors) {
        Grid<Actor> gr = getGrid();
        if (gr == null) {
            setColor(getColor().darker());
            return;
        }
        
        Location front = getLocation().getAdjacentLocation(getDirection());
        Location behind = getLocation().getAdjacentLocation(-getDirection());
        
        if (gr.isValid(front)) {
            Actor other = gr.get(front);
            if (other != null) {
                setColor(other.getColor());
            }
            else {
                setColor(getColor().darker());
            }
        }
        else if (gr.isValid(behind)) {
            Actor other = gr.get(behind);
            if (other != null) {
                setColor(other.getColor());
            }
            else {
                setColor(getColor().darker());
            }
        }
    }
    
}

import info.gridworld.actor.Bug;

public class CircleBug extends Bug {
    
    private int sideLength;
    private int steps;
    private int turnAmount;
    
    public CircleBug(int length) {
        steps = 0;
        turnAmount = 1;
        sideLength = length;
    }
    
    @Override
    public void act()
    {
        if (steps < sideLength && canMove()) {
            move();
            steps++;
        }
        else
        {
            for (int i = 0; i < turnAmount; i++) { turn(); }
            steps = 0;
        }
    }
}
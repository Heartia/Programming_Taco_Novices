import info.gridworld.actor.Bug;

public class DancingBug extends Bug {
    
    private int sideLength;
    private int steps;
    private int turnAmount;
    private int index;
    private int[] turns = new int[]{};
    
    public DancingBug(int length, int[] turns) {
        turnAmount = 0;
        sideLength = length;
        steps = 0;
        index = 0;
        this.turns = turns;
    }
    
    @Override
    public void act() {
        if (index + 1 >= turns.length) {
            index = 0;
        }
        for (int t = 0; t < turns[index]; t++) {
            turn();
        }
        index++;
        while (canMove() && steps < sideLength) {
            move();
            steps++;
            return;
        }
        steps = 0;
    }
}
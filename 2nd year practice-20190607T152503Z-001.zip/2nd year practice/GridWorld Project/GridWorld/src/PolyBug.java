import info.gridworld.actor.Bug;

public class PolyBug extends Bug {
    
    private int sideLength;
    private int steps;
    private int turnAmount;
    
    public PolyBug(int length) {
        steps = 0;
        turnAmount = 2;
        sideLength = length;
    }
    
    public PolyBug(int length, int turns) {
        steps = 0;
        turnAmount = turns;
        sideLength = length;
    }
    
    public void setTurns(int turns) {
        turnAmount = turns;
    }
    
    @Override
    public void act()
    {
        if (steps < sideLength && canMove()) {
            move();
            steps++;
        }
        else
        {
            for (int i = 0; i < turnAmount; i++) { turn(); }
            steps = 0;
        }
    }
}
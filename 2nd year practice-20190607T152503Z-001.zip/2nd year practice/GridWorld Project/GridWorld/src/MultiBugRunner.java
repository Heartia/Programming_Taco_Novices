import info.gridworld.actor.Actor;
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;

import java.awt.Color;
import java.util.Random;

/**
 * This class runs a world that contains box bugs.
 * This class is not tested on the AP CS A and AB exams.
 */

public class MultiBugRunner {
    public static void main(String[] args) {
        Random r = new Random();
        ActorWorld world = new ActorWorld();
        
        BoxBug box = new BoxBug(5);
        box.setColor(Color.YELLOW);
        world.add(box);
        
        CircleBug circle = new CircleBug(5);
        circle.setColor(Color.BLUE);
        world.add(circle);
        
        DancingBug dancer = new DancingBug(5, new int[]{r.nextInt(10), r.nextInt(10), r.nextInt(10), r.nextInt(10)});
        dancer.setColor(Color.GREEN);
        world.add(dancer);
        
        SpiralBug spiral = new SpiralBug(5);
        spiral.setColor(Color.RED);
        world.add(spiral);
        
        ZBug zMover = new ZBug(5, 5);
        spiral.setColor(Color.ORANGE);
        world.add(zMover);
        
        PolyBug poly = new PolyBug(5, 5);
        poly.setColor(Color.MAGENTA);
        world.add(poly);
        
        world.add(new Rock());
        
        world.show();
    }
}
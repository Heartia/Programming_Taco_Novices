
import info.gridworld.actor.Actor;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import java.awt.Color;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 153732
 */
public class KingCrab extends CrabCritter {
    
    /*
    * A KingCrab causes each actor that it processes to move one
    * location further away from the KingCrab. If the actor cannot
    * move away, the KingCrab consumes the actor.
    *
    * Once the KingCrab finished processing all the actors, it move
    * like a CrabCritter.
    */
    
    public KingCrab() {
        setColor(Color.ORANGE);
    }
    
    @Override
    public ArrayList<Actor> getActors() {
        ArrayList<Actor> actors = new ArrayList<>();
        int[] dirs = {Location.AHEAD, Location.HALF_LEFT, Location.HALF_RIGHT};
        
        for (Location loc : getLocationsInDirections(dirs)) {
            Actor a = getGrid().get(loc);
            if (a != null) actors.add(a);
        }
        
        return actors;
    }
    
    public boolean processActors() {
        if (getActors().size() > 0) {
            for (Actor a : getActors()) {
                Grid gr = getGrid();
                Location loc = a.getLocation();
                Location king = getLocation();
                int dir = king.getDirectionToward(loc);
                Location next = loc.getAdjacentLocation(dir);
                if (gr.isValid(next) && gr.get(next) == null) {
                    a.moveTo(next);
                }
                else {
                    a.removeSelfFromGrid();
                }
            }
            return true;
        }
        return false;
    }
    
    @Override
    public void makeMove(Location loc) {
        if (!processActors()) {
            super.makeMove(loc);
        }
    }
    
}

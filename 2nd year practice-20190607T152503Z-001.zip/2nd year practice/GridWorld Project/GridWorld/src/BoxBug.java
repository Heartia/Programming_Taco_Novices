import info.gridworld.actor.Bug;

public class BoxBug extends Bug {
    
    private int sideLength;
    private int steps;
    private int turnAmount;
    
    public BoxBug(int length) {
        steps = 0;
        turnAmount = 2;
        sideLength = length;
    }
    
    @Override
    public void act()
    {
        if (steps < sideLength && canMove()) {
            move();
            steps++;
        }
        else
        {
            for (int i = 0; i < turnAmount; i++) { turn(); }
            steps = 0;
        }
    }
}

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 153732
 */
public class BlusterCritter extends Critter {
    
    private final int critterCap;
    
    public BlusterCritter(int critterCap) {
        this.critterCap = critterCap;
    }
    
    @Override
    public void processActors(ArrayList<Actor> actors) {
        Grid<Actor> gr = getGrid();
        if (gr == null) {
            setColor(getColor().brighter());
            return;
        }
        Location loc = getLocation();
        if (getOccupiedLocationsNum(loc) >= critterCap) {
            setColor(getColor().darker());
        }
        else {
            setColor(getColor().brighter());
        }
    }
    
    private int getOccupiedLocationsNum(Location loc) {
        int locationNum = 0;
        Grid<Actor> gr = getGrid();
        ArrayList<Location> locs = gr.getOccupiedAdjacentLocations(loc);
        for (Location loca : locs) {
            ArrayList<Location> locas = gr.getOccupiedAdjacentLocations(loca);
            for (Location location : locas) {
                Actor other = gr.get(location);
                if (other != null && other != this) locationNum++;
            }
        }
        return locationNum;
    }
    
    @Override
    public void makeMove(Location loc) {
        setDirection(getLocation().getDirectionToward(loc));
        super.makeMove(loc);
    }
    
}


import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 153732
 */
public class LoansomeCarBuyer {
    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        while (scan.hasNextLine()) {
            int months = scan.nextInt();
            double downPayment = scan.nextDouble(), loan = scan.nextDouble();
            int deprecations = scan.nextInt();
            
            if (months < 0) System.exit(months);
            
            for (int d = 0; d < deprecations; d++) {
                
            }
        }
    }
    
}

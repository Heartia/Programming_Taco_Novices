public class Player {
    private String name;
    private Room currentRoom;
    //private Inventory inventory;
    private Catalog catalog;

    public Player() {
        catalog = new Catalog();
        loadPlayerCatalog();
    }

    public Room getCurrentRoom() {
        return currentRoom;
    }

    public void setCurrentRoom(Room currentRoom) {
        this.currentRoom = currentRoom;
    }

    public Catalog getCatalog() {
        return catalog;
    }

    public void setCatalog(Catalog catalog) {
        this.catalog = catalog;
    }

    public void loadPlayerCatalog() {
        catalog.putItem("CredCoin", false);
        catalog.putItem("LockPick", false);
        catalog.putItem("KeyCard1", false);
        catalog.putItem("KeyCard2", false);
        catalog.putItem("KeyCard3", false);
        catalog.putItem("WaterCups", false);
        catalog.putItem("SafetyGloves", false);
        catalog.putItem("Tacos", false);
        catalog.putItem("DuctTape", false);
    }

    /*public void dropItem(Item item) {
        String itemName = item.getName();
        if(inventory.doHave(itemName)) {
            currentRoom.getInventory().addItem(itemName, item);
            inventory.removeItem(item);
        }
    }

    public Inventory getInventory() {
        return inventory;
    }

    public String getItemString() {
        return inventory.getItemsString();
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public void pickUpItem(Item item) {
        String itemName = item.getName();
        if(inventory.doHave(itemName) && item.isTakeable()) {
            inventory.addItem(itemName, item);
            currentRoom.getInventory().removeItem(item);
        }
    }*/
}
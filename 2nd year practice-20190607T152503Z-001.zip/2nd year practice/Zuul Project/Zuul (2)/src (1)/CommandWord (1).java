/**
 * Representations for all the valid command words for the game.
 *
 * @author Michael Kolling and David J. Barnes
 * @version 2011.08.09
 * @author Sheldon Duncan
 * @version 2018.10.21
 */

public enum CommandWord {
    /*
    * A value for each command word, plus one for
    * unrecognised commands.
     */
    GO, QUIT, HELP, LOOK, TALK, BACK, INSPECT, TAKE, DROP, CATALOG, USE, UNKNOWN;
}
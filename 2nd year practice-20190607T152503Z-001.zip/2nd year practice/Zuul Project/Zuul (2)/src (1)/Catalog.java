import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Catalog {
    private HashMap<String, Boolean> catalog;
    private HashMap<String, Boolean> gatherable;
    private HashMap<String, Catalog> inception;

    public Catalog() {
        catalog = new HashMap<>();
        gatherable = new HashMap<>();
        inception = new HashMap<>();
    }

    public void putItem(String name, boolean inCatalog) {
        catalog.put(name, inCatalog);
        gatherable.put(name, true);
    }

    public void putItem(String name, boolean inCatalog, boolean pickUpAble) {
        catalog.put(name, inCatalog);
        gatherable.put(name, pickUpAble);
    }

    public void removeItem(String name) {
        catalog.remove(name);
        gatherable.remove(name);
    }

    public void addItemInInception(String name) {
        inception.put(name, new Catalog());
    }

    public void addItemInInception(String name, String innerName) {
        Catalog catalog = new Catalog();
        catalog.addInCatalog(innerName);
        inception.put(name, catalog);
    }

    public HashMap<String, Catalog> getInception() {
        return inception;
    }

    public void setInception(HashMap<String, Catalog> inception) {
        this.inception = inception;
    }

    public void removeItemInInception(String name) {
        inception.remove(name);
    }

    public Catalog getInnerCatalog(String name) {
        return inception.get(name);
    }

    public boolean isThere(String name) {
        boolean has = false;
        Iterator iterator = catalog.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry pair = (Map.Entry)iterator.next();
            if (pair.getKey().equals(name) && pair.getValue().equals(true)) {
                has = true;
                break;
            }
        }
        return has;
    }

    public boolean hasNothing() {
        boolean empty = true;
        Iterator iterator = catalog.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry pair = (Map.Entry)iterator.next();
            if (pair.getValue().equals(true)) {
                empty = false;
                break;
            }
        }
        return empty;
    }

    public void addInCatalog(String name) {
        catalog.put(name, true);
        gatherable.put(name, true);
    }

    public void addInCatalog(String name, boolean pickUpAble) {
        catalog.put(name, true);
        gatherable.put(name, pickUpAble);
    }

    public void takeFromCatalog(String name) {
        if (this.isThere(name))
            catalog.put(name, false);
    }

    public void setPickUpAble(String name, boolean pickUpAble) {
        gatherable.put(name, pickUpAble);
    }

    public boolean getPickUpAble(String name) {
        return gatherable.get(name);
    }

    public void emptyCatalog() {
        Iterator iterator = catalog.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry pair = (Map.Entry)iterator.next();
            if (pair.getValue().equals(true)) {
                catalog.put((String)pair.getKey(), false);
            }
        }
    }

    public void fillCatalog() {
        Iterator iterator = catalog.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry pair = (Map.Entry)iterator.next();
            if (pair.getValue().equals(false)) {
                catalog.put((String)pair.getKey(), true);
            }
        }
    }

    public String getCatalogString() {
        if (hasNothing()) {
            return "There aren't any items....";
        }
        String catalogString = "There's ";
        Iterator iterator = catalog.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry pair = (Map.Entry)iterator.next();
            if (pair.getValue().equals(true)) {
                catalogString += (String) pair.getKey() + " ";
            }
        }
        return catalogString;
    }
}
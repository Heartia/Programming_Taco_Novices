import java.util.ArrayList;

public class Character {
    private String name;
    private ArrayList<String> dialogue;
    //private Inventory inventory;
    private Catalog catalog;

    public Character() {
        dialogue = new ArrayList<>();
        name = "Chara";
        catalog = new Catalog();
        loadCharacterCatalog();
        //inventory = new Inventory();
    }

    public Character(String name) {
        dialogue = new ArrayList<>();
        this.name = name;
        //inventory = new Inventory();
    }

    public String getName() {
        return name;
    }

    public void loadCharacterCatalog() {
        catalog.putItem("CredCoin", false);
        catalog.putItem("LockPick", false);
        catalog.putItem("KeyCard3", false);
    }

    public void putInCatalog(String name) {
        if(catalog.isThere(name))
            catalog.putItem("name", true);
    }

    public void removeFromCatalog(String name) {
        if(catalog.isThere(name))
            catalog.putItem("name", false);
    }

    public void setName(String name) {
        this.name = name;
    }

   /* public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public Item getFromInventory(String itemName) {
        return inventory.getItem(itemName);
    }
    */
    public void addDialogue(String dialogue) {
        this.dialogue.add(dialogue);
    }

    public void addDialogue(int index, String dialogue) {
        this.dialogue.add(index, dialogue);
    }

    public void removeDialogue(String dialogue) {
        this.dialogue.remove(dialogue);
    }

    public void removeDialogue(int index) {
        this.dialogue.remove(index);
    }

    public void setDialogue(int index, String dialogue) {
        this.dialogue.set(index, dialogue);
    }

    @Override
    public String toString() {
        String charaDescr = name + "\n";

        for (int i = 0; i < dialogue.size(); i++) {
                charaDescr += dialogue.get(i) + ": " + dialogue;
                boolean isLast = i + 1 >= dialogue.size();
                if (!isLast)
                    charaDescr += ", ";
        }
        return charaDescr;
    }
}
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

/**
 * Class Room - a room in an adventure game.
 *
 * This class is part of the "World of Zuul" application.
 * "World of Zuul" is a very simple, text based adventure game.
 *
 * A "Room" represents one location in the scenery of the game.  It is
 * connected to other rooms via exits.  The exits are labelled north,
 * east, south, west.  For each direction, the room stores a reference
 * to the neighboring room, or null if there is no exit in that direction.
 *
 * @author  Michael Kolling and David J. Barnes
 * Edited by Sheldon Duncan
 * @version 2018.10.02
 */

public class Room
{
    private String roomName;
    private String description;
    private HashMap <String, Room> exits;
    //private Inventory inventory;
    private ArrayList <Character> characters;
    private Catalog catalog;

    /**
     * Create a room described "description". Initially, it has
     * no exits. "description" is something like "a kitchen" or
     * "an open court yard".
     * @param description The room's description.
     */
    public Room(String roomName, String description)
    {
        catalog = new Catalog();
        this.roomName = roomName;
        this.description = description;
        exits = new HashMap<String, Room>();
        //inventory = new Inventory();
        characters = new ArrayList<>();
        loadRoomCatalog();
    }

    /*public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }*/

    public void setCharacters(ArrayList<Character> characters) {
        this.characters = characters;
    }

    public void addCharacter(Character character) {
        characters.add(character);
    }

    public Character getCharacter(int index)
    {
        return characters.get(index);
    }

    public String getRoomName() {
        return roomName;
    }

    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    /**
     * Define the exits of this room.  Every direction either leads
     * to another room or is null (no exit there).
     * @param direction the direction of the exit
     * @param neighbour the room through the exit
     */
    public void setExit(String direction, Room neighbour)
    {
        exits.put(direction, neighbour);
    }

    public Room getExit(String direction)
    {
        return exits.get(direction);
    }

    /*/**
     * Parameters are self explanatory.
     * @param item - The item you are placing.
     * @param itemName - Name of an item.
     */

    /*public void addItem(String itemName, Item item)
    {
        inventory.addItem(itemName, item);
    }

    public Item getItem(String itemName)
    {
        return inventory.getItem(itemName);
    }

    public Item takeItem(String itemName)
    {
        return inventory.takeItem(itemName);
    }

    /**
     * Return a long description of this room, of the form:
     *      You are in the kitchen.
     *      Exits: north west
     * @return
     */

    /*public String getItemList()
    {
        if(!inventory.isEmpty())
            return "Hm. In the room, you can see " + inventory.getItemsString() + "!";
        return "Looks like there aren't any important items in here.";
    }*/

    public void loadRoomCatalog() {
        catalog.putItem("CredCoin", false);
        catalog.putItem("LockPick", false);
        catalog.putItem("KeyCard1", false);
        catalog.putItem("KeyCard2", false);
        catalog.putItem("KeyCard3", false);
        catalog.putItem("WaterCups", false);
        catalog.putItem("SafetyGloves", false);
        catalog.putItem("Tacos", false);

        catalog.putItem("WaterTable", false);
        catalog.putItem("VendingMachine", false);
        catalog.putItem("Panel", false);
        catalog.putItem("MainControlPanel", false);
        catalog.putItem("SideControlPanel", false);
        catalog.putItem("Toilets", false);
        catalog.putItem("Sinks", false);
    }

    public Catalog getCatalog() {
        return catalog;
    }

    public void setCatalog(Catalog catalog) {
        this.catalog = catalog;
    }

    public void addToCatalog(String name) {
        catalog.addInCatalog(name);
    }

    public void removeFromCatalog(String name) {
        catalog.takeFromCatalog(name);
    }

    public String getCharacterList()
    {
        if(!characters.isEmpty()) {
            if (characters.size() == 1)
                return "You can see an A.I! The A.I's name is " + characters.get(0);
            String characterList = "There are multiple A.I in this room! The names include ";
            for (int i = 0; i < characters.size(); i++) {
                if (i + 1 == characters.size())
                    characterList += "and" + characters.get(i);
                else
                    characterList += characters.get(i) + ", ";
            }
            return characterList;
        }
        return "There aren't any characters in here.";
    }

    public String getLongDescription()
    {
        return "You are " + description + ".\n" + getExitString();
    }

    public String getExitString()
    {
        String returnString = "Exits: ";
        Set<String> keys = exits.keySet();
        for(String exit : keys) {
            returnString += " " + exit;
        }
        return returnString;
    }

    /**
     * @return The description of the room.
     */
    public String getDescription()
    {
        return description;
    }
}

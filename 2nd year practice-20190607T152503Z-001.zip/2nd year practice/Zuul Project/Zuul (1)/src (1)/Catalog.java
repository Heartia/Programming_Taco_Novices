import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Catalog {
    private HashMap<String, Boolean> catalog;

    public Catalog() {
        catalog = new HashMap<>();
    }

    public void putItem(String name, boolean inCatalog) {
        catalog.put(name, inCatalog);
    }

    public void removeItem(String name) {
        catalog.remove(name);
    }

    public boolean isThere(String name) {
        boolean has = false;
        Iterator iterator = catalog.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry pair = (Map.Entry)iterator.next();
            if (pair.getKey().equals(name)) {
                has = true;
                break;
            }
        }
        return has;
    }

    public boolean hasNothing() {
        boolean empty = true;
        Iterator iterator = catalog.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry pair = (Map.Entry)iterator.next();
            if (pair.getValue().equals(true)) {
                empty = false;
                break;
            }
        }
        return empty;
    }

    public void addInCatalog(String name) {
        catalog.put(name, true);
    }

    public void takeFromCatalog(String name) {
        if (this.isThere(name))
            catalog.put(name, false);
    }

    public void emptyCatalog() {
        Iterator iterator = catalog.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry pair = (Map.Entry)iterator.next();
            if (pair.getValue().equals(true)) {
                catalog.put((String)pair.getKey(), false);
            }
        }
    }

    public void fillCatalog() {
        Iterator iterator = catalog.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry pair = (Map.Entry)iterator.next();
            if (pair.getValue().equals(false)) {
                catalog.put((String)pair.getKey(), true);
            }
        }
    }

    public String getCatalogString() {
        if (hasNothing()) {
            return "There aren't any items....";
        }
        String catalogString = "There's ";
        Iterator iterator = catalog.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry pair = (Map.Entry)iterator.next();
            if (pair.getValue().equals(true)) {
                catalogString += (String) pair.getKey() + " ";
            }
        }
        return catalogString;
    }
}
public class Item {
    private String name;
    private String description;
    private boolean takeable;
    private boolean hidden;

    public Item (String itemName)
    {
        name = itemName;
        description = "";
        takeable = false;
        hidden = false;
    }

    public Item(String itemName, String itemDescription)
    {
        name = itemName;
        description = itemDescription;
        takeable = false;
    }

    public void isTakeable(boolean canBeTaken)
    {
        takeable = canBeTaken;
    }

    public void isHidden(boolean isHidden)
    {
        hidden = isHidden;
    }

    public boolean isTakeable()
    {
        return takeable;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String itemName)
    {
        name = itemName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String itemDescription) {
        description = itemDescription;
    }
}
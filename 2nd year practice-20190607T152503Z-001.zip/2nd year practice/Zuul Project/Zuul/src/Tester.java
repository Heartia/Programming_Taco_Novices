public class Tester {
    public static void main(String[] args) {
        Game game = new Game();
        game.play();
    }
}
import java.util.ArrayList;

public class Character {
    private String name;
    private ArrayList<String> dialogue;
    private Inventory inventory;

    public Character() {
        dialogue = new ArrayList<>();
        name = "Chara";
        inventory = new Inventory();
    }

    public Character(String name) {
        dialogue = new ArrayList<>();
        this.name = name;
        inventory = new Inventory();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public Item getFromInventory(String itemName) {
        return inventory.getItem(itemName);
    }

    public void addDialogue(String dialogue) {
        this.dialogue.add(dialogue);
    }

    public void addDialogue(int index, String dialogue) {
        this.dialogue.add(index, dialogue);
    }

    public void removeDialogue(String dialogue) {
        this.dialogue.remove(dialogue);
    }

    public void removeDialogue(int index) {
        this.dialogue.remove(index);
    }

    public void setDialogue(int index, String dialogue) {
        this.dialogue.set(index, dialogue);
    }

    @Override
    public String toString() {
        String charaDescr = name + "\n";

        for (int i = 0; i < dialogue.size(); i++) {
                charaDescr += dialogue.get(i) + ": " + dialogue;
                boolean isLast = i + 1 >= dialogue.size();
                if (!isLast)
                    charaDescr += ", ";
        }
        return charaDescr;
    }
}
import java.util.Random;
import java.util.Scanner;
import java.util.Stack;

/**
 *  This class is the main class of the "World of Zuul" application.
 *  "World of Zuul" is a very simple, text based adventure game.  Users
 *  can walk around some scenery. That's all. It should really be extended
 *  to make it more interesting!
 *
 *  To play this game, create an instance of this class and call the "play"
 *  method.
 *
 *  This main class creates and initialises all the others: it creates all
 *  rooms, creates the parser and starts the game.  It also evaluates and
 *  executes the commands that the parser returns.
 *
 * @author  Michael Kolling and David J. Barnes
 * Edited by Sheldon Duncan
 * @version 2018.10.02
 */

public class Game
{
    private Player player;
    private Parser parser;
    private Room currentRoom;
    private Item mainControlPanel, CredCoin, waterTable, waterCups, vendingMachine,
            ductTape, snackBarLockpick, Toilets, Sinks, SafetyGloves, KeyCard1, KeyCard2,
            KeyCard3;
    private Stack <Room> lastRoom;
    private int actionsLeft;
    private Room mainRoom, filtration, s_inter, n_inter, lavatory, sideRoom, basement, closet;
    private boolean wantToQuit;
    private boolean isStarting;
    /**
     * Create the game and initialise its internal map.
     */
    public Game()
    {
        lastRoom = new Stack();
        player = new Player();
        actionsLeft = 51;
        createRooms();
        parser = new Parser();
        wantToQuit = false;
    }

    /**
     * Create all the rooms and link their exits together.
     */
    private void createRooms()
    {
        // create the rooms
        mainRoom = new Room("main control room", "in the main control room." +
                "\nHere, you are greeted with a wide array of metallic buttons, levers and other pieces of machinery." +
                "\nGlistening panels of blue light the room, making you experience a coolness akin to that of an" +
                "\naquarium. Perhaps you can stay in here another time, although for now, you have to hurry." +
                "\nThe main control panel is stationed in the center of the room. Perhaps you can use that to" +
                "\ndisable the lockdown error.\n");
        filtration = new Room("filtration room","in the filtration room." +
                "\nUpon entering this room, a sort of air wall smashes you and your body as gusts " +
                "\nrush into the door you just went through. A cleaning robot disk sways back and forth in the room, " +
                "\nlikely sweeping up dust that you can’t see. Light illuminates from a vending machine as unreachable " +
                "\nsnacks try to make your tongue water, having you stomp your feet at leaving behind your CredCoin " +
                "\ncard. Some water cups are also in the room, however, unlike most filtration rooms, these cups " +
                "\nare completely empty.\n");
        s_inter = new Room("g-h intermediary room", "in the G-H intermediary room." +
                "\nThere isn’t much in this room - with four walls, a floor and a ceiling, it’s as " +
                "\nspotless and empty as an intermediary room should be. There’s a door to sector H47, but there’s " +
                "\nno way that that’ll be open for you during this lockdown error. Perhaps you should leave this " +
                "\nroom - seems like another transition room with nothing to offer. I wonder if my friends are on " +
                "\nthe other side of this wall - oh wait, I forgot - I don’t have friends! Hahaha.\n");
        n_inter = new Room("g-f intermediary room", "in the G-F intermediary room." +
                "\nThree doors stare at you in this room - the bathroom door, the door back to the " +
                "\nmain room, and the door to sector F47. While you obviously have to go through the former two doors," +
                "\n the latter door to F47, in combination with the emptiness that brings echoes every time a noise is" +
                "\n made in this room, causes you to feel like moping about how you’re trapped here. There’s a very " +
                "\nslim probability you’ll make it out of here safe - some of the gadgets in this sector and injure " +
                "\nand even kill you, and, on top of that, just pressing the wrong controls or taking too long can " +
                "\nsignal police to capture you for doing nothing wrong. You worked so hard to become a trainee of " +
                "\nthe PIMMS, and become incarcerated can completely destroy that dream. You kind of feel… hopeless.\n");
        lavatory = new Room("g47 lavatory", "in the G47 lavatory." +
                "\nConsidering that this sector lacks any dormitories, solar farms, cafeterias, " +
                "\nworkplaces, or anything else, it’s not surprising that the lavatory here is clean, as if nobody " +
                "\nhas gone here for years. A small cleaning robot remains dormant in the corner of the room, and the " +
                "\nfive stalls stare at you with a gray, gritty slate-like colour. To pair with the stalls, there are " +
                "\nalso five sinks with mirrors that are perfectly spotless. Looks like your presence is going to ruin " +
                "\nthe homeostasis that is this room." +
                "\nIt seems to be there's also a vent on the ceiling that'll take you to the main control room. Although," +
                "\nfrom the main control room, you probably can't go back to the lavatory through that shortcut.\n");
        sideRoom = new Room("side control room", "in the side control room." +
                "\nThis room is illuminated by what seems to be a rather large holographic screen" +
                "\n - it’s the side control panel! Around the room, the panel’s light illuminates objects the solid" +
                "\nsheets that is the metallic walls, floor and ceiling of the room, alongside an A.I you see in the" +
                "\ncorner of the room with the name tag “Neha”. It seems to be that you can go to the sector G46, but" +
                "\nthe door is locked, like is should be in a lockdown. The room also has a few counters covered in" +
                "\nvarious buttons and levers, but, as a trainee you still have yet to learn what these controls do.\n");
        basement = new Room("upper g sector basement", "in the upper G sector basement." +
                "\nEach basement in the PIMMS is divided into two parts - one for the letter " +
                "\nfollowed by 0-49, known as the upper basement, and another for the same letter but from 50 to 99, " +
                "\nknown as the lower basement. You call out into the echoes of the basement to see if anybody from " +
                "\nany other sector is there, but before you check for there to be a reponse you realise that the " +
                "\nlockdown error also encloses your sector of the basement - G47 - in soundproof plasma walls. " +
                "\nThere’s no way anybody can see that you exist. People far away walk and talk with each other, " +
                "\nwithout noticing that you’re there and in need of extreme help. On the bright side, an A.I with" +
                "\n a puddle of water around it is in the corner of this basement sector - even though it works " +
                "\nabsolutely broken down, maybe you can talk to it for help.\n");
        closet = new Room("g47 sanitation closet","in the G47 sanitation closet." +
                "\nA small, claustrophobic closet of darkness surrounds you as a single cardboard box " +
                "\nsits with gloves - probably for electricians and plumbers - on top. Most sanitation closets tend " +
                "\nto have a variety of items, from brooms to mops and even a few extra cleaning disk robots, but, " +
                "\nhaving been abandoned for years, all this closet has to offer is just some gloves. It reminds " +
                "\nyou of how you might be worthless in society, only being able to offer just one job - one in which " +
                "\nmay or may not be useful." +
                "\n\nAlthough you do see a broken tile on the floor, one that may lead to somewhere or hold sometihng." +
                "\nMaybe you should go down?\n");

        mainRoom.setExit("east", filtration);
        mainRoom.setExit("south", s_inter);
        mainRoom.setExit("west", sideRoom);
        mainRoom.setExit("north", n_inter);
        mainRoom.setExit("down", basement);

        mainControlPanel = new Item("Main Control Panel");
        mainRoom.addItem("Main Control Panel", mainControlPanel);

        filtration.setExit("east", closet);
        filtration.setExit("south", s_inter);
        filtration.setExit("west", mainRoom);

        waterTable = new Item("Water Table");
        filtration.addItem("Water Table", waterTable);
        vendingMachine = new Item("Vending Machine");
        filtration.addItem("Vending Machine", vendingMachine);

        closet.setExit("west", filtration);

        SafetyGloves = new Item("Safety Gloves");
        closet.addItem("Safety Gloves", SafetyGloves);

        s_inter.setExit("east", filtration);
        s_inter.setExit("north", mainRoom);

        sideRoom.setExit("east", mainRoom);
        sideRoom.setExit("north", lavatory);

        lavatory.setExit("east", n_inter);
        lavatory.setExit("south", sideRoom);
        lavatory.setExit("up", mainRoom);

        Toilets = new Item("Toilets");
        lavatory.addItem("Toilets", Toilets);
        Sinks = new Item("Sinks");
        lavatory.addItem("Sinks", Sinks);

        n_inter.setExit("south", mainRoom);
        n_inter.setExit("west", lavatory);

        basement.setExit("up", mainRoom);

        currentRoom = mainRoom;  // start game in main room
        player.setCurrentRoom(currentRoom);
    }

    private void createItems()
    {
        /*
         * Remember to add the other items.
         */
        mainControlPanel = new Item("Main Control Panel", "");
    }

    /**
     *  Main play routine.  Loops until end of play.
     */
    public void play()
    {
        printWelcome();

        // Enter the main command loop.  Here we repeatedly read commands and
        // execute them until the game is over.

        boolean finished = false;
        while (! finished) {
            Command command = parser.getCommand();
            finished = processCommand(command);
        }
        System.out.println("Aw, you're going already? Well, it's fine, everybody" +
                "\nhas places to be, places to go." +
                "\n\nBye bye!");
    }

    /**
     * Print out the opening message for the player.
     */
    private void printWelcome()
    {
        System.out.println();
        System.out.println("Welcome to the World of Zuul! Or should I say, the spacetime rift of Prithvi....");
        System.out.println("Here you're trapped in a lockdown error on the PIMMS in sector G47!" +
                "\nGet out of this sector as quick as possible! Go go go!");
        System.out.println("Also, you should type 'help'. That is, if you need help.");
        System.out.println();
        printLocationInfo();
    }

    /**
     * Given a command, process (that is: execute) the command.
     * @param command The command to be processed.
     * @return true If the command ends the game, false otherwise.
     */
    private boolean processCommand(Command command)
    {
        //boolean wantToQuit = false;
        if(command.isUnknown()) {
            System.out.println("I don't know what you mean...");
            return false;
        }

        String commandWord = command.getCommandWord();
        if (commandWord.equalsIgnoreCase("help"))
            printHelp(command);
        else if (commandWord.equalsIgnoreCase("go")) {
            //Actions are decremented in printLocationInfo
            goRoom(command);
        }
        else if (commandWord.equalsIgnoreCase("quit")) {
            wantToQuit = quit(command);
        }
        else if (commandWord.equalsIgnoreCase("look")) {
            look();
        }
        else if (commandWord.equalsIgnoreCase("talk")) {
            talk(command);
            decrementActions();
        }
        else if (commandWord.equalsIgnoreCase("back")) {
            //Actions are decrementerd in printLocationInfo
            back();
        }
        else if (commandWord.equalsIgnoreCase("inspect")) {
            inspect(command);
            decrementActions();
        }
        else if (commandWord.equalsIgnoreCase("take")) {
            take(command);
        }
        else if (commandWord.equalsIgnoreCase("drop")) {
            drop(command);
        }
        else if (commandWord.equalsIgnoreCase("catalog")) {
            catalog();
        }
        if (actionsLeft == 0)
            wantToQuit = quit();
        return wantToQuit;
    }

    // implementations of user commands:

    /**
     * Print out some help information.
     * Here we print some stupid, cryptic message and a list of the
     * command words.
     */
    private void printHelp(Command command)
    {
        if(!command.hasSecondWord()) {
            System.out.println("So, I'm your A.I Sam, who'll help you out in the G47 sector!"
                    + "\nI know you had brain injuries, so I can understand how you forgot." +
                    "\nYou're a trainee for the PIMMS, an interdimensional spaceship!" +
                    "\nHowever, you got stuck in a lockdown error, and have only a little" +
                    "\nbit of time to get out - else you risk being sent to jail!" +
                    "\n\nYour main objective is to collect items and use keycards on the main" +
                    "\ncontrol panel to win! You just have to collect those keycards... in time." +
                    "\nYou might want to know some commands here.");
            System.out.println();
            System.out.println("Your command words are:");
            System.out.println(parser.showCommands());
            System.out.println("Type 'help commands' if you want to see how to use these commands!");
            return;
        }
        if(command.getSecondWord().equalsIgnoreCase("Commands")) {
            System.out.println("So here's a basic rundown of commands that you'll have to use." +
                    "\nGo) You have to put an exit name after this command. For example," +
                    "\n\ttyping 'go east' will send you east. 'go north' will send you north." +
                    "\n\tYou use this command to move from room to room." +
                    "\n\tKeep in mind, though - this will decrement the amount of actions you have." +
                    "\nQuit) Typing this command, by itself like 'quit' will quit the game." +
                    "\nHelp) I'm sure you know how to use help, but if you type 'help', you'll" +
                    "\n\tget a basic rundown of your game and your objective. Typing 'help commands'" +
                    "\n\twill give you a basic rundown on how commands work." +
                    "\nLook) Allows you to look around the room and see the description of the room." +
                    "\nTalk) If you type 'talk' followed by the name of an A.I character in the room," +
                    "\n\tsuch as typing 'talk Sam', you will talk to that A.I. These A.I" +
                    "\n\tcan be very useful on your fetch quest. However, this'll also" +
                    "\n\tdecrement your actions." +
                    "\nBack) This command makes you go back to the room you were last in. All you type" +
                    "\n\tis 'back.' Keep in mind, this command is similar to 'go' and, as such, will" +
                    "\n\talso decrement your actions." +
                    "\nInspect) If you add the name of an item in the room after 'inspect' such" +
                    "\n\tas 'inspect main control panel', you might find something hidden!" +
                    "\nTake) If you type 'take' followed by an item in the room, such as 'take" +
                    "\n\tkey card', you can take this item and put it into your inventory." +
                    "\nDrop) Similarly, you can do the same with 'drop' with any item in your" +
                    "\n\tinventory and place it into the room." +
                    "\n\nI presume you understand all the commands now, right?" +
                    "\nWell, if you don't, it won't take much time to learn.");
        }
    }

    /**
     * Try to go to one direction. If there is an exit, enter
     * the new room, otherwise print an error message.
     */

    private void goRoom(Command command)
    {
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know where to go...
            System.out.println("Go where?");
            return;
        }

        String direction = command.getSecondWord();

        // Try to leave current room.
        Room nextRoom = player.getCurrentRoom().getExit(direction);

        if (nextRoom == null) {
            if(player.getCurrentRoom().getRoomName().equalsIgnoreCase("g47 sanitation closet") &&
                    direction.equalsIgnoreCase("down")) {
                System.out.println("Wait, what is that? Even I don't know about this room. Wait..." +
                        "\ndon't go... wait!" +
                        "\n\nYou fell into a room with strange lights and noises, and your vision fades" +
                        "\nas you white out. When you wake up, you're in a random room!?");
                Random random = new Random();
                int rando = random.nextInt(9);
                switch(rando){
                    case 0:
                        currentRoom = mainRoom;
                        break;
                    case 1:
                        currentRoom = filtration;
                        break;
                    case 2:
                        currentRoom = n_inter;
                        break;
                    case 3:
                        currentRoom = s_inter;
                        break;
                    case 4:
                        currentRoom = sideRoom;
                        break;
                    case 5:
                        currentRoom = lavatory;
                        break;
                    case 6:
                        currentRoom = basement;
                        break;
                    case 7:
                        currentRoom = closet;
                        break;
                    case 8:
                        System.out.println("'I told you this was a bad idea,' yelled Sam A.I as you flesh" +
                                "\nbegan to turn inside out and your blood burned into bits." +
                                "\nYou screamed from the inside out as the white faded to black..." +
                                "\n... and your life turned to death." +
                                "\n\nGame Over!");
                        wantToQuit = quit();
                        return;
                }
                player.setCurrentRoom(currentRoom);
                printLocationInfo();
            }
            System.out.println("There is no door!");
            actionsLeft++;
        }
        else {
            lastRoom.push(currentRoom);
            if (currentRoom.getRoomName().equalsIgnoreCase("g47 lavatory") &&
                    direction.equalsIgnoreCase("Up"))
                System.out.println("You just went... through the shortcut in the vents? Ew.");
            currentRoom = nextRoom;
            player.setCurrentRoom(currentRoom);
            printLocationInfo();
        }
    }

    /**
     * Return a description of the room's exits.
     * for example, "Exist: north west".
     * @return A description of the available exits.
     */

    private void printActionsLeft() {
        if (actionsLeft == 0)
            System.out.println("\nHm. I guess this is the end. You tried your best, but you ran out of time.");
        else if (actionsLeft == 1)
            System.out.println("This is your last action, right? You do only have " + actionsLeft + " action left....");
        else if (actionsLeft <= 5)
            System.out.println("You better hurry!!! You only have " + actionsLeft + " actions left!");
        else if (actionsLeft <= 25)
            System.out.println("You still have quite some time, as you have " + actionsLeft + " actions left. Donchu worry <3");
        else
            System.out.println("You have plenty of time! The actions you have left is " + actionsLeft + "!");
    }

    private void decrementActions() {
        actionsLeft--;
        printActionsLeft();
    }

    private void printLocationInfo() {
        System.out.println("The room that you're in is the " + player.getCurrentRoom().getRoomName() + "!");
        System.out.println(player.getCurrentRoom().getExitString());
        decrementActions();
        System.out.println(player.getCurrentRoom().getItemList());
    }

    private void take(Command command)
    {
        if (!command.hasSecondWord())
        {
            System.out.println("Uhm... what exactly are you taking?");
            return;
        }
        if (currentRoom.getInventory().doHave(command.getSecondWord())) {
            System.out.println("You took " + currentRoom.getInventory().getItem(command.getSecondWord()).getName() + "!");
            player.pickUpItem(currentRoom.getInventory().getItem(command.getSecondWord()));
            return;
        }
        System.out.println("Uhm... whatever you're taking... isn't there....");
    }

    private void catalog()
    {
        System.out.println(player.getItemString());
    }

    private void drop(Command command)
    {
        if (!command.hasSecondWord())
        {
            System.out.println("... Maybe you should specify... what you're dropping.");
            return;
        }
        if (player.getInventory().doHave(command.getSecondWord())) {
            System.out.println("You dropped " + player.getInventory().getItem(command.getSecondWord()).getName() + "!");
            player.dropItem(player.getInventory().getItem(command.getSecondWord()));
            return;
        }
        System.out.println("Yeah, you aren't holding what you're trying to drop....");
    }

    private void look()
    {
        System.out.println(player.getCurrentRoom().getLongDescription());
        printActionsLeft();
        System.out.println(player.getCurrentRoom().getItemList());
    }

    private void back()
    {
        if(lastRoom.isEmpty())
            System.out.println("Uh... I think you went back tooo far..." +
                    "\nNo worries... it's a mistake everyone makes.");
        else {
            System.out.println("Hm! You went back!");
            currentRoom = lastRoom.pop();
            player.setCurrentRoom(currentRoom);
            printLocationInfo();
        }
    }

    private void inspect(Command command)
    {
        if(!command.hasSecondWord()) {
            System.out.println("Uh... what are you inspecting?");
            actionsLeft++;
            return;
        }
        System.out.println("Uhm... what you're looking for... isn't there....");
    }

    private void talk(Command command)
    {
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know who to talk to...
            System.out.println("Wait, who are you talking to?");
            actionsLeft++;
            return;
        }
        else
            if(command.getSecondWord().equalsIgnoreCase("Sam") &&
                    player.getCurrentRoom().getRoomName().equalsIgnoreCase("main control room"))
                System.out.println("Hello! How's it going!?");
            else if (command.getSecondWord().equalsIgnoreCase("Neha") &&
                    player.getCurrentRoom().getRoomName().equalsIgnoreCase("side control room"))
                System.out.println("Hiya, how's it going!");
            else if (command.getSecondWord().equalsIgnoreCase("Quiyang") &&
                    player.getCurrentRoom().getRoomName().equalsIgnoreCase("upper g sector basement"))
                System.out.println("Do you really want to talk to me?");
            else
                System.out.println("Uhm... they're not there...");
    }

    /**
     * "Quit" was entered. Check the rest of the command to see
     * whether we really quit the game.
     * @return true, if this command quits the game, false otherwise.
     */

    private boolean quit(Command command)
    {
        if(command.hasSecondWord()) {
            System.out.println("Quit what?");
            return false;
        }
        else {
            return true;  // signal that we want to quit
        }
    }

    private boolean quit()
    {
        return true;
    }
}
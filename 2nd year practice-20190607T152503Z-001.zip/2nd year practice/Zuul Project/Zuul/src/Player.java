public class Player {
    private String name;
    private Room currentRoom;
    private Inventory inventory;

    public Player() {

    }

    public Room getCurrentRoom() {
        return currentRoom;
    }

    public void setCurrentRoom(Room currentRoom) {
        this.currentRoom = currentRoom;
    }

    public void dropItem(Item item) {
        String itemName = item.getName();
        if(inventory.doHave(itemName)) {
            currentRoom.getInventory().addItem(itemName, item);
            inventory.removeItem(item);
        }
    }

    public Inventory getInventory() {
        return inventory;
    }

    public String getItemString() {
        return inventory.getItemsString();
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public void pickUpItem(Item item) {
        String itemName = item.getName();
        if(inventory.doHave(itemName) && item.isTakeable()) {
            inventory.addItem(itemName, item);
            currentRoom.getInventory().removeItem(item);
        }
    }
}
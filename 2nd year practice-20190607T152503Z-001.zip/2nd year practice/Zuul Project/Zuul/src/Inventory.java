import java.util.*;

public class Inventory {
    private HashMap<String, Item> items;
    private HashMap<Item, Integer> itemsNum;

    public Inventory ()
    {
        items = new HashMap<>();
        itemsNum = new HashMap<>();
    }

    public void addItem (String itemName, Item item)
    {
        items.putIfAbsent(itemName, item);
        if (this.doHave(itemName) && !itemsNum.isEmpty()) {
            itemsNum.put(item, 2);
            /*int temp = itemsNum.get(item) + 1;
            itemsNum.put(item, temp);*/
        } else
            itemsNum.put(item, 1);
    }

    public void setItem (String itemName, Item item)
    {
        items.put(itemName, item);
        if (itemsNum.get(item) != null) {
            int temp = itemsNum.get(item)+1;
            itemsNum.put(item, temp);
        }
        else
            itemsNum.put(item, 1);
    }

    public void addItemAmount (Item item, int amount)
    {
        int temp = itemsNum.get(item)+amount;
        itemsNum.put(item, temp);
    }

    public void setItemAmount (Item item, int amount)
    {
        itemsNum.put(item, amount);
    }

    public Item takeItem (String itemName)
    {
        Item temp = items.get(itemName);
        items.remove(itemName);
        return temp;
    }

    public Item getItem (String itemName)
    {
        return items.get(itemName);
    }

    public int getItemAmount (Item item)
    {
        return itemsNum.get(item);
    }

    public void removeItem (Item item)
    {
        String temp = getKeyByValue(items, item);
        items.remove(temp);
        itemsNum.remove(item);
    }

    public void removeItem (String itemName)
    {
        Item temp = items.get(itemName);
        items.remove(itemName);
        itemsNum.remove(temp);
    }

    public static <T, E> T getKeyByValue(Map<T, E> map, E value) {
        for (Map.Entry<T, E> entry : map.entrySet()) {
            if (Objects.equals(value, entry.getValue())) {
                return entry.getKey();
            }
        }
        return null;
    }

    public String getItemsString ()
    {
        String itemString = "";
        Iterator iterator = items.entrySet().iterator();
        while(iterator.hasNext()) {
            Map.Entry pair = (Map.Entry)iterator.next();
            if(iterator.hasNext())
                itemString += pair.getKey() + " and ";
            else
                itemString += pair.getKey();
            //iterator.remove();
        }
        return itemString;
    }

    /*
     * Have to fix this method right below.
     */

    public String getItemsAmountString()
    {
        String itemString = "";
        ArrayList<String> itemNames = new ArrayList<>();
        Iterator iterator1 = items.entrySet().iterator();
        while(iterator1.hasNext()) {
            Map.Entry pair = (Map.Entry)iterator1.next();
            itemNames.add(pair.getKey() + "");
            iterator1.remove();
        }
        ArrayList<Integer> itemAmnts = new ArrayList<>();
        Iterator iterator2 = itemsNum.entrySet().iterator();
        while(iterator2.hasNext()) {
            Map.Entry pair = (Map.Entry)iterator2.next();
            itemAmnts.add((Integer) pair.getValue());
            iterator2.remove();
        }

        return itemString;
    }

    public boolean isEmpty()
    {
        return items.isEmpty() || itemsNum.isEmpty();
    }

    public boolean doHave(String itemName)
    {
        boolean isThere = false;
        for (Object o : items.entrySet()) {
            Map.Entry pair = (Map.Entry) o;
            String theName = (String) pair.getKey();
            if (theName.equalsIgnoreCase(itemName)) {
                isThere = true;
            }
        }
        return isThere;
    }
}
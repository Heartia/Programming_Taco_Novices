import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * This class is part of the "World of Zuul" application.
 * "World of Zuul" is a very simple, text based adventure game.
 *
 * This class holds an enumeration of all command words known to the game.
 * It is used to recognise commands as they are typed in.
 *
 * @author  Michael Kolling and David J. Barnes
 * Edited by Sheldon Duncan
 * @version 2018.10.02
 */

public class CommandWords {
    // a constant array that holds all valid command words
    /*private static final String[] validCommands = {
            "go", "quit", "help", "look", "talk", "back", "inspect", "take", "drop"
    };*/
    private static HashMap<String, CommandWord> validCommands;

    /**
     * Constructor - initialise the command words.
     */
    public CommandWords() {
        validCommands = new HashMap<>();
        validCommands.put("go", CommandWord.GO);
        validCommands.put("quit", CommandWord.QUIT);
        validCommands.put("help", CommandWord.HELP);
        validCommands.put("look", CommandWord.LOOK);
        validCommands.put("talk", CommandWord.TALK);
        validCommands.put("back", CommandWord.BACK);
        validCommands.put("inspect", CommandWord.INSPECT);
        validCommands.put("take", CommandWord.TAKE);
        validCommands.put("drop", CommandWord.DROP);
        validCommands.put("catalog", CommandWord.CATALOG);
    }

    /**
     * Check whether a given String is a valid command word.
     *
     * @return true if a given string is a valid command,
     * false if it isn't.
     */
    public boolean isCommand(String aString) {
        Iterator iterator = validCommands.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry pair = (Map.Entry)iterator.next();
            if (pair.getKey().equals(aString))
                return true;
        }
        /*for (int i = 0; i < validCommands.size(); i++) {
            if (validCommands.get.equals(aString))
                return true;
        } Beta code - might be useful*/
        // if we get here, the string was not found in the commands
        return false;
    }

    public String showAll() {
        String totalCommands = "";
        Iterator iterator = validCommands.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry pair = (Map.Entry)iterator.next();
            totalCommands += pair.getKey() + " ";
        }
        /*for (String command : validCommands) {
            totalCommands += command + " ";
        } Beta code - might be useful*/
        return totalCommands + "\n";
    }
}
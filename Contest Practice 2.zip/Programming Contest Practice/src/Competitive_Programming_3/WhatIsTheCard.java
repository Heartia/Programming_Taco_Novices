package Competitive_Programming_3;

import java.io.*;
import java.util.Scanner;

public class WhatIsTheCard {

    public static void main(String[] args) throws IOException {
        Scanner scan = new Scanner(new File("WhatIsTheCard.txt"));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
        int tests = scan.nextInt();

        for (int t = 1; t <= tests; t++) {
            Card[] cards = new Card[52];

            for (int i = 0; i < cards.length; i++) {
                cards[i] = new Card(scan.next());
            }

            Card[] deck25 = new Card[25];

            for (int c = cards.length - 1; c <= 25; c--) {
                deck25[0] = cards[c];
            }

            int y = 0;
            int j = cards.length - 26;

            for (int i = 0; i < 3; i++) {
                int value = cards[j].value;

                y += value;
                j -= 10 - value;
            }



            pw.println("Case " + t + ": " + cards[y]);
        }

        pw.close();
    }



    private static class Card {

        int value;
        char suit;

        Card(String info) {
            value = Character.isDigit(info.charAt(0)) ?
                    Integer.parseInt(info.substring(0, 1)) : 10;
            suit = info.charAt(1);
        }

        public String toString() {
            if (value < 10) {
                return value + "" + suit;
            }
            else {
                switch (value) {
                    case 10:
                        return "T" + suit;
                    case 11:
                        return "J" + suit;
                    case 12:
                        return "Q" + suit;
                    case 13:
                        return "K" + suit;
                    default:
                        return "?" + suit;
                }
            }
        }

    }

}

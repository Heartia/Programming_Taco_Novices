package Competitive_Programming_3;

import java.io.*;
import java.math.BigDecimal;

public class Joanna {

    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new FileReader(new File("joanna.dat")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        final int payRate = 0, hours = 1, laptopPrice = 2, accesoryPrice = 3, taxRate = 4;
        int tests = Integer.parseInt(br.readLine());

        for (int t = 0; t < tests; t++) {
            String[] data = br.readLine().split("\\s");

            BigDecimal[] vals = new BigDecimal[data.length];

            for (int i = 0; i < vals.length; i++) {
                vals[i] = new BigDecimal(data[i]);
            }

            BigDecimal netPay = (((vals[payRate].multiply(vals[hours])).multiply(new BigDecimal(1 - 0.0765))));
            netPay = netPay.multiply(new BigDecimal(10));
            final BigDecimal divide = vals[taxRate].divide(new BigDecimal(100), BigDecimal.ROUND_HALF_UP);
            final BigDecimal add = divide.add(new BigDecimal(1));
            BigDecimal purchase = (vals[laptopPrice].multiply(add).add((vals[accesoryPrice].multiply((divide.add(new BigDecimal(1)))))));
            BigDecimal funCash = netPay.subtract(purchase);

            pw.print("Net Pay:  ");
            StringBuilder netPayStr = new StringBuilder(String.format("%,.2f", netPay));
            int netlength = netPayStr.length();
            while (netlength < 8) {
                netPayStr.insert(0, " ");
                netlength++;
            }
            pw.println("$" + netPayStr.toString());

            pw.print("Purchase: ");
            StringBuilder purchaseStr = new StringBuilder(String.format("%,.2f", purchase));
            int purlength = purchaseStr.length();
            while (purlength < 8) {
                purchaseStr.insert(0, " ");
                purlength++;
            }
            pw.println("$" + purchaseStr.toString());

            pw.print("Fun Cash: ");
            StringBuilder funStr = new StringBuilder(String.format("%,.2f", funCash));
            int funlength = funStr.length();
            while (funlength < 8) {
                funStr.insert(0, " ");
                funlength++;
            }
            pw.println("$" + funStr.toString());

            pw.println("*********");
        }

        pw.close();
    }

}

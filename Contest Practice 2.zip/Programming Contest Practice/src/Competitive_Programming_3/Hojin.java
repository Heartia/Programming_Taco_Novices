package Competitive_Programming_3;

import java.io.*;

public class Hojin {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("hojin.dat")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        int tests = Integer.parseInt(br.readLine());

        for (int t = 1; t <= tests; t++) {
            String[] data = br.readLine().split(" ");
            long[] nums = new long[data.length];
            for (int n = 0; n < nums.length; n++) {
                nums[n] = Long.parseLong(data[n]);
            }
            pw.println("Case #" + t + ": " + gcfBest(nums[0], nums[1]));
        }
        pw.close();
    }

    private static long gcf(long num1, long num2) {
        long count = 0;
        while (num2 != 0) {
            if (count == Short.MAX_VALUE || num1 < 0 || num2 < 0) {
                return 1;
            }
            if (num1 % num2 == 0) {
                return num2;
            }
            else if (num2 % num1 == 0) {
                return num1;
            }
            else {
                if (num1 < num2) {
                    long temp = num1;
                    num1 = num2;
                    num2 = temp;
                }
                num1 -= num2;
            }
            count++;
        }
        return num1;
    }

    private static long gcfBetter(long a, long b) {
        while (b != 0) {
            long temp = b;
            b = a % b;
            a = temp;
        }

        return a;
    }

    private static long gcfBest(long a, long b) {
        if (b == 0) {
            return a;
        }

        return gcfBest(b, a % b);
    }

}

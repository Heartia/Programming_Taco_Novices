package Competitive_Programming_3;

import java.io.*;

public class Dylan {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("dylan.dat")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        final int halfLength = 0, rowAmount = 1, seatNumber = 2;
        int tests = Integer.parseInt(br.readLine());

        for (int t = 0; t < tests; t++) {
            String[] data = br.readLine().split(" ");
            int[] vals = new int[data.length];

            for (int i = 0; i < data.length; i++) {
                vals[i] = Integer.parseInt(data[i]);
            }

            int length = vals[halfLength] * 2;
            int left = length * (vals[rowAmount] - 1);

            if(vals[seatNumber] < vals[halfLength]) {
                pw.println(2 * (vals[halfLength] - vals[seatNumber] - 1));
            }
            else {
                pw.println(2 * (vals[seatNumber] - vals[halfLength]));
            }
        }

        pw.close();
    }

}

package Competitive_Programming_3;

import java.io.*;

public class Lucia {

    static PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("lucia.dat")));

        String[] data = br.readLine().split(" ");
        int[] vals = new int[data.length];

        for (int i = 0; i < vals.length; i++) {
            vals[i] = Integer.parseInt(data[i]);
        }

        TriTree tree = new TriTree(vals[0]);

        for (int i = 1; i < vals.length; i++) {
            tree.insert(vals[i]);
        }

        tree.printPreOrder();
        pw.close();
    }

    static class TriTree {

        static class Node {
            int val;
            Node left, right, centre;

            Node(int val) {
                this.val = val;
                left = right = centre = null;
            }

            public String toString() {
                return val + "";
            }
        }

        Node root;

        TriTree(int val) {
            root = new Node(val);
        }

        void insert(int val) {
            root = insert(root, val);
        }

        Node insert(Node node, int key) {
            if (node == null) {
                node = new Node(key);
                return node;
            }
            else {
                if (key < node.val - 5) {
                    node.left = insert(node.left, key);
                }
                else if (key > node.val + 5) {
                    node.right = insert(node.right, key);
                }
                else {
                    node.centre = insert(node.centre, key);
                }

                return node;
            }
        }

        void printPreOrder() {
            printPreOrder(root);
        }

        void printPreOrder(Node node) {
            if (node == null) {
                return;
            }
            pw.print(node.val + " ");
            printPreOrder(node.left);
            printPreOrder(node.centre);
            printPreOrder(node.right);
        }

    }

}

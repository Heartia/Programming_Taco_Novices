package Competitive_Programming_3;

public class TestAPExam {

    public static void main(String[] args) {
        secondTestMethod(new int[]{3, 4, 5});

        String s = "holy";
        String t = s.substring(s.length());
        System.out.println(s + t);
    }

    public static void increment(int n) {
        n++;
    }

    public static void secondTestMethod(int[] testArray) {
        for (int element : testArray) {
            increment(element);
            System.out.print(element + " ");
        }
    }

}

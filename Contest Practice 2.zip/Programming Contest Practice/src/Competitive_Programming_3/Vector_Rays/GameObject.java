package Competitive_Programming_3.Vector_Rays;

public interface GameObject {

    void render();

    void tick();

}

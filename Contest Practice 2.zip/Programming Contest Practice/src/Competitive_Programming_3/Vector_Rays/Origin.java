package Competitive_Programming_3.Vector_Rays;

import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

public class Origin implements GameObject {

    int x, y, radius, moveDist;
    private Canvas canvas;
    private Color color;
    private ArrayList<Ray> rays = new ArrayList<>();
    private Random random;

    public Origin(int x, int y, int radius, int angleIncrements, int moveDist, Canvas canvas, Color color) {
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.canvas = canvas;
        this.color = color;
        this.moveDist = moveDist;
        int angle = 0;
        while (angle < 360) {
            if (angle % 90 == 0) {
                if (angle == 90) {
                    rays.add(new Ray(x + (radius / 2), y + (radius / 2), Map.xSize / 2, 0, canvas, color));
                }
                else if (angle == 0) {
                    rays.add(new Ray(x + (radius / 2), y + (radius / 2), Map.xSize, Map.ySize / 2, canvas, color));
                }
                else if (angle == 270) {
                    rays.add(new Ray(x + (radius / 2), y + (radius / 2), Map.xSize / 2, Map.ySize, canvas, color));
                }
                else if (angle == 180) {
                    rays.add(new Ray(x + (radius / 2), y + (radius / 2), 0, Map.ySize / 2, canvas, color));
                }
            }
            else {
                rays.add(new Ray(x + (radius / 2), y + (radius / 2), angle, canvas, color));
            }
            angle += angleIncrements;
        }
        random = new Random();
    }

    @Override
    public void render() {
        canvas.setForegroundColor(color);
        canvas.fillCircle(x, y, radius);
        for (Ray ray : rays) {
            ray.render();
        }
    }

    @Override
    public void tick() {
        int oldX = x, oldY = y;
        x = random.nextBoolean() ? x + moveDist : x - moveDist;
        y = random.nextBoolean() ? y + moveDist : y - moveDist;
        for (Ray ray : rays) {
            ray.startX = x + radius / 2;
            ray.startY = y + radius / 2;
            if (ray.angle == 90 || ray.angle == 270) {
                ray.endX += x - oldX;
            }
            else if (ray.angle == 0 || ray.angle == 180) {
                ray.endY += y - oldY;
            }
            ray.tick();
        }
    }

    @Override
    public String toString() {
        return "Origin (" + x + ", " + y +") {" +
                "\nradius = " + radius +
                "\ncolor = " + color +
                "\nrays = " + rays +
                "\n}";
    }

    public ArrayList<Ray> getRays() {
        return rays;
    }

    public void setRays(ArrayList<Ray> rays) {
        this.rays = rays;
    }
}

package Competitive_Programming_3.Vector_Rays;

import java.awt.*;

public class Wall implements GameObject {

    int startX, startY;
    int endX, endY;
    private Canvas canvas;
    private Color color;

    public Wall(int startX, int startY, int endX, int endY, Canvas canvas, Color color) {
        this.startX = startX;
        this.startY = startY;
        this.endX = endX;
        this.endY = endY;
        this.canvas = canvas;
        this.color = color;
    }

    @Override
    public void render() {
        canvas.setForegroundColor(color);
        canvas.drawLine(startX, startY, endX, endY, 3);
    }

    @Override
    public void tick() {

    }

    @Override
    public String toString() {
        return "Wall (" + startX + ", " + startY + ") -> (" + endX + ", " + endY + ") {" +
                "\n, color = " + color +
                "\n}";
    }
}

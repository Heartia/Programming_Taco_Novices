package Competitive_Programming_3.Vector_Rays;

import java.awt.*;

public class Ray implements GameObject {

    double startX, startY;
    double endX, endY;
    double angle;
    private Canvas canvas;
    private Color color;

    public Ray(double startX, double startY, double angle, Canvas canvas, Color color) {
        this.startX = startX;
        this.startY = startY;
        this.angle = angle;
        this.canvas = canvas;
        this.color = color;
        int tempAngle = (int)(angle * Math.PI / 100);
        endX = (startX + Map.xSize) * Math.sin(tempAngle);
        endY = (startX + Map.ySize) * Math.cos(tempAngle);
    }

    public Ray(double startX, double startY, double endX, double endY, Canvas canvas, Color color) {
        this.startX = startX;
        this.startY = startY;
        this.endX = endX;
        this.endY = endY;
        this.canvas = canvas;
        this.color = color;
    }

    @Override
    public void render() {
        canvas.setForegroundColor(color);
        canvas.drawLine((int)startX, (int)startY, (int)endX, (int)endY, 3);
    }

    @Override
    public void tick() {

    }

    @Override
    public String toString() {
        return "Ray (" + startX + ", " + startY + ") -> (" + endX + ", " + endY + ") {" +
                "\nangle = " + angle +
                "\ncolor = " + color +
                "\n}";
    }
}

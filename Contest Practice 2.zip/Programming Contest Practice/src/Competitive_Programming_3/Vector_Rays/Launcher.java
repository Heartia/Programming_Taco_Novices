package Competitive_Programming_3.Vector_Rays;

import java.io.IOException;

public class Launcher {

    public static void main(String[] args) throws IOException {
        Map map = new Map("Vector Rays", 1000, 600);
        map.run();
    }

}

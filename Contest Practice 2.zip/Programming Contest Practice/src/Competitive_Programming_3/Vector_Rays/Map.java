package Competitive_Programming_3.Vector_Rays;

import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Map {

    static final int WALL = 0;
    static final int PATH = 1;
    static final int PASSED = 2;
    static final int START = 3;
    static final int END = 4;

    private static int startR = 0, startC = 0;
    static int xSize, ySize;
    private static Random random;
    private static Canvas canvas;
    private static Color[] colorof = {Color.BLACK, Color.WHITE, Color.GREEN, Color.YELLOW, Color.RED};
    private static BufferedReader br;
    private static int waitTime = 10;

    private static ArrayList<GameObject> gameObjects = new ArrayList<>();

    static {
        try {
            br = new BufferedReader(new FileReader(new File("MapRay.dat")));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public Map(String title, int xSize, int ySize) throws IOException {
        //String[] data = br.readLine().split("\\s");
        this.xSize = xSize;
        this.ySize = ySize;
        random = new Random();
        canvas = new Canvas(title, xSize, ySize);
        canvas.wait(500);// Synch with system
        canvas.setForegroundColor(new Color(10, 0, 25));
        canvas.fillRectangle(0, 0, xSize, ySize);
        genMap();
    }

    public void run() {
        long max = 50000000;
        long l = 0;
        while(true) {
            if (l < max) {
                l++;
            }
            else {
                tick();
                drawMap();
                l = 0;
            }
        }
    }

    public void readMap() {

    }

    public void genMap() {
        //gameObjects.add(new Wall(random.nextInt(400) + 50, random.nextInt(400) + 50, random.nextInt(400) + 50, random.nextInt(400) + 50, canvas, Color.WHITE));
        gameObjects.add(new Origin(xSize / 2, ySize / 2, 16, 15, 3, canvas, new Color(255, 255, 192)));
    }

    public void tick() {
        for (GameObject g : gameObjects) {
            g.tick();
            if (g.getClass() == Origin.class) {
                for (Ray ray : ((Origin)g).getRays()) {
                    System.out.print(ray.angle + " ");
                }
                System.out.println();
            }
        }
    }

    public void drawMap() {
        canvas.setForegroundColor(new Color(10, 0, 25));
        canvas.fillRectangle(0, 0, xSize, ySize);
        for (GameObject g : gameObjects) {
            g.render();
        }
    }

    public String toString() {
        StringBuilder string = new StringBuilder();
        for (GameObject g : gameObjects) {
            string.append(g).append("\n");
        }
        return string.toString();
    }
}

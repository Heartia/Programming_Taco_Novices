package Competitive_Programming_3;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class Aaditya {

    public static void main(String[] args) {
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        pw.println("Programming in Java is Awesome!!\n" +
                "Java PROGRAMMERS rock the world!");
        pw.close();
    }

}

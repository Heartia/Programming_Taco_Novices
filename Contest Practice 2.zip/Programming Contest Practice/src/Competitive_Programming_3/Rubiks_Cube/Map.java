package Competitive_Programming_3.Rubiks_Cube;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Map {

    static final int WHITE = 0;
    static final int RED = 1;
    static final int GREEN = 2;
    static final int YELLOW = 3;
    static final int BLUE = 4;
    static final int ORANGE = 5;

    private static int startR = 0, startC = 0;
    private static int margin = 300;
    private static int[][][] cube;      // array representing map
    private static int[][] ogMap;
    private static int rows;   // number of rows in array
    private static int cols;   // number of columns in array\
    private static int sides;
    private static int currentSide;
    private static int size;  // size of graphical representation (cells)
    private static Random random;
    private static Canvas canvas;
    private static Color[] colorof = {Color.WHITE, Color.RED, new Color(0, 128, 0), Color.YELLOW, Color.BLUE, new Color(255, 128, 0)};
    private static BufferedReader br;
    private static ArrayList<Integer> path = new ArrayList<>();
    private static int waitTime = 10;

    static {
        try {
            br = new BufferedReader(new FileReader(new File("Map.dat")));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    /*
    int minX = (margin / 2) + (size * cols) + (margin / 10);
        int maxX = (margin / 2) + (size * (cols + 1)) + (margin / 10) - 10;
        int minY = margin / 2 + 50;
        int maxY = (margin / 2) + (size * cols) - 50;

        System.out.println(maxX - minX + " : " + (maxY - minY));

        if (e.getX() < maxX && e.getX() > minX && e.getY() < maxY && e.getY() > minY) {
            currentSide++;
            System.out.println("Clicked");
            if (currentSide >= cube[0][0].length) {
                currentSide = 0;
            }
        }
     */

    public Map(String title) {
        rows = 3;
        cols = 3;
        sides = 6;
        size = 120;
        cube = new int[rows][cols][sides];  // creates array
        ogMap = new int[rows][cols];
        int XDIM = cols * size + margin;
        int YDIM = rows * size + margin;
        random = new Random();
        canvas = new Canvas(title, XDIM, YDIM);
        canvas.wait(500);// Synch with system
        canvas.setForegroundColor(new Color(165, 179, 209));
        canvas.fillRectangle(0, 0, XDIM, YDIM);
    }

    public void randomSetCube() {
        for (int r = 0; r < cube.length; r++) {
            for (int c = 0; c < cube[r].length; c++) {
                Arrays.fill(cube[r][c], -1);
            }
        }
        int whites, reds, greens, blues, oranges, yellows;
        whites = reds = greens = blues = oranges = yellows = rows * cols;
        int[] colours = new int[]{
                whites, reds, greens, blues, oranges, yellows
        };

        int total = (rows * cols) * sides;
        while (total != 0) {
            int r = random.nextInt(rows), c = random.nextInt(cols), s = random.nextInt(sides), colour = random.nextInt(colours.length);
            if(cube[r][c][s] == -1 && colours[colour] != 0) {
                cube[r][c][s] = colour;
                colours[colour]--;
                total--;
            }
        }
    }

    public void run() {
        while(true) {
            genMap();

            int minX = (margin / 2) + (size * cols) + (margin / 10);
            int maxX = (margin / 2) + (size * (cols + 1)) + (margin / 10) - 10;
            int minY = margin / 2 + 50;
            int maxY = (margin / 2) + (size * cols) - 50;

            System.out.println(maxX - minX + " : " + (maxY - minY));

            if (canvas.getFrame().clickedX < maxX && canvas.getFrame().clickedX > minX
                    && canvas.getFrame().clickedY < maxY && canvas.getFrame().clickedY > minY) {
                currentSide++;
                System.out.println("Clicked");
                if (currentSide >= cube[0][0].length) {
                    currentSide = 0;
                }
            }
        }
    }

    public void genMap() {
        drawmap(currentSide);
    }

    public static void drawmap(int side) {
        for(int r = 0; r < rows; r++) {
            canvas.wait(waitTime);  // animation delay

            for(int c = 0; c < cols; c++) {
                canvas.setForegroundColor(Color.BLACK);
                canvas.fillRectangle(c * size + (margin / 2), r * size +(margin / 2), size, size);
                canvas.setForegroundColor(Map.colorof[cube[r][c][side]]);
                canvas.fillRectangle(c * size + 2 +(margin / 2), r * size + 2 +(margin / 2), size - 4, size - 4);
            }
        }

        canvas.setForegroundColor(Color.BLACK);
        canvas.fillPolygon(new int[]{(margin / 2) + (size * cols) + (margin / 10), (margin / 2) + (size * (cols + 1)) + (margin / 10) - 10,
                        (margin / 2) + (size * cols) + (margin / 10)}, new int[]{margin / 2 + 50, (margin / 2) + ((size * cols) / 2), (margin / 2) + (size * cols) - 50});
        canvas.setForegroundColor(Color.WHITE);
        canvas.fillPolygon(new int[]{(margin / 2) + (size * cols) + (margin / 10) + 3, (margin / 2) + (size * (cols + 1)) + (margin / 10) - 10 - 3,
                (margin / 2) + (size * cols) + (margin / 10) + 3}, new int[]{margin / 2 + 60, (margin / 2) + ((size * cols) / 2), (margin / 2) + (size * cols) - 60});

        canvas.setForegroundColor(Color.GREEN);
        canvas.drawString("Side: " + currentSide, 10, 10);
    }

    public static void drawcell(int r, int c, Color color) {
        canvas.setForegroundColor(Color.BLACK);
        canvas.fillRectangle(r * size, c * size, size, size);
        canvas.setForegroundColor(color);
        canvas.fillRectangle(r * size + 1, c * size + 1, size - 2, size - 2);
    }
}

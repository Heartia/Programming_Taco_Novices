package Competitive_Programming_3.Rubiks_Cube;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class JFrameMouse extends JFrame implements MouseListener {

    public int clickedX = -1, clickedY = -1;
    public int pressedX = -1, pressedY = -1;
    public int releasedX = -1, releasedY = -1;
    public int enteredX = -1, enteredY = -1;
    public int exitedX = -1, exitedY = -1;

    @Override
    public void mouseClicked(@org.jetbrains.annotations.NotNull MouseEvent e) {
        clickedX = e.getX();
        clickedY = e.getY();
    }

    @Override
    public void mousePressed(MouseEvent e) {
        pressedX = e.getX();
        pressedY = e.getY();
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        releasedX = e.getX();
        releasedY = e.getY();
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        enteredX = e.getX();
        enteredY = e.getY();
    }

    @Override
    public void mouseExited(MouseEvent e) {
        exitedX = e.getX();
        exitedY = e.getY();
    }
}

package Competitive_Programming_3.Rubiks_Cube;

import java.io.IOException;

public class Launcher {

    public static void main(String[] args) throws IOException {
        Map map = new Map("Rubik's Cube!");

        map.randomSetCube();
        map.run();
    }

}

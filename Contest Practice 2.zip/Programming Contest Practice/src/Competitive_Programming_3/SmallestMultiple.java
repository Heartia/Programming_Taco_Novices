package Competitive_Programming_3;

import java.io.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.NoSuchElementException;

public class SmallestMultiple {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("SmallestMultiple.dat")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        // lcm(a, b) = ab / gcd(a, b)

        String line;
        while ((line = br.readLine()) != null) {
            String[] data = line.split(" ");
            long[] vals = new long[data.length];
            for (int v = 0; v < data.length; v++) {
                vals[v] = Long.parseLong(data[v]);
            }
            pw.println(Arrays.toString(vals));
            pw.println("GCD : " + product(vals) / gcd(vals));
            pw.println("Max : " + max(vals));
            pw.println("Min : " + min(vals));
            pw.println("Sum : " + sum(vals));
            pw.println("------------------");
        }
        pw.close();
    }

    private static long product(long[] vals) {
        long product = 1;
        for (long v : vals) {
            product *= v;
        }
        return product;
    }

    private static long gcd(long[] vals) {
        long result = vals[0];
        for (int i = 1; i < vals.length; i++) {
            result = gcd(result, vals[i]);
        }
        return result;
    }

    private static long gcd(long a, long b) {
        if (a == 0) {
            return b;
        }
        return gcd(b % a, a);
    }

    private static boolean contains(int[] vals, int key) {
        for (int v : vals) {
            if (v == key) {
                return true;
            }
        }
        return false;
    }

    private static long max(long[] vals) {
        return Arrays.stream(vals).max().orElseThrow();
    }

    private static long min(long[] vals) {
        return Arrays.stream(vals).min().orElseThrow();
    }

    private static long sum(long[] vals) {
        return Arrays.stream(vals).sum();
    }

}

package Competitive_Programming_3.Pathfinding_AStar;

import java.io.IOException;

public class Launcher {

    public static void main(String[] args) throws IOException {
        Map map = new Map("Pathfinding - A Star");

        for (int i = 0; i < Integer.MAX_VALUE; i++) {
            map.genMap();
        }
    }

}

package Competitive_Programming_3.Pathfinding_AStar;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AStar {

    /**
     * If path was found, this method will return true and the path list will
     * be filled like this: {xn, yn, ..., x2, y2, x1, y1}
     * so the order is inverted.
     * x and y are the starting position.
     *
     * The algorithm makes sure to search in a clockwise direction, starting
     * upwards.
     *
     * @param map - The board traversed in the search
     * @param r - The current position's row value.
     * @param c - The current position's column value.
     * @param path - The path of locations that lead to the goal.
     * @return A boolean stating whether the path was found or not.
     */
    public static boolean searchPath(@NotNull int[][] map, int r, int c, List<Location> path, boolean canGoDiagonal, int distFromStart) {

        // Let's check if the target node was reached.
        if (map[r][c] == Map.END) {
            path.add(new Location(r, c, distFromStart));
            return true;
        }

        /*
        When the current position is a non-visited
        node, then it'll be marked as visited.
         */
        if (map[r][c] == Map.PATH || map[r][c] == Map.START) {
            map[r][c] = Map.PASSED;

            Map.drawmap();

            /*
            Let's visit all neighbour nodes recursively.
            If path was found, let's fill the path list
            with the current position.
             */

            List<Location> locations = getAdjacentLocations(new Location(r, c), canGoDiagonal);

            Collections.sort(locations);

            for (int i = 0; i < locations.size();) {
                if((locations.get(i).r != r ^ locations.get(i).c != c) && locations.get(i).isValid()
                        && searchPath(map, locations.get(i).r, locations.get(i).c, path, canGoDiagonal, distFromStart + Location.V_H_COST)) {
                    System.out.println(locations.get(i));
                    path.add(new Location(r, c));
                    Location locCheck = new Location(locations.get(i).r, locations.get(i).c, distFromStart + Location.V_H_COST);
                    checkForRemoval(path, getAdjacentLocations(locCheck, canGoDiagonal));
                    return true;
                }
                else if((locations.get(i).r != r && locations.get(i).c != c) && locations.get(i).isValid()
                        && searchPath(map, locations.get(i).r, locations.get(i).c, path, canGoDiagonal, distFromStart + Location.DIA_COST)) {
                    System.out.println(locations.get(i));
                    path.add(new Location(r, c));
                    Location locCheck = new Location(locations.get(i).r, locations.get(i).c, distFromStart + Location.DIA_COST);
                    checkForRemoval(path, getAdjacentLocations(locCheck, canGoDiagonal));
                    return true;
                }
                else {
                    i++;
                }
            }
        }

        return false;
    }

    /**
     * This ia a helper method to the searchPath method. It finds the adjacent locations of a passed in location and returns
     * said locations.
     * @param currLoc The given current location for calculations
     * @param canGoDiagonal A boolean that will determine whether diagonal locations will be counted as adjacent or not.
     * @return A list stating the locations adjacent to the location passed into the parameter.
     */
    private static List<Location> getAdjacentLocations(@NotNull Location currLoc, boolean canGoDiagonal) {
        List<Location> locations = new ArrayList<>();
        locations.add(new Location(currLoc.r - 1, currLoc.c, (int)currLoc.distFromStart + Location.V_H_COST));
        locations.add(new Location(currLoc.r, currLoc.c + 1, (int)currLoc.distFromStart + Location.V_H_COST));
        locations.add(new Location(currLoc.r + 1, currLoc.c, (int)currLoc.distFromStart + Location.V_H_COST));
        locations.add(new Location(currLoc.r, currLoc.c - 1, (int)currLoc.distFromStart + Location.V_H_COST));
        if (canGoDiagonal) {
            locations.add(new Location(currLoc.r - 1, currLoc.c - 1, (int)currLoc.distFromStart + Location.DIA_COST));
            locations.add(new Location(currLoc.r - 1, currLoc.c + 1, (int)currLoc.distFromStart + Location.DIA_COST));
            locations.add(new Location(currLoc.r + 1, currLoc.c - 1, (int)currLoc.distFromStart + Location.DIA_COST));
            locations.add(new Location(currLoc.r + 1, currLoc.c + 1, (int)currLoc.distFromStart + Location.DIA_COST));
        }
        return locations;
    }

    /**
     * This is a helper method to the searchPath method. It checks to see if there are any unnecessary locations in the
     *  given path, and if so, it removes said location.
     * @param path The current path being located to find the shortest path to a location.
     * @param adjacentLocs The adjacent locations to the passed in current location.
     * @return A boolean, stating whether it was successful in removing a location from the passed in path.
     */
    private static boolean checkForRemoval(@NotNull List<Location> path, List<Location> adjacentLocs) {
        boolean removed = false;
        List<Location> check = new ArrayList<>();
        for (Location location : path) {
            if (adjacentLocs.contains(location)) {
                check.add(location);
            }
        }
        System.out.println(check);
        if (check.size() > 0) {
            removed = true;
        }
        return removed;
    }

}

package Competitive_Programming_3.Pathfinding_AStar;

import java.util.Objects;

public class Location implements Comparable<Location> {

    int r, c;
    double distFromStart, heuristicCost, finalCost;
    static int V_H_COST = 10;
    static int DIA_COST = 14;

    Location(int r, int c) {
        this.r = r;
        this.c = c;

        distFromStart += Math.abs(r - Map.startR) * V_H_COST;
        distFromStart += Math.abs(c - Map.startC) * V_H_COST;

        heuristicCost += Math.abs(r - Map.endR) * V_H_COST;
        heuristicCost += Math.abs(c - Map.endC) * V_H_COST;

        // heuristicCost = Math.sqrt(Math.pow(Map.endR - r, 2) + Math.pow(Map.endC - c, 2)) * DIA_COST;
        finalCost = heuristicCost + distFromStart;
    }

    Location(int r, int c, int distFromStart) {
        this.r = r;
        this.c = c;

        this.distFromStart = distFromStart;

        heuristicCost += Math.abs(r - Map.endR) * V_H_COST;
        heuristicCost += Math.abs(c - Map.endC) * V_H_COST;

        finalCost = heuristicCost + distFromStart;
    }

    boolean isTile(int tile) {
        if (r >= 0 && r < Map.rows && c >= 0 && c < Map.cols) {
            if (Map.map[r][c] == tile) {
                return true;
            }
        }
        return false;
    }

    boolean isValid() {
        if (r >= 0 && r < Map.rows && c >= 0 && c < Map.cols) {
            return true;
        }
        return false;
    }

    @Override
    public int compareTo(Location o) {
        if(finalCost != o.finalCost) {
            return Integer.compare((int) finalCost, (int) o.finalCost);
        }
        else {
            return Integer.compare((int) heuristicCost, (int) o.heuristicCost);
        }

        //return Integer.compare((int) finalCost, (int) o.finalCost);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Location location = (Location) o;
        return r == location.r &&
                c == location.c &&
                Double.compare(location.distFromStart, distFromStart) == 0 &&
                Double.compare(location.heuristicCost, heuristicCost) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(r, c, distFromStart, heuristicCost, finalCost);
    }

    @Override
    public String toString() {
        return "Location at ( " + r + ", " + c + " ) { " +
                "distFromStart = " + distFromStart +
                " : heuristicCost = " + heuristicCost +
                " : finalCost = " + finalCost +
                " }";
    }
}

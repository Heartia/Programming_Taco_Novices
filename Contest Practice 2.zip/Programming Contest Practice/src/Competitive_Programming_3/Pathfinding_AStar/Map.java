package Competitive_Programming_3.Pathfinding_AStar;

import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Map {

    static final int WALL = 0;
    static final int PATH = 1;
    static final int PASSED = 2;
    static final int START = 3;
    static final int END = 4;
    static final int CHECKED = 5;

    static int[][] map;      // array representing map
    private static int[][] ogMap;
    static int rows;   // number of rows in array
    static int cols;   // number of columns in array
    private static int size;  // size of graphical representation (cells)
    static int startR = 0, startC = 0;
    static int endR = rows - 1, endC = cols - 1;
    private static Random random;
    private static Canvas canvas;
    private static Color[] colorof = {Color.BLACK, Color.WHITE, Color.GREEN, Color.YELLOW, Color.RED, new Color(0, 128, 0)};
    private static BufferedReader br;
    private static ArrayList<Location> path = new ArrayList<>();
    private static int waitTime = 10;

    static {
        try {
            br = new BufferedReader(new FileReader(new File("Map4.dat")));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public Map(String title) throws IOException {
        String[] data = br.readLine().split("\\s");
        rows = Integer.parseInt(data[0]);
        cols = Integer.parseInt(data[1]);
        size = Integer.parseInt(data[2]);
        map = new int[rows][cols];  // creates array
        ogMap = new int[rows][cols];
        int XDIM = cols * size;
        int YDIM = rows * size;
        random = new Random();
        canvas = new Canvas(title, XDIM, YDIM);
        canvas.wait(500);// Synch with system
        canvas.setForegroundColor(new Color(55, 120, 161));
        canvas.fillRectangle(0, 0, XDIM, YDIM);
        readMap();
    }

    public void readMap() throws IOException {
        for (int r = 0; r < map.length; r++) {
            String[] line = br.readLine().split("\\s");

            for (int c = 0; c < line.length; c++) {
                map[r][c] = Integer.parseInt(line[c]);
                if (map[r][c] == Map.START) {
                    startR = r;
                    startC = c;
                }
                if (map[r][c] == Map.END) {
                    endR = r;
                    endC = c;
                }
            }
        }
    }

    public void genMap() {
        for (int r = 0; r < rows; r++) {
            ogMap[r] = Arrays.copyOf(map[r], map[r].length);
        }
        System.out.println("****************************************************************************************************");
        AStar.searchPath(map, startR, startC, path, false, 0);
        canvas.wait(waitTime);
        for (int i = 0; i < path.size(); i++) {
            drawcell(path.get(i).c, path.get(i).r, Color.CYAN);
            canvas.wait(waitTime * 10);
        }
        canvas.wait(waitTime * 50);
        for (int r = 0; r < rows; r++) {
            map[r] = Arrays.copyOf(ogMap[r], map[r].length);
            drawmap();
        }
        canvas.wait(waitTime * 10);
        path.clear();
    }

    public static void drawmap() {
        for(int r = 0; r < rows; r++) {

            canvas.wait(waitTime);  // animation delay

            for(int c = 0; c < cols; c++) {
                canvas.setForegroundColor(Color.BLACK);
                canvas.fillRectangle(c * size, r * size, size, size);
                canvas.setForegroundColor(Map.colorof[map[r][c]]);
                canvas.fillRectangle(c * size + 1, r * size + 1, size - 2, size - 2);
            }
        }
    }

    public static void drawcell(int r, int c, Color color) {
        canvas.setForegroundColor(Color.BLACK);
        canvas.fillRectangle(r * size, c * size, size, size);
        canvas.setForegroundColor(color);
        canvas.fillRectangle(r * size + 1, c * size + 1, size - 2, size - 2);
    }
}

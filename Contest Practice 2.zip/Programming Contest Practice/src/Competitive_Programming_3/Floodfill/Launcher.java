package Competitive_Programming_3.Floodfill;

import java.io.IOException;

public class Launcher {

    public static void main(String[] args) throws IOException {
        FloodMap map = new FloodMap("Floodfill");

        for (long i = 0; i < Long.MAX_VALUE; i++) {
            map.genMap();
        }
    }

}

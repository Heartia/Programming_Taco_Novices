package Competitive_Programming_3.Floodfill;

import org.jetbrains.annotations.NotNull;

public class Floodfill {

    public static void floodfill(@NotNull int[][] map, int r, int c) {
        map[r][c] = FloodMap.PASSED;
        FloodMap.drawmap();

        // Search up
        if(r - 1 >= 0 && map[r - 1][c] == FloodMap.PATH) {
            floodfill(map, r - 1, c);
        }
        // Search right
        if(c + 1 < map[r].length && map[r][c + 1] == FloodMap.PATH) {
            floodfill(map, r, c + 1);
        }
        // Search down
        if(r + 1 < map.length && map[r + 1][c] == FloodMap.PATH) {
            floodfill(map, r + 1, c);
        }
        // Search left
        if(c - 1 >= 0 && map[r][c - 1] == FloodMap.PATH) {
            floodfill(map, r, c - 1);
        }
    }

}

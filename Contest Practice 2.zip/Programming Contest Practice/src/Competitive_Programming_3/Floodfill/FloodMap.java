package Competitive_Programming_3.Floodfill;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FloodMap {

    static final int WALL = 0;
    static final int PATH = 1;
    static final int PASSED = 2;
    static final int START = 3;

    private static int startR = 0, startC = 0;
    private static int[][] map;      // array representing map
    private static int[][] ogMap;
    private static int rows;   // number of rows in array
    private static int cols;   // number of columns in array
    private static int size;  // size of graphical representation (cells)
    private static Random random;
    private static Canvas canvas;
    private static Color[] colorof = {Color.BLACK, Color.WHITE, Color.GREEN, Color.YELLOW, Color.RED};
    private static BufferedReader br;
    private static ArrayList<Integer> path = new ArrayList<>();
    private static int waitTime = 3;

    Logger log = Logger.getLogger("Competitive_Programming_3.Floodfill.FloodMap");
    private static AudioPlayer audioPlayer;

    static {
        try {
            br = new BufferedReader(new FileReader(new File("FloodMap.dat")));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public FloodMap(String title) throws IOException {
        //String[] data = br.readLine().split("\\s");
        random = new Random();
        rows = 18;
        cols = 32;
        size = 40;
        map = genRandomMap(rows, cols);  // creates array
        ogMap = new int[rows][cols];
        int XDIM = cols * size;
        int YDIM = rows * size;
        canvas = new Canvas(title, XDIM, YDIM);
        canvas.wait(500);// Synch with system
        canvas.setForegroundColor(new Color(55, 120, 161));
        canvas.fillRectangle(0, 0, XDIM, YDIM);
        try {
            audioPlayer = new AudioPlayer();
            AudioPlayer.setFilePath("boop.wav");
        } catch (UnsupportedAudioFileException | LineUnavailableException e) {
           log.log(Level.SEVERE, "Problem importing files for audio", e);
        }
        //readMap();
    }

    public void readMap() throws IOException {
        for (int r = 0; r < map.length; r++) {
            String[] line = br.readLine().split("\\s");

            for (int c = 0; c < line.length; c++) {
                map[r][c] = Integer.parseInt(line[c]);
            }
        }
    }

    public void genMap() {
        startR = random.nextInt(rows);
        startC = random.nextInt(cols);
        Floodfill.floodfill(map, startR, startC);
        drawmap();
        canvas.wait(waitTime * 500);
        map = genRandomMap(rows, cols);
    }

    public int[][] genRandomMap(int rows, int cols) {
        int[][] map = new int[rows][cols];

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                map[r][c] = random.nextInt(2);
            }
        }

        return map;
    }

    public static void drawmap() {
        for(int i=0;i<rows;i++) {

            canvas.wait(waitTime);  // animation delay

            for (int j = 0; j < cols; j++) {
                canvas.setForegroundColor(Color.BLACK);
                canvas.fillRectangle(j * size, i * size, size, size);
                canvas.setForegroundColor(FloodMap.colorof[map[i][j]]);
                canvas.fillRectangle(j * size + 1, i * size + 1, size - 2, size - 2);
            }
        }
    }

    public static void drawcell(int r, int c, Color color) {
        canvas.setForegroundColor(Color.BLACK);
        canvas.fillRectangle(r * size, c * size, size, size);
        canvas.setForegroundColor(color);
        canvas.fillRectangle(r * size + 1, c * size + 1, size - 2, size - 2);
    }
}

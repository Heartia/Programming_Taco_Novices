package Competitive_Programming_3;

import org.jetbrains.annotations.NotNull;

import java.io.*;
import java.util.Arrays;

public class OrderUp {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("OrderUp.dat")));

        int caseNum = 0;
        String line;

        while ((line = br.readLine()) != null) {
            int nameAmt = Integer.parseInt(line);
            if (nameAmt == 0) {
                System.exit(0);
            }
            if (caseNum != 0) {
                System.out.println();
            }

            Name[] names = new Name[nameAmt];
            for (int n = 0; n < nameAmt; n++) {
                names[n] = new Name(br.readLine());
            }

            Arrays.sort(names);
            for (int n = 0; n < nameAmt; n++) {
                System.out.println(names[n]);
            }
            caseNum++;
        }
    }

}

class Name implements Comparable<Name> {

    String name;

    Name(String name) {
        this.name = name;
    }

    @Override
    public int compareTo(@NotNull Name other) {
        if(name.substring(0, 1).compareTo(other.name.substring(0, 1)) == 0) {
            return name.substring(1, 2).compareTo(other.name.substring(1, 2));
        }

        return name.substring(0, 1).compareTo(other.name.substring(0, 1));
    }

    @Override
    public String toString() {
        return name;
    }
}

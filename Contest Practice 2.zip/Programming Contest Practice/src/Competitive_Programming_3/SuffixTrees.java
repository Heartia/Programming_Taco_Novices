package Competitive_Programming_3;

public class SuffixTrees {

    static class SuffixTree {

        private static final int MAX_LENGTH = 1000;
        private static final int HASH_TABLE_SIZE = 2179;

        private char[] T = new char[MAX_LENGTH];
        private int N;
        private SuffixEdge[] Edges;
        private Node[] Nodes;

        private Suffix active;

        static class Node {
            public int suffix_node;
            public static int Count = 1;

            public Node() {
                suffix_node = -1;
            }
        }

        class Suffix {
            public int origin_node;
            public int first_char_index;
            public int last_char_index;

            public Suffix(int node, int start, int stop) {
                origin_node = node;
                first_char_index = start;
                last_char_index = stop;
            }

            public boolean Implicit() {
                return first_char_index > last_char_index;
            }

            public boolean Explicit() {
                return first_char_index > last_char_index;
            }

            /**
             * Function Canonize()
             * A suffix in the tree is denoted by a suffix structure
             * that denotes its last character.
             *
             * The canonical representation of a suffix for this
             * algorithm requires that the origin node by the closest
             * node to the end of the tree. To force this to be true,
             * we have to slide down every edge in our current path
             * until we reacht the final node.
             */
            public void Canonize() {

            }
        }

        class SuffixEdge {
            public int first_char_index;
            public int last_char_index;
            public int end_node;
            public int start_node;

            public SuffixEdge() {
                start_node = -1;
            }

            public SuffixEdge(int init_first, int init_last, int parent_node) {
                first_char_index = init_first;
                last_char_index = init_last;
                start_node = parent_node;
                end_node = Node.Count++;
            }

            public void Insert() {

            }

            public int SplitEdge(Suffix s) {
                return -1;
            }
        }

        public SuffixTree() {
            Edges = new SuffixEdge[HASH_TABLE_SIZE];
            for (int i = 0; i < HASH_TABLE_SIZE; i++) {
                Edges[i] = new SuffixEdge();
            }
            Nodes = new Node[MAX_LENGTH * 2];
            for (int i = 0; i < MAX_LENGTH * 2; i++) {
                Nodes[i] = new Node();
            }
            active = new Suffix(0, 0, -1);
        }

    }

}

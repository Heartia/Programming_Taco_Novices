package Competitive_Programming_3;

import java.io.*;

public class FishTank {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("FishTank.txt")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        String line;

        while ((line = br.readLine()) != null) {
            int vertices = Integer.parseInt(line);
            String[] data = br.readLine().split(" ");
            double depth = Double.parseDouble(data[0]);
            double litres = Double.parseDouble(data[1]);

            Coordinate[] coordinates = new Coordinate[vertices];
            for (int v = 0; v < vertices; v++) {
                coordinates[v] = new Coordinate(br.readLine());
            }

            double maxVolume = 0;
            double height, minY = coordinates[0].y, maxY = coordinates[0].y;

            for (int c = 0; c < coordinates.length - 1; c++) {
                maxVolume += coordinates[c].x * coordinates[c + 1].y;
                if (coordinates[c].y < minY) {
                    minY = coordinates[c].y;
                }
                if (coordinates[c].y > maxY) {
                    maxY = coordinates[c].y;
                }
            }
            for (int c = 0; c < coordinates.length - 1; c++) {
                maxVolume -= coordinates[c].y * coordinates[c + 1].x;
            }

            height = maxY - minY;
            maxVolume = (maxVolume / 2) * (depth * Math.pow(10, -2));
            pw.printf("%.2f", maxVolume);
            pw.println(" : " + height);
        }
        pw.close();
    }

}

class Coordinate {
    double x;
    double y;

    Coordinate(String info) {
        String[] data = info.split(" ");
        x = Double.parseDouble(data[0]);
        y = Double.parseDouble(data[1]);
    }
}

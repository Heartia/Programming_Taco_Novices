package Competitive_Programming_3;

import java.io.*;

public class Jollo {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("Jollo.txt")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        String line = "";

        while ((line = br.readLine()) != null && !line.equals("0 0 0 0 0")) {
            String[] data = line.split(" ");

            int[] cards = new int[data.length];

            for (int i = 0; i < data.length; i++) {
                cards[i] = Integer.parseInt(data[i]);
            }

            if (cards[0] > cards[3] && cards[1] > cards[4]) {
                pw.println(-1);
                continue;
            }
            else {
                pw.println(cards[2] + 1);
            }
        }

        pw.flush();
    }

}

package Competitive_Programming_3;

import java.io.*;

public class Alok {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("alok.dat")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        String line = "";
        double sum = 0;
        int count = 0;
        while ((line = br.readLine()) != null) {
            sum += Double.parseDouble(line);
            count++;
        }
        pw.format("$%.2f", sum);
        pw.println();
        pw.format("$%.2f", (sum / count));
        pw.close();
    }

}

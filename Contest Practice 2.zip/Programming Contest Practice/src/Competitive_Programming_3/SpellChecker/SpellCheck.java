package Competitive_Programming_3.SpellChecker;

import org.jetbrains.annotations.NotNull;

import java.io.*;
import java.util.*;

public class SpellCheck {

    String filename;

    private BufferedReader br;
    private PrintWriter pw;

    private List<String> dictionary = new ArrayList<>();

    SpellCheck(String filename) {
        pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
        try {
            br = new BufferedReader(new FileReader(new File(filename)));

            String line;
            while((line = br.readLine()) != null) {
                dictionary.addAll(Arrays.asList(line.toUpperCase().split("\\s")));
            }
        }
        catch(FileNotFoundException e) {
            pw.println("File not found: " + filename);
            pw.close();
        }
        catch(IOException e) {
            pw.println("An error with input occurred with: " + filename);
            pw.close();
        }

        Collections.sort(dictionary);
    }

    public String check(@NotNull String text) {
        int probableErrors = 0;
        StringBuilder report = new StringBuilder();
        String[] info = text.split("\\n");
        List<Integer> lineNums = new ArrayList<>();
        List<Integer> lineCorr = new ArrayList<>();
        List<String> problems = new ArrayList<>();

        for (int lineNum = 0; lineNum < info.length; lineNum++) {
            for (String word : info[lineNum].split("[\\s|_]+")) {
                String analysisWord = prepWordForAnalysis(word);
                if(word.length() == 1 || Collections.binarySearch(dictionary, analysisWord) >= 0) {
                    continue;
                }
                probableErrors++;
                problems.add(word);
                lineCorr.add(lineNum);
                if (lineNums.size() == 0 || lineNums.get(lineNums.size() - 1) != lineNum) {
                    lineNums.add(lineNum);
                }
            }
        }

        if (probableErrors == 0) {
            return "There were no errors found in this text.";
        }
        else {
            if (probableErrors == 1) {
                report.append("There was ").append(probableErrors).append(" error found\n");
            }
            else {
                report.append("There were ").append(probableErrors).append(" errors found\n");
            }
            report.append("Line numbers of errors: ");
            for (int num : lineNums) {
                report.append(num + 1).append(" ");
            }
            report.append("\nWords with errors: ");
            for (String str : problems) {
                report.append(str).append(" ");
            }
            report.append("\nPossible Solutions to errors:\n");
            for (int i = 0; i < probableErrors; i++) {
                report.append("On line ").append(lineCorr.get(i)).append(" the error ").append(problems.get(i)).append(" is likely ").append(spellingAnalysis(problems.get(i))).append("\n");
            }
        }

        return report.toString().trim();
    }

    private String prepWordForAnalysis(String word) {
        word = word.toUpperCase();
        word = word.replaceAll("[^\\p{L}\\p{Nd}]+", "");
        return word;
    }

    private String spellingAnalysis(String word) {
        String newWord = addedLetter(word);
        if (newWord.equals("N/A")) {
            return newWord;
        }
        return word;
    }

    private String addedLetter(String word) {
        if (Collections.binarySearch(dictionary, word) >= 0) {
            return word;
        }

        for (int i = 0; i < word.length(); i++) {
            String cutWord = word.substring(0, i) + word.substring(i + 1);
            if (Collections.binarySearch(dictionary, cutWord) >= 0)  {
                return cutWord;
            }
        }

        if (word.length() >= 2) {
            for (int i = 0; i < word.length() - 1; i++) {
                for (int j = 0; j < word.length() - 1; j++) {
                    String cutWord = "";
                    if (j < i) {
                        cutWord = word.substring(0, j) + word.substring(j + 1, i) + word.substring(i + 1);
                        String prepped = prepWordForAnalysis(cutWord);
                        System.out.println(prepped);
                        if (Collections.binarySearch(dictionary, prepped) >= 0)  {
                            return cutWord;
                        }
                    }
                    else if (j > i){
                        cutWord = word.substring(0, i) + word.substring(i + 1, j) + word.substring(j + 1);
                        String prepped = prepWordForAnalysis(cutWord);
                        System.out.println(prepped);
                        if (Collections.binarySearch(dictionary, prepped) >= 0)  {
                            return cutWord;
                        }
                    }
                }
            }
        }

        return "N/A";
    }
}

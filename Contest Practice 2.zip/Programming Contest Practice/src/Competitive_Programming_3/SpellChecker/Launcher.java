package Competitive_Programming_3.SpellChecker;

public class Launcher {

    public static void main(String[] args) {
        SpellCheck spellCheck = new SpellCheck("dictionary.txt");

        System.out.println(spellCheck.check("This is smoe test text\n" +
                "As you can see, it's pretty good text.\n" +
                "Veey very good.\n" +
                "Wait wait wait, you think it's not very good?\n" +
                "How poor for you. So, so stupid.\n" +
                "Fs in the caht for you."));

        System.out.println("\n" + spellCheck.check("This is who we are.\n" +
                "This is who I am.\n" +
                "And if hyou think you can stop me\n" +
                "I'm gonna need ya to think again.\n" +
                "I won't be falling down yo tou.\n" +
                "There'sno way I can go down now.\n" +
                "Let's go, just me and you.\n" +
                "Let's go, just one on two.\n" +
                "Go aheadn and try to hit me it your able.\n" +
                "If you think you can stop me you're unable."));
    }

}

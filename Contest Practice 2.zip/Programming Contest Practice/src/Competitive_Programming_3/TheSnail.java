package Competitive_Programming_3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class TheSnail {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        String line;
        boolean debug = false;
        while ((line = br.readLine()) != null) {
            String[] numString = line.split(" ");
            final int HEIGHT = 0, CLIMB = 1, FALL = 2, FATIGUE = 3;
            int[] nums = new int[numString.length];

            for (int i = 0; i < nums.length; i++) {
                nums[i] = Integer.parseInt(numString[i]);
            }

            if (Arrays.equals(nums, new int[]{0, 0, 0, 0})) {
                System.exit(0);
            }

            int height = nums[HEIGHT];
            double climb = nums[CLIMB];
            double fall = nums[FALL];
            double fatigue = (double)nums[FATIGUE] / 100;
            double distance = 0;
            int day = 0;

            while (distance < height && distance >= 0) {
                if (debug) {
                    System.out.println("Day " + day);
                    System.out.println("Initial height: " + distance);
                }
                distance += climb * (1 - (fatigue * day));
                if (distance >= height) break;
                distance -= fall;
                day++;
                if (debug) {
                    System.out.println("Height after sliding " + distance);
                }
            }

            if (distance >= height) {
                System.out.println("success on day " + (day + 1));
            }
            else if (distance < 0) {
                System.out.println("failure on day " + day);
            }
            else {
                System.out.println("Questionable success???");
            }
        }
    }

}

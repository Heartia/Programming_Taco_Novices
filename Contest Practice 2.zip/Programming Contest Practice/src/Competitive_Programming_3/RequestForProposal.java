package Competitive_Programming_3;

import java.io.*;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class RequestForProposal {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("RequestForProposal2.txt")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        String line;
        int RFP = 0;
        while ((line = br.readLine()) != null) {
            RFP++;
            if (RFP > 1) {
                pw.println();
            }
            String[] numString = line.split(" ");
            if (Arrays.equals(numString, new String[]{"0", "0"})) {
                System.exit(0);
            }
            int[] nums = new int[numString.length];

            for (int i = 0; i < nums.length; i++) {
                nums[i] = Integer.parseInt(numString[i]);
            }

            String[] proposals = new String[nums[0]];

            for (int p = 0; p < nums[0]; p++) {
                proposals[p] = br.readLine();
            }

            Proposal[] proposalList = new Proposal[nums[1]];

            for (int l = 0; l < proposalList.length; l++) {
                String name = br.readLine();
                String[] statStr = br.readLine().split(" ");
                double[] stats = new double[statStr.length];
                for (int d = 0; d < stats.length; d++) {
                    stats[d] = Double.parseDouble(statStr[d]);
                }
                String[] requirements = new String[(int)stats[1]];
                for (int s = 0; s < stats[1]; s++) {
                    requirements[s] = br.readLine();
                }
                proposalList[l] = new Proposal(name, stats[0], requirements, proposals, RFP);
            }

            Arrays.sort(proposalList);
            pw.println(proposalList[0]);
            pw.flush();
        }
        pw.close();
    }

    static class Proposal implements Comparable<Proposal> {

        String proposalName;
        double price;
        String[] requirements;
        int RFP;
        double compliance;

        Proposal(String proposalName, double price, String[] requirements, String[] totalRequirements, int RFP) {
            this.proposalName = proposalName;
            this.price = price;
            this.requirements = requirements.clone();
            this.RFP = RFP;
            compliance = checkCompliance(totalRequirements);
        }

        private double checkCompliance(String[] requirements) {
            return (double)matchesProposals(requirements) / requirements.length;
        }

        private int matchesProposals(String[] requirements) {
            int proposalMatch = 0;
            for (String thisRequirement : this.requirements) {
                for (String requirement : requirements) {
                    if (thisRequirement.equals(requirement)) {
                        proposalMatch++;
                    }
                }
            }
            return proposalMatch;
        }

        public String toString() {
            return "RFP #" + RFP + "\n" + proposalName;
        }

        @Override
        public int compareTo(Proposal other) {
            if (this.compliance > other.compliance) {
                return -1;
            }
            else if (this.compliance < other.compliance) {
                return 1;
            }
            else {
                return -Double.compare(other.price, this.price);
            }
        }
    }

}

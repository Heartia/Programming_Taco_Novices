package Competitive_Programming_3;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Bojing {

    static BufferedReader br;

    static {
        try {
            br = new BufferedReader(new FileReader(new File("bojing.dat")));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    static PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

    public static void main(String[] args) throws IOException {
        ArrayList<String> wordList = new ArrayList<>();

        String line;
        while ((line = br.readLine()) != null) {
            String[] wordArray = line.split(" ");
            wordList.addAll(Arrays.asList(wordArray));
        }

        wordList.sort(Comparator.comparingInt(String::length));
        int length = wordList.get(0).length();
        ArrayList<String> outputList = new ArrayList<>();
        int count = 0;

        for (String word : wordList) {
            if (word.length() > length) {
                outputList.sort(Comparator.naturalOrder());
                printList(outputList);
                count = 0;
                length = word.length();
                outputList.clear();

            }
            if (count == 0) {
                outputList.add(word);
            }
            else {
                outputList.add(word);
            }
            count++;
        }

        printList(outputList);
        pw.close();

    }

    private static void printList(List<String> wordList) {
        for (int i = 0; i < wordList.size(); i++) {
            if (i + 1 == wordList.size()) {
                pw.println(wordList.get(i));
            }
            else {
                pw.print(wordList.get(i) + " ");
            }
        }
    }

}

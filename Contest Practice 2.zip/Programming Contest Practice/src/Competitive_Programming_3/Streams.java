package Competitive_Programming_3;

import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.*;

import static javax.swing.UIManager.getColor;

public class Streams {

    public static void main(String[] args) {
        stringStreams();
    }

    private static void stringStreams() {
        String string = "Given a list of integers, of of which is in [1,2^32],\n" +
                "find the smallest integer that is a multiple of each of the given\n" +
                "numbers.";
        System.out.println(String.join(", ", Arrays.asList(string.split("\\s"))));
    }

    private static void intStreams() {
        IntStream declared = IntStream.of(1, 2, 3, 4, 5);
        // > 1, 2, 3, 4, 5
        IntStream rangeIncl = IntStream.range(1, 5);
        // > 1, 2, 3, 4
        IntStream rangeExcl = IntStream.rangeClosed(1, 5);
        // > 1, 2, 3, 4, 5
        IntStream rangeIter = IntStream.iterate(0, i -> i + 2).limit(3);
        // > 0, 2, 4
        // Starts at 0, goes for three times while iterating i by +2.
        IntStream random = IntStream.generate(() -> ThreadLocalRandom.current().nextInt(10)).limit(5);
        // > ?, ?, ?, ?, ?
        // This fills the IntStream with random values up to a limit.
        System.out.println(Arrays.toString(random.toArray()));

        declared = declared.map(i -> i * i);
        System.out.println(Arrays.toString(declared.toArray()));

        Stream<Color> stream = IntStream.range(1, 5).mapToObj(UIManager::getColor);

        Stream<Integer> differ = IntStream.rangeClosed(1, 5).map(i -> i * i).boxed();

        DoubleStream doubleStream = IntStream.range(1, 5).mapToDouble(i -> i);

        LongStream longStream = IntStream.range(1, 5).mapToLong(i -> i);
    }

}

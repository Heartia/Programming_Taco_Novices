package Competitive_Programming_3;

import java.io.*;

public class DontEverGamble {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("DontEverGamble.dat")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        int caseNum = 1;
        String line;

        while ((line = br.readLine()) != null) {
            String[] data = line.split(" ");
            int die1 = Integer.parseInt(data[0]);
            int die2 = Integer.parseInt(data[1]);
            pw.println("Test case #" + caseNum + ":");

            if (die1 < die2) {
                int difference = die2 - die1;
                int incre = 1;
                while (difference >= 0) {
                    pw.println(die1 + incre);
                    difference--;
                    incre++;
                }
            }
            else if (die2 < die1) {
                int difference = die1 - die2;
                int incre = 1;
                while (difference >= 0) {
                    pw.println(die2 + incre);
                    difference--;
                    incre++;
                }
            }
            else {
                pw.println(die1 + 1);
            }
            caseNum++;
        }
        pw.close();
    }

}

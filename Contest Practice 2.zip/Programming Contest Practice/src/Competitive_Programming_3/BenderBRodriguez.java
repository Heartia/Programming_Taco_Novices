package Competitive_Programming_3;

import java.io.*;

public class BenderBRodriguez {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        String line;
        while((line = br.readLine()) != null) {
            int length = Integer.parseInt(line);
            if (length == 0) {
                System.exit(0);
            }
            String direction = "+x";
            String[] turns = br.readLine().split(" ");
            for (int i = 0; i < length - 1; i++) {
                if (turns[i].equals("No")) {
                    continue;
                }
                else if (direction.contains("x")) {
                    if (direction.contains("-")) {
                        if (turns[i].contains("+")) {
                            turns[i] = "-" + turns[i].charAt(1);
                        }
                        else {
                            turns[i] = "+" + turns[i].charAt(1);
                        }
                    }
                    direction = turns[i];
                }
                else if (direction.charAt(1) == turns[i].charAt(1)) {
                    if (direction.charAt(0) == turns[i].charAt(0)) {
                        direction = "-x";
                    }
                    else {
                        direction = "+x";
                    }
                }
            }
            pw.println(direction);
            pw.flush();
        }
        pw.close();
    }

}

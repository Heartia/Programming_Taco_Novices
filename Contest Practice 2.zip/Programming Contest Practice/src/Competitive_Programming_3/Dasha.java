package Competitive_Programming_3;

import java.io.*;
import java.util.ArrayList;

public class Dasha {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("dasha.dat")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        int tests = Integer.parseInt(br.readLine());

        for (int t = 0; t < tests; t++) {
            String[] data = br.readLine().split(" ");
            int[] vals = new int[data.length];

            for (int v = 0; v < vals.length; v++) {
                vals[v] = Integer.parseInt(data[v]);
            }

            ArrayList<Integer> values = new ArrayList<>();
            int count = 1;
            int result = vals[3];
            values.add(result);

            for (int i = 0; i < vals[2]; i++) {
                result = (result * vals[0] + vals[1]) % vals[2];
                if (!values.contains(result)) {
                    values.add(result);
                    count++;
                }
                else {
                    break;
                }
            }

            if (count > vals[2]) {
                count = vals[2];
            }
            pw.println(count + " / " + vals[2]);
        }

        pw.close();
    }

}

package Competitive_Programming_3;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Stack;

public class WhatIsTheCard2 {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("WhatIsTheCard.txt"));

        int tests = scan.nextInt();

        for (int t = 1; t <= tests; t++) {
            Stack<Card> deck = new Stack<>();

            for (int i = 0; i < 52; i++) {
                deck.push(new Card(scan.next()));
            }

            Stack<Card> hand = new Stack<>();

            for (int i = 0; i < 25; i++) {
                hand.push(deck.pop());
            }

            int sum = 0, index = deck.size() - 1;

            for (int i = 0; i < 3; i++) {
                int value = deck.get(index).value;
                index--;
                sum += value;
                index -= (10 - value);
            }

            deck.addAll(hand);

            System.out.println("Case " + t + ": " + deck.get(deck.size() - sum));
        }
    }

    private static class Card {

        int value;
        char rank;
        char suit;

        Card(String info) {
            value = Character.isDigit(info.charAt(0)) ? Integer.parseInt(info.substring(0, 1)) : 10;
            rank = info.charAt(0);
            suit = info.charAt(1);
        }

        public String toString() {
            return rank + "" + suit;
        }

    }

}

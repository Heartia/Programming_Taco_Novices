package Competitive_Programming_3;

import java.io.*;

public class Raghav {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("raghav.dat")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        String line;
        int index = 1;
        while ((line = br.readLine()) != null) {
            if (index >= 50) {
                break;
            }

            int num = Integer.parseInt(line);

            if(index % 2 == 0) {
                num *= 2;
            }
            else {
                num += 7;
            }

            if(index % 3 == 0) {
                num *= 5;
            }
            if(index % 5 == 0) {
                num -= 11;
            }
            if(index % 7 == 0) {
                num *= num;
            }
            if(index % 10 == 0) {
                num /= 10;
            }
            if(index % 11 == 0) {
                num = (int)Math.sqrt(num);
            }

            pw.println(num);

            index++;
        }

        pw.close();
    }

}

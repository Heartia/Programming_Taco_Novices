package Competitive_Programming_3;

import java.io.*;

public class Nina {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("nina.dat")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        int tests = Integer.parseInt(br.readLine());

        for (int t = 1; t <= tests; t++) {
            double radius = Double.parseDouble(br.readLine());

            double sideLength = 2 * radius * Math.sin(Math.PI / 5);
            double area = (5 * Math.pow(sideLength, 2)) / (4 * Math.tan(Math.PI / 5));

            if (area > 43560) {
                pw.println("LOCATION #" + t + " WILL NOT FIT");
            }
            else {
                pw.print("LOCATION #" + t + " ");
                pw.format("%.2f", area);
                pw.print(" ");
                pw.format("%.2f", (5 * sideLength));
                pw.println();
            }
        }

        pw.close();
    }

}

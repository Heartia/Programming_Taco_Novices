package Competitive_Programming_3;

public class Santino {

    public static void main(String[] args) {

    }

}

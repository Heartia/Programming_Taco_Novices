package Competitive_Programming_3.Pathfinding_DepththFirst;

import java.util.List;

public class DepthFirst {

    /**
     * If path was found, this method will return true and the path list will
     * be filled like this: {xn, yn, ..., x2, y2, x1, y1}
     * so the order is inverted.
     * x and y are the starting position.
     *
     * The algorithm makes sure to search in a clockwise direction, starting
     * upwards.
     *
     * @param map - The board traversed in the search
     * @param r - The current position's row value.
     * @param c - The current position's column value.
     * @param path - The path of locations that lead to the goal.
     * @return A boolean stating whether the path was found or not.
     */
    public static boolean searchPath(int[][] map, int r, int c, List<Location> path) {

        // Let's check if the target node was reached.
        if (map[r][c] == Map.END) {
            path.add(new Location(r, c));
            return true;
        }

        /*
        When the current position is a non-visited
        node, then it'll be marked as visited.
         */
        if (map[r][c] == Map.PATH || map[r][c] == Map.START) {
            map[r][c] = Map.PASSED;
            Map.drawmap();

            /*
            Let's visit all neighbour nodes recursively.
            If path was found, let's fill the path list
            with the current position.
             */

            // Search up
            if(r - 1 >= 0 && searchPath(map, r - 1, c, path)) {
                Location loc = new Location(r, c);
                path.add(loc);
                System.out.println(loc);
                return true;
            }
            // Search right
            if(c + 1 < map[r].length && searchPath(map, r, c + 1, path)) {
                Location loc = new Location(r, c);
                path.add(loc);
                System.out.println(loc);
                return true;
            }
            // Search down
            if(r + 1 < map.length && searchPath(map, r + 1, c, path)) {
                Location loc = new Location(r, c);
                path.add(loc);
                System.out.println(loc);
                return true;
            }
            // Search left
            if(c - 1 >= 0 && searchPath(map, r, c - 1, path)) {
                Location loc = new Location(r, c);
                path.add(loc);
                System.out.println(loc);
                return true;
            }
        }

        return false;
    }

    public static boolean searchPathWDiagonals(int[][] map, int r, int c, List<Integer> path) {

        // Let's check if the target node was reached.
        if (map[r][c] == Map.END) {
            path.add(r);
            path.add(c);
            return true;
        }

        /*
        When the current position is a non-visited
        node, then it'll be marked as visited.
         */
        if (map[r][c] == Map.PATH || map[r][c] == Map.START) {
            map[r][c] = Map.PASSED;
            Map.drawmap();

            /*
            Let's visit all neighbour nodes recursively.
            If path was found, let's fill the path list
            with the current position.
             */

            // Search up
            if(r - 1 >= 0 && searchPathWDiagonals(map, r - 1, c, path)) {
                path.add(r);
                path.add(c);
                return true;
            }
            // Search upright
            if(r - 1 >= 0 && c + 1 < map[r].length && searchPathWDiagonals(map, r - 1, c + 1, path)) {
                path.add(r);
                path.add(c);
                return true;
            }
            // Search right
            if(c + 1 < map[r].length && searchPathWDiagonals(map, r, c + 1, path)) {
                path.add(r);
                path.add(c);
                return true;
            }
            // Search downright
            if(r + 1 < map.length && c + 1 < map[r].length && searchPathWDiagonals(map, r + 1, c + 1, path)) {
                path.add(r);
                path.add(c);
                return true;
            }
            // Search down
            if(r + 1 < map.length && searchPathWDiagonals(map, r + 1, c, path)) {
                path.add(r);
                path.add(c);
                return true;
            }
            // Search downleft
            if(r + 1 < map.length && c - 1 >= 0 && searchPathWDiagonals(map, r + 1, c - 1, path)) {
                path.add(r);
                path.add(c);
                return true;
            }
            // Search left
            if(c - 1 >= 0 && searchPathWDiagonals(map, r, c - 1, path)) {
                path.add(r);
                path.add(c);
                return true;
            }
            // Search upleft
            if(r - 1 >= 0 && c - 1 >= 0 && searchPathWDiagonals(map, r - 1, c - 1, path)) {
                path.add(r);
                path.add(c);
                return true;
            }
        }

        return false;
    }

}

package Competitive_Programming_3.Pathfinding_DepththFirst;

import java.util.Objects;

public class Location {

    int r, c;

    Location(int r, int c) {
        this.r = r;
        this.c = c;
    }

    boolean isTile(int tile) {
        if (r >= 0 && r < Map.rows && c >= 0 && c < Map.cols) {
            if (Map.map[r][c] == tile) {
                return true;
            }
        }
        return false;
    }

    boolean isValid() {
        if (r >= 0 && r < Map.rows && c >= 0 && c < Map.cols) {
            return true;
        }
        return false;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Location location = (Location) o;
        return r == location.r &&
                c == location.c;
    }

    @Override
    public int hashCode() {
        return Objects.hash(r, c);
    }

    @Override
    public String toString() {
        return "Location at ( " + r + ", " + c + " )";
    }
}

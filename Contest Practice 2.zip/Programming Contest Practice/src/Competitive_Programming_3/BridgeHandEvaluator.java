package Competitive_Programming_3;

import java.io.*;

public class BridgeHandEvaluator {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("BridgeHandEvaluator.txt")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        String line;
        while ((line = br.readLine()) != null) {
            BridgeHand hand = new BridgeHand(line.split(" "));
        }
    }

    private static class Card {

        String rank;
        String suit;

        public Card(String cardInfo) {
            rank = cardInfo.substring(0, 1);
            suit = cardInfo.substring(1);
        }

        public Card(String rank, String suit) {
            this.rank = rank;
            this.suit = suit;
        }

        public boolean equals(Object o) {
            if (rank.equals(((Card)o).rank) && suit.equals(((Card)o).suit)) {
                return true;
            }
            return false;
        }
    }

    private static class BridgeHand {

        Card[] cards;
        private int[] suitAmounts;
        private int[] rankAmounts;

        private static final int S = 0, H = 1, D = 2, C = 3;

        public BridgeHand(String[] handInfo) {
            Card[] cards = new Card[handInfo.length];
            for (int i = 0; i < cards.length; i++) {
                cards[i] = new Card(handInfo[i]);
            }
            suitAmounts = getAmountOfSuits();
            rankAmounts = getAmountOfRanks();
        }

        public BridgeHand(Card[] cards) {
            this.cards = cards;
            suitAmounts = getAmountOfSuits();
            rankAmounts = getAmountOfRanks();
        }

        public int evaluate() {
            int points = 0;
            // Step 1
            points += getAmountOfRankInHand("A") * 4;
            points += getAmountOfRankInHand("K") * 3;
            points += getAmountOfRankInHand("Q") * 2;

            // Step 2
            if (getAmountOfRankInHand("K") > 0) {
                for (Card c : cards) {
                    if (c.rank.equals("K")) {
                        int amount = 0;
                        String suit = c.suit;
                        for (Card check : cards) {
                            if (check.suit.equals(suit)) {
                                amount++;
                            }
                        }
                        if (amount == 1) {
                            points--;
                        }
                    }
                }
            }

            // Step 3
            if (getAmountOfRankInHand("Q") > 0) {
                for (Card c : cards) {
                    if (c.rank.equals("Q")) {
                        int amount = 0;
                        String suit = c.suit;
                        for (Card check : cards) {
                            if (check.suit.equals(suit)) {
                                amount++;
                            }
                        }
                        if (amount <= 2) {
                            points--;
                        }
                    }
                }
            }

            //Step 4
            if (getAmountOfRankInHand("J") > 0) {
                for (Card c : cards) {
                    if (c.rank.equals("J")) {
                        int amount = 0;
                        String suit = c.suit;
                        for (Card check : cards) {
                            if (check.suit.equals(suit)) {
                                amount++;
                            }
                        }
                        if (amount <= 3) {
                            points--;
                        }
                    }
                }
            }

            //Step 5
            for (int s : suitAmounts) {
                if (suitAmounts[s] == 2) {
                    points++;
                }
                else if (suitAmounts[s] <= 1) {
                    points += 2;
                }
            }

            return points;
        }

        public int getAmountInHand(Card card) {
            int amount = 0;
            for (Card c : cards) {
                if (c.equals(cards)) {
                    amount++;
                }
            }
            return amount;
        }

        public int getAmountOfRankInHand(String rank) {
            int amount = 0;
            for (Card c : cards) {
                if (c.rank.equals(rank)) {
                    amount++;
                }
            }
            return amount;
        }

        public int getAmountOfSuitInHand(String suit) {
            int amount = 0;
            for (Card c : cards) {
                if (c.suit.equals(suit)) {
                    amount++;
                }
            }
            return amount;
        }

        public int[] getAmountOfSuits() {
            int S = 0, H = 0, D = 0, C = 0;
            for (Card card : cards) {
                if (card.suit.equals("S")) {
                    S++;
                }
                else if (card.suit.equals("H")) {
                    H++;
                }
                else if (card.suit.equals("D")) {
                    D++;
                }
                else if (card.suit.equals("C")) {
                    C++;
                }
            }
            return new int[]{S, H, D, C};
        }

        public int[] getAmountOfRanks() {
            int A = 0, TWO = 0, THREE = 0, FOUR = 0, FIVE = 0,
                    SIX = 0, SEVEN = 0, EIGHT = 0, NINE = 0,
                    T = 0, J = 0, Q = 0, K = 0;

            for (Card card : cards) {
                if (card.rank.equals("A")) {
                    A++;
                }
                else if (card.rank.equals("2")) {
                    TWO++;
                }
                else if (card.rank.equals("3")) {
                    THREE++;
                }
                else if (card.rank.equals("4")) {
                    FOUR++;
                }
                else if (card.rank.equals("5")) {
                    FIVE++;
                }
                else if (card.rank.equals("6")) {
                    SIX++;
                }
                else if (card.rank.equals("7")) {
                    SEVEN++;
                }
                else if (card.rank.equals("8")) {
                    EIGHT++;
                }
                else if (card.rank.equals("9")) {
                    NINE++;
                }
                else if (card.rank.equals("T")) {
                    T++;
                }
                else if (card.rank.equals("J")) {
                    J++;
                }
                else if (card.rank.equals("Q")) {
                    Q++;
                }
                else if (card.rank.equals("K")) {
                    K++;
                }
            }

            return new int[]{A, TWO, THREE, FOUR, FIVE,
                    SIX, SEVEN, EIGHT, NINE,
                    T, J, Q, K};
        }

    }

}

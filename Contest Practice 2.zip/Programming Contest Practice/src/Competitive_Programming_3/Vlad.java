package Competitive_Programming_3;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;

public class Vlad {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("vlad.dat")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        ArrayList<Person> people = new ArrayList<>();

        String line;
        while ((line = br.readLine()) != null) {
            people.add(new Person(line));
        }

        Collections.sort(people);

        for (int i = 0; i < people.size(); i++) {
            pw.println(people.get(i));
        }
        pw.close();
    }

    static class Person implements Comparable<Person> {

        String firstname, lastname, middleinit;

        Person(String info) {
            String[] data = info.split("\\s");
            firstname = data[2];
            lastname = data[1].substring(0, data[1].length() - 1);
            if (3 == data.length) {
                middleinit = " ";
            }
            else {
                middleinit = data[3].substring(0, 1);
            }
        }

        public String toString() {
            if (!middleinit.equals(" ")) {
                return firstname + " " + middleinit + " " + lastname;
            }
            else {
                return firstname + " " + lastname;
            }
        }

        @Override
        public int compareTo(Person other) {
            if (lastname.compareTo(other.lastname) == 0) {
                if (firstname.compareTo(other.firstname) == 0) {
                    return middleinit.compareTo(other.middleinit);
                }
                else {
                    return firstname.compareTo(other.firstname);
                }
            }
            else {
                return lastname.compareTo(other.lastname);
            }
        }
    }

}

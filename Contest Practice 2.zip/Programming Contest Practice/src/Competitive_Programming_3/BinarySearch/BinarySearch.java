package Competitive_Programming_3.BinarySearch;

public class BinarySearch {

    /**
     * Returns index of x if it is present in arr[l..
     * r], else return -1
     * @param arr An sorted array of integers to be searched.
     * @param key The value to find in the array arr.
     * @return The first found index of the key. If key is not
     *      in arr, this method returns a negative value indicating
     *      the index in which the key would be at if in the array.
    */
    int binarySearch(int[] arr, int key) {
        int min = 0, max = arr.length - 1, mid = 0;

        while (min <= max) {
            mid = min + (max - min) / 2;

            // Check if x is present at mid
            if (arr[mid] == key)
                return mid;

            // If x greater, ignore left half
            if (arr[mid] < key)
                min = mid + 1;

                // If x is smaller, ignore right half
            else
                max = mid - 1;
        }

        // if we reach here, then element was
        // not present
        return -mid;
    }

}

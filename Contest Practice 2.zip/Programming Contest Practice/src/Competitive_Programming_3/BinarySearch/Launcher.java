package Competitive_Programming_3.BinarySearch;

import java.io.IOException;

public class Launcher {

    public static void main(String[] args) throws IOException {
        Base base = new Base("Binary Search", 1200, 800);
        base.run();
    }

}

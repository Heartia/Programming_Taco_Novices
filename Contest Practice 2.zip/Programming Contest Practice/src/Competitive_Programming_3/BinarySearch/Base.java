package Competitive_Programming_3.BinarySearch;

import Competitive_Programming_3.Canvas;

import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Random;

public class Base {

    static final int WALL = 0;
    static final int PATH = 1;
    static final int PASSED = 2;
    static final int START = 3;
    static final int END = 4;

    private static int startR = 0, startC = 0;
    static int xSize, ySize;
    private static Random random;
    private static Canvas canvas;
    private static Color[] colorof = {Color.BLACK, Color.WHITE, Color.GREEN, Color.YELLOW, Color.RED};
    private static BufferedReader br;
    private static int waitTime = 10;
    private static BinarySearch binarySearch = new BinarySearch();
    private static int[] values;
    private static int max;

    static {
        try {
            br = new BufferedReader(new FileReader(new File("MapRay.dat")));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public Base(String title, int xSize, int ySize) throws IOException {
        //String[] data = br.readLine().split("\\s");
        this.xSize = xSize;
        this.ySize = ySize;
        random = new Random();
        canvas = new Canvas(title, xSize, ySize);
        canvas.wait(500);// Synch with system
        canvas.setForegroundColor(Color.WHITE);
        canvas.fillRectangle(0, 0, xSize, ySize);
        max = 100;
        values = new int[100];
        for (int i = 0; i < values.length; i++) {
            values[i] = random.nextInt(max) + 1;
        }
        genMap();
    }

    public void run() {
        long max = 50000000;
        long l = 0;
        while(true) {
            if (l < max) {
                l++;
            }
            else {
                tick();
                genMap();
                l = 0;
            }
        }
    }

    public void readMap(int displacement) {
        for (int i = 0; i < values.length; i++) {

        }
    }

    public void genMap() {
        int displacement = 100;
        drawMap(displacement);
        readMap(displacement);
    }

    public void tick() {

    }

    public void drawMap(int displacement) {
        canvas.setForegroundColor(Color.BLACK);
        int thickness = 3;
        canvas.drawLine(displacement, displacement, displacement, ySize - displacement, thickness);
        canvas.drawLine(displacement, ySize - displacement, xSize - displacement, ySize - displacement, thickness);
        canvas.drawLine(xSize - displacement, displacement, xSize - displacement, ySize - displacement, thickness);
    }

    public String toString() {
        return "Base";
    }
}

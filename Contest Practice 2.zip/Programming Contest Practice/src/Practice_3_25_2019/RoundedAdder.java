package Practice_3_25_2019;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class RoundedAdder {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("rounded_adder.dat"));

        String formatter = "%." + scan.nextInt() + "f";
        double sum = 0;

        while (scan.hasNext()) {
            sum += Double.parseDouble(String.format(formatter, scan.nextDouble()));
        }

        System.out.printf(formatter, sum);
        System.out.println();
    }

}

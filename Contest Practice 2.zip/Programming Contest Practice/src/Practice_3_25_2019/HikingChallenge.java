package Practice_3_25_2019;

public class HikingChallenge {

    public static void main(String[] args) {

    }

}

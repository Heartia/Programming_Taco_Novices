package Practice_3_25_2019;

import java.util.Scanner;

public class BallDrop {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        for (int i = 0; i < 4; i++) {
            double num = scan.nextDouble();

            System.out.printf("%.2f", Math.sqrt(2 * num / 9.8));
            System.out.println(" second(s)");
        }
    }

}

package Practice_3_25_2019;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class ShapeRotation {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("shape_rotation.dat"));

        while (scan.hasNext()) {
            String[] widthHeight = scan.next().split("x");
            int[] dimensions = new int[widthHeight.length];

            for (int i = 0; i < widthHeight.length; i++) {
                dimensions[i] = Integer.parseInt(widthHeight[i]);
            }

            scan.next();
            int degrees = scan.nextInt();

            String[][] oldShape = new String[dimensions[0]][dimensions[1]];
            for (int i = 0; i < dimensions[1]; i++) {
                oldShape[i] = scan.next().split("");
            }

            System.out.println(getArrayToString(getTurnedShape(oldShape, degrees)));
        }
    }

    private static String getArrayToString(String[][] shape) {
        StringBuilder str = new StringBuilder();
        for (int r = 0; r < shape.length; r++) {
            for (int c = 0; c < shape[0].length; c++) {
                if (c + 1 < shape[0].length) {
                    str.append(shape[r][c]).append(" ");
                }
                else {
                    str.append(shape[r][c]);
                }
            }
            str.append("\n");
        }
        return str.toString();
    }

    private static String[][] getTurnedShape(String[][] shape, int degrees) {
        return shape;
    }

}

package Miscellaneous;

import java.io.File;
import java.util.Scanner;

public class SearchingForNessy {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int t = scan.nextInt();

        for (int i = 0; i < t; i++) {
            int n = scan.nextInt(), m = scan.nextInt();
            System.out.println((n / 3) * (m / 3));
            /*
            * Reasoning?
            * n is the height, m is the width.
            * n * m is the area of the grid.
            * Each sonar takes up 9 spaces, which is 1/9.
            *
            * This can then be solved with (n / 3) * (m / 3).
            * It's combining equations in simple algebra.
            *
            * (n * m) / 9 doesn't work, for some reason. It almost
            * does, but sometimes it is one number off.
            *
            * -----------------------------------------
            *
            * In terms of problems like these,
            * they can be solved using:
            *
            * (height / square of cover) * (width / square of cover)
             */
        }
    }
}

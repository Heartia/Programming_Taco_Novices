package Miscellaneous;

import java.util.Arrays;
import java.util.Scanner;

public class CD {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        while (scan.hasNext()) {
            int jackCDs = scan.nextInt(), jillCDs = scan.nextInt();
            int cdNum = 0;
            if (jackCDs == 0 && jillCDs == 0) {
                System.exit(0);
            }
            int[] CDs = new int[jackCDs];
            for (int j = 0; j < jackCDs; j++) {
                CDs[j] = scan.nextInt();
            }
            for (int j = 0; j < jillCDs; j++) {
                if (Arrays.binarySearch(CDs, scan.nextInt()) > -1) {
                    cdNum++;
                }
            }
            System.out.println(cdNum);
        }
    }

}

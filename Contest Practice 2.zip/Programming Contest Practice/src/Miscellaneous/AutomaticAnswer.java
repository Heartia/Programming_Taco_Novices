package Miscellaneous;

import java.util.Scanner;

public class AutomaticAnswer {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int t = scan.nextInt();

        for (int i = 0; i < t; i++) {
            int n = scan.nextInt();

            n = (((((n * 567) / 9) + 7492) * 235) / 47) - 498;

            StringBuilder s = new StringBuilder(n + "");
            s.reverse();

            System.out.println(s.charAt(1));
        }
    }
}

package Miscellaneous;

import java.io.File;
import java.util.Scanner;

public class Goro {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int x = scan.nextInt(); // The max we'll approximate pi to.
        double pi = 0.0; // The pi approximation value.
        // It's better to start with a value of 0 to add into rather than to make that later.
        int num = 1;

        for (int i = 0; i < x; i++) { // Increments through each individual term.
            if (i % 2 == 0) { // If even, add.
                pi += 1 / (num * Math.pow(3, i));
            }
            else { // If odd, subtract.
                pi -= 1 / (num * Math.pow(3, i));
            }
            num += 2; // The number that increases by 2 for the denominator of the equation.
            solve(pi);
        }
    }

    private static void solve(double pi) {
        // This finishes up the parenthesised part of the equation,
        // multiplying it by its' coefficient and formatting it.
        pi *= Math.sqrt(12);
        System.out.printf("%.5f\n", pi);
    }
}

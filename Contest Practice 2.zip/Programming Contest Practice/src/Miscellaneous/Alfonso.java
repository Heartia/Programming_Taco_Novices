package Miscellaneous;

public class Alfonso {
    public static void main(String[] args) {
        String line = "ACEGIKMOQSUWY";

        for (int i = 0; i < line.length(); i+=2) {
            for (int k = i; k < line.length(); k++) {
                System.out.println(line.substring(k));
            }
        }
    }
}

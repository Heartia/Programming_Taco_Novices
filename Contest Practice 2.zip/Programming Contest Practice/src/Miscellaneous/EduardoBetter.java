package Miscellaneous;

import java.util.Arrays;
import java.util.Scanner;

/**
 * How Brice coded it. Simple, quick and efficient.
 */

public class EduardoBetter {
    private static char[] alphabet = new char[]{'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
    'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        while (scan.hasNextLine()) {
            String s = scan.nextLine(); // Picks up an instance of each individual line to work out.
            s = s.toLowerCase();
            Scanner word = new Scanner(s); // Creates a new scanner to increment through each word.
            int shift = word.next().length()%26; // Gets the shift number for the word.

            for (int i = 0; i < s.length(); i++) { // Goes through each character in the line.
                if (!inAlphabet(s.charAt(i))) { // Checks to see if character is blank. If so, continue.
                    System.out.print(s.charAt(i));
                    continue;
                }
                System.out.print((char)((s.charAt(i) - 97 + shift) % 26 + 97)); // Shifts the character via a char.
            }
            System.out.println();
        }
    }

    private static boolean inAlphabet(char c) {
        return Arrays.binarySearch(alphabet, c) != -1;
    }
}

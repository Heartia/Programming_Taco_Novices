package Miscellaneous;

public class GoDataGo {

    public static void main(String[] args) {
        final int y2013 = 0, y2014 = 1, y2015 = 2, y2016 = 3, y2017 = 4,
                y2018 = 5, y2019 = 6;

        int[] courses = new int[7], videos = new int[7], quizzes = new int[7],
        lessons = new int[7], learners = new int[7], blogPosts = new int[7];

        String[] popular = new String[7], tidbits = new String[7];

        courses[y2013] = 4;
        videos[y2013] = -1;
        lessons[y2013] = -1;
        quizzes[y2013] = -1;
        learners[y2013] = -1;
        blogPosts[y2013] = 2;
        tidbits[y2013] = "- Records of Sololearn occur in 2001 as an empty site domain, yet Sololearn is never boughtt\n" +
                "\tuntil 2013.\n" +
                "- Sololearn was mostly app only - many webpages led you to the Google app.";

        courses[y2014] = 14;
        videos[y2014] = -1;
        lessons[y2014] = -1;
        quizzes[y2014] = -1;
        learners[y2014] = -1;
        blogPosts[y2014] = 0;
        tidbits[y2014] = "- The blog, oddly enough, just disappeared during a large part in this time.\n" +
                "- Makeup, dining etiquette, and photography also came to Sololearn, alongside the coding.";

        courses[y2015] = 10;
        videos[y2015] = 553;
        lessons[y2015] = 787;
        quizzes[y2015] = 2_325;
        learners[y2015] = 4_041_339;
        blogPosts[y2015] = 29;
        tidbits[y2015] = "- The website got updated into what it is today. The blog also reappeared.\n" +
                "- Sololearn became the biggest app in coding, and a very well recommended app in India. \n" +
                "- Makeup, photography and the like left, as Sololearn became made for coding only. \n" +
                "- Sololearn was also recognised by silicon valley, and essentially blew up in popularity.";

        courses[y2016] = 12;
        videos[y2016] = 0;
        lessons[y2016] = 916;
        quizzes[y2016] = 2_708;
        learners[y2016] = 12_737_376;
        blogPosts[y2016] = 31;
        popular[y2016] = "car \n- By Sutax Kapoor";
        tidbits[y2016] = "- The code playground came to mobile.\n" +
                "- Around August, 2016, videos disappeared.\n";

        courses[y2017] = 12;
        videos[y2017] = 0;
        lessons[y2017] = 940;
        quizzes[y2017] = 9_410;
        learners[y2017] = 20_846_684;
        blogPosts[y2017] = 36;
        popular[y2017] = "Emma's Paint Project \n- By Emma";
        tidbits[y2017] = "- By 2017, 42 Users reached platinum level, with 13 of them from India.\n" +
                "- 1293 Users reached gold level.\n" +
                "- 12,000 Users reached silver level.\n" +
                "- By 2017, Nikolay Nachev had the highest score in challenges, with 31,000 won matches (wow, wut)\n" +
                "- Krishna Teja, by 2017, unlocked 49 badges.\n" +
                "- Hetsy Rei, by 2017, submitted 3,200 posts.\n" +
                "- By 2017, there were 15 moderators.\n" +
                "- The most recent blog post by March 17th, 2019 came from this year.";

        courses[y2018] = 13;
        videos[y2018] = 0;
        lessons[y2018] = 1_572;
        quizzes[y2018] = 12_970;
        learners[y2018] = 27_949_873;
        blogPosts[y2018] = 36;
        popular[y2018] = "Find the Day of the Week You Were Born! \n- By Michael Xanthopoulos";
        tidbits[y2018] = "This was Sololearn's most popular year yet - although, 2019 still has 8.5 months left.";

        courses[y2019] = 13;
        videos[y2019] = 0;
        lessons[y2019] = 1_599;
        quizzes[y2019] = 13_714;
        learners[y2019] = 29_692_900;
        blogPosts[y2019] = 36;
        popular[y2019] = "Find the Day of the Week You Were Born! \n- By Emma";

        for (int i = 0; i < 7; i++) {
            System.out.println("The year " + (2013 + i));

            System.out.println("There were " + courses[i] + " courses by the year " + (2013 + i));

            if (videos[i] == -1) System.out.println("There are some videos that exist.");
            else System.out.println("There were " + videos[i] + " videos by the year " + (2013 + i));

            if (lessons[i] == -1) System.out.println("There are some lessons that exist.");
            else System.out.println("There were " + lessons[i] + " lessons by the year " + (2013 + i));

            if (quizzes[i] == -1) System.out.println("There are some quizzes that exist.");
            else System.out.println("There were " + quizzes[i] + " quizzes by the year " + (2013 + i));

            if (learners[i] == -1) System.out.println("There were certainly some learners there!");
            else System.out.println("There were " + learners[i] + " learners by the year " + (2013 + i));

            System.out.println("There were " + blogPosts[i] + " blog posts by the year " + (2013 + i));

            if (popular[i] != null) System.out.println("The most popular code by the year "+ (2013 + i) +
                    "\nwas \"" + popular[i] + "\"");

            if (tidbits[i] == null) System.out.println("Some other developments occurred this year.");
            else System.out.println("\n===============Some tidbits====================\n" + tidbits[i]);
            System.out.println("\n===============================================================\n" +
                    "===============================================================\n");
        }

        for (int i = 0; i < 7; i++) {
            System.out.println("The year " + (2013 + i));
            System.out.print("Courses | ");
            for (int c = 0; c < courses[i]; c++) {
                System.out.print("X");
            }
            System.out.println();
            System.out.print("Videos (x10) | ");
            for (int v = 0; v < videos[i]; v+=10) {
                System.out.print("X");
            }
            System.out.println();
            System.out.print("Lessons (x30) | ");
            for (int l = 0; l < lessons[i]; l+=30) {
                System.out.print("X");
            }
            System.out.println();
            System.out.print("Quizzes(x250) | ");
            for (int q = 0; q < quizzes[i]; q+=250) {
                System.out.print("X");
            }
            System.out.println();
            System.out.print("Learners (x1,000,000) | ");
            for (int l = 0; l < learners[i]; l+=1_000_000) {
                System.out.print("X");
            }
            System.out.println();
            System.out.print("Blogposts (x2) | ");
            for (int b = 0; b < blogPosts[i]; b+=2) {
                System.out.print("X");
            }
            System.out.println("\n");
        }
    }
}

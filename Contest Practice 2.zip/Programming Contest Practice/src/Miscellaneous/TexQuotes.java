package Miscellaneous;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

class TexQuotes {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("TexQuotes.txt"));
        scan.useDelimiter("");

        StringBuilder lines = new StringBuilder();

        boolean nextQuote = true;

        while (scan.hasNext()) {
            String character = scan.next();
            if (character.equals("\"")) {
                if (nextQuote) {
                    character = "``";
                }
                else {
                    character = "''";
                }
                nextQuote = !nextQuote;
            }
            lines.append(character);
        }
        System.out.print(lines);
    }
}

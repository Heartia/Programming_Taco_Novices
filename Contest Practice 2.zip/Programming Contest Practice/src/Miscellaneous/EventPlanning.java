package Miscellaneous;

import java.util.Scanner;

public class EventPlanning {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        while (scan.hasNext()) {
            int participants = scan.nextInt();
            int budget = scan.nextInt();
            int hotels = scan.nextInt();
            int[] weeks = new int[scan.nextInt()];

            for (int h = 0; h < hotels; h++) {
                int price = scan.nextInt();
                for (int w = 0; w < weeks.length; w++) {
                    weeks[w] = scan.nextInt();
                }
            }
        }
    }

}

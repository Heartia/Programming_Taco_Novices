package Miscellaneous;

public class IsPalindromeNum {

    public static void main(String[] args) {
        System.out.println(isPalindrome(-1));
    }

    private static boolean isPalindrome(int input) {
        int temp = input;
        int remain = 0;
        int sum = 0;

        while (input > 0) {
            remain = input % 10;
            sum = (sum * 10) + remain;
            input /= 10;
        }
        return temp == sum;
    }

}

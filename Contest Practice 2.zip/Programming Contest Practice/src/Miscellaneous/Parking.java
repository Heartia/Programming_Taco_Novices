package Miscellaneous;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Parking {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int t = scan.nextInt();

        for (int i = 0; i < t; i++) {
            int stores = scan.nextInt();

            ArrayList<Integer> positions = new ArrayList<>();

            for (int l = 0; l < stores; l++) {
                positions.add(scan.nextInt());
            }

            int min = Collections.min(positions);
            int max = Collections.max(positions);

            System.out.println((max - min) * 2);
        }
    }
}

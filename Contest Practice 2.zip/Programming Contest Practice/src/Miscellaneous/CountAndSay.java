package Miscellaneous;

public class CountAndSay {

    public static void main(String[] args) {
        System.out.println(countAndSay(1001));
    }

    public static String countAndSay(int n) {
        if (n <= 0) {
            return "";
        }

        String num = n + "";
        if (num.startsWith("11")) return "21" + countAndSay(n / 100);
        else if (num.startsWith("21")) return "1211" + countAndSay(n / 100);
        else if (num.startsWith("1")) return "11" + countAndSay(n / 10);
        return "";
    }

}

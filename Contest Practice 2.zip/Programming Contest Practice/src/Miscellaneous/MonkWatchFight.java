package Miscellaneous;

import java.util.Scanner;
import java.util.TreeSet;

public class MonkWatchFight {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        BinarySearchTree BST = new BinarySearchTree();

        int n = scan.nextInt();

        for (int i = 0; i < n; i++) {
            BST.insert(scan.nextInt());
        }
    }

    static class BinarySearchTree {

        class Node {
            int key;
            Node left, right;

            public Node(int key) {
                this.key = key;
                left = right = null;
            }
        }

        Node root;

        BinarySearchTree() {
            root = null;
        }

        void insert(int key) {
            root = insertRec(root, key);
        }

        Node insertRec(Node root, int key) {
            if (root == null) {
                root = new Node(key);
                return root;
            }

            if (key < root.key) {
                root.left = insertRec(root.left, key);
            }
            else if (key > root.key) {
                root.right = insertRec(root.right, key);
            }
            return root;
        }

    }
}

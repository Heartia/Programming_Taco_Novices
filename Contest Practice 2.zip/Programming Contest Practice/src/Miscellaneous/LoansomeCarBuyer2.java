package Miscellaneous;

import java.util.Scanner;

public class LoansomeCarBuyer2 {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        while (scan.hasNext()) {
            int duration = scan.nextInt(), month, recordAmt;

            if (duration < 0) System.exit(0);

            double loan = scan.nextDouble(), downPay = scan.nextDouble();

            double[] records = new double[duration];
            recordAmt = scan.nextInt();

            for (int r = 0; r < recordAmt; r++) {
                month = scan.nextInt();
                double dep = scan.nextDouble();
                for (int m = month; m < duration; m++) records[m] = dep;
            }
            int time = 0;
            double monthlyPay = loan / duration;
            double carValue = (loan + downPay) * (1 - records[0]);

            while (carValue < loan) {
                time += 1;
                loan -= monthlyPay;
                carValue -= carValue * records[time];
            }

            System.out.print(time + " month");
            System.out.println(time != 1 ? "s" : "");
        }
    }
}

package Miscellaneous;

public class ReverseInteger {

    public static void main(String[] args) {
        System.out.println(reverse(-2147483412));
    }

    public static int reverse(long input) {
        long val = 0;
        do {
            val = val * 10 + input % 10;
            input /= 10;
        } while (input != 0);

        return (val > Integer.MAX_VALUE || val < Integer.MIN_VALUE) ? 0 : (int)val;
    }

}

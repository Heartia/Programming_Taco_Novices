package Miscellaneous;

import java.util.Scanner;

public class DivisionOfNlogonia {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        while (scan.hasNext()) {
            int K = scan.nextInt();

            if (K == 0) System.exit(0);

            int dX = scan.nextInt(), dY = scan.nextInt();

            for (int i = 0; i < K; i++) {
                int x = scan.nextInt(), y = scan.nextInt();

                if (x == dX || y == dY) {
                    System.out.println("divisa");
                    continue;
                }

                if (x > dX) {
                    if (y > dY) {
                        System.out.println("NE");
                    }
                    else {
                        System.out.println("SE");
                    }
                }
                else {
                    if (y > dY) {
                        System.out.println("NO");
                    }
                    else {
                        System.out.println("SO");
                    }
                }
            }
        }
    }
}

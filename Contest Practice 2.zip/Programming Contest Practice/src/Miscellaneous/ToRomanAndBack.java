package Miscellaneous;

import java.util.HashMap;
import java.util.Scanner;

/*
This code converts any number to roman numerals and any roman numerals to numbers.

Probably a common question:
Why is one coded recursively and one coded iteratively?

...

Don't ask. I'm still learning, okay!? I wanted to experiment two ways of doing this thing.
On the plus side, it shows how recursion can be compact, I guess?

You can also put in fake roman numerals and see what you get...? Sometimes it's just
-1, but sometimes it actually evaluates it. The roman to number system isn't perfect.
*/

public class ToRomanAndBack {

    private static HashMap<Integer, String> romNums = new HashMap<>();

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        fillMap();

        while (scan.hasNext()) {
            String evaluate = scan.next();
            if (isNumeric(evaluate)) System.out.println(toRomNum(Integer.parseInt(evaluate)));
            else System.out.println(toArabic(evaluate));
        }
    }

    private static void fillMap() { // Used for the iterative one that converts numbers to roman numerals.
        romNums.put(1000, "M");
        romNums.put(900, "CM");
        romNums.put(500, "D");
        romNums.put(400, "CD");
        romNums.put(100, "C");
        romNums.put(90, "XC");
        romNums.put(50, "L");
        romNums.put(40, "XL");
        romNums.put(10, "X");
        romNums.put(9, "IX");
        romNums.put(5, "V");
        romNums.put(4, "IV");
        romNums.put(1, "I");
    }

    private static String toRomNum(int num) { // Converts number to roman numeral - the iterative one.
        StringBuilder romNum = new StringBuilder();

        while (num >= 1000) {
            romNum.append(romNums.get(1000));
            num -= 1000;
        }
        while (num >= 900) {
            romNum.append(romNums.get(900));
            num -= 900;
        }
        while (num >= 500) {
            romNum.append(romNums.get(500));
            num -= 500;
        }
        while (num >= 400) {
            romNum.append(romNums.get(400));
            num -= 400;
        }
        while (num >= 100) {
            romNum.append(romNums.get(100));
            num -= 100;
        }
        while (num >= 90) {
            romNum.append(romNums.get(90));
            num -= 90;
        }
        while (num >= 50) {
            romNum.append(romNums.get(50));
            num -= 50;
        }
        while (num >= 40) {
            romNum.append(romNums.get(40));
            num -= 40;
        }
        while (num >= 10) {
            romNum.append(romNums.get(10));
            num -= 10;
        }
        while (num >= 9) {
            romNum.append(romNums.get(9));
            num -= 9;
        }
        while (num >= 5) {
            romNum.append(romNums.get(5));
            num -= 5;
        }
        while (num >= 4) {
            romNum.append(romNums.get(4));
            num -= 4;
        }
        while (num >= 1) {
            romNum.append(romNums.get(1));
            num -= 1;
        }
        return romNum.toString();
    }

    private static int toArabic(String number) { // From roman numeral to number. The recursive one.
        // Looks better, right? I coded this a week after the iterative one.
        if (number.isEmpty()) return 0;
        if (number.startsWith("M")) return 1000 + toArabic(number.substring(1));
        if (number.startsWith("CM")) return 900 + toArabic(number.substring(2));
        if (number.startsWith("D")) return 500 + toArabic(number.substring(1));
        if (number.startsWith("CD")) return 400 + toArabic(number.substring(2));
        if (number.startsWith("C")) return 100 + toArabic(number.substring(1));
        if (number.startsWith("XC")) return 90 + toArabic(number.substring(2));
        if (number.startsWith("L")) return 50 + toArabic(number.substring(1));
        if (number.startsWith("XL")) return 40 + toArabic(number.substring(2));
        if (number.startsWith("X")) return 10 + toArabic(number.substring(1));
        if (number.startsWith("IX")) return 9 + toArabic(number.substring(2));
        if (number.startsWith("V")) return 5 + toArabic(number.substring(1));
        if (number.startsWith("IV")) return 4 + toArabic(number.substring(2));
        if (number.startsWith("I")) return 1 + toArabic(number.substring(1));
        return -1;
    }

    public static boolean isNumeric(String str) { // Checks if a number is numeric - from StackOverflow
        return str.matches("-?\\d+(\\.\\d+)?");  //match a number with optional '-' and decimal.
    }
}
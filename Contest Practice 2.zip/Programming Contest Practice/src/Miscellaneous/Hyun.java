package Miscellaneous;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Hyun {

    private static String[][] keyboard;
    private static final int NUMBER = 0, TOP = 1, HOME = 2, BOTTOM = 3;

    private static void fillKeyboard() {
        keyboard = new String[4][];
        keyboard[NUMBER] = new String[]{"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
        keyboard[TOP] = new String[]{"q", "w", "e", "r", "t", "y", "u", "i", "o", "p"};
        keyboard[HOME] = new String[]{"a", "s", "d", "f", "g", "h", "j", "k", "l"};
        keyboard[BOTTOM] = new String[]{"z", "x", "c", "v", "b", "n", "m"};
    }

    private static boolean findInArray(String letter, String[] array) {
        for (int i = 0; i < array.length; i++) {
            if (letter.equals(array[i])) {
                return true;
            }
        }
        return false;
    }

    private static String areasOnKeyboard(String line) {
        StringBuilder isOn = new StringBuilder();
        Set<String> isOnSet = new HashSet<>();

        String[] letters = line.split("");

        for (int l = 0; l < letters.length; l++) {
            if (!isOnSet.contains("NUMBER") && findInArray(letters[l], keyboard[NUMBER])) {
                isOnSet.add("NUMBER");
            }
            else if (!isOnSet.contains("TOP") && findInArray(letters[l], keyboard[TOP])) {
                isOnSet.add("TOP");
            }
            else if (!isOnSet.contains("HOME") && findInArray(letters[l], keyboard[HOME])) {
                isOnSet.add("HOME");
            }
            else if (!isOnSet.contains("BOTTOM") && findInArray(letters[l], keyboard[BOTTOM])) {
                isOnSet.add("BOTTOM");
            }
        }

        if (isOnSet.contains("NUMBER")) isOn.append("NUMBER ");
        if (isOnSet.contains("TOP")) isOn.append("TOP ");
        if (isOnSet.contains("HOME")) isOn.append("HOME ");
        if (isOnSet.contains("BOTTOM")) isOn.append("BOTTOM");

        return isOn.toString();
    }

    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("Hyun.dat"));

        fillKeyboard();

        int t = scan.nextInt();
        scan.nextLine();

        for (int i = 1; i <= t; i++) {
            String line = scan.nextLine();

            System.out.println("Case #" + i + ": " + areasOnKeyboard(line).trim());
        }
    }
}

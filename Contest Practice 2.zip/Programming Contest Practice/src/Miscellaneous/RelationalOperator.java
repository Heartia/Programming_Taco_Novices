package Miscellaneous;

import java.util.Scanner;

public class RelationalOperator {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int t = scan.nextInt();

        for (int i = 0; i < t; i++) {
            int num1 = scan.nextInt(), num2 = scan.nextInt();

            if (num1 > num2) System.out.println(">");
            else if (num1 < num2) System.out.println("<");
            else System.out.println("=");
        }
    }
}

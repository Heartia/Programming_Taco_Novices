package Miscellaneous;

import java.util.Scanner;
import java.util.function.BiFunction;
import java.util.function.Function;

public class Functionals {

    private static Scanner scan = new Scanner(System.in);

    private static Integer compute(Function<Integer, Integer>function, Integer value) {
        return function.apply(value);
        /*
        This is a very simple higher order function.
        It takes the arguments and returns the methods
        output.

        You can also do invert(value), but you
        passed in function as the parameter, so...
         */
    }

    private static Integer invert(Integer value) {
        return -value;
    }

    private static Integer invertTheNumber() {
        int toInvert = scan.nextInt();
        Function<Integer, Integer> invertFunction = Functionals::invert;
        /*
        This is a method reference. The :: operator
        takes the function invert and stores it in
        a function object. This way, you can use
        it like an object.
         */
        return compute(invertFunction, toInvert);
    }

    private static Integer invertTheNumberBetter() {
        int toInvert = scan.nextInt();
        return compute((a) -> -a, toInvert);
    }

    /*****************************************/

    private Integer add(Integer a, Integer b) {
        return a + b;
    }

    public static void main(String[] args) {
        System.out.println(invertTheNumber());
        BiFunction<Integer, Integer, Integer> add = (a, b) -> a + b;
        // Same as calling add(a, b)
        /*
        (a, b) is the same as making parameters. Save for how a & b
        not needing types.

        -> Is the same as adding curly brackets. For example:
         */
        BiFunction<Integer, Integer, Integer> weakAdd = (a, b) -> {
            Integer result = a + b;
            return result;
        }; /*
        You can also do this, usually for multi-line calculations.

        With lambdas, the compute function can be made nicer.
        */
    }

}

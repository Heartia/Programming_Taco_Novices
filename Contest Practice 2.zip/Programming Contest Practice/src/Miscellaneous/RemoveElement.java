package Miscellaneous;

import java.util.Arrays;

public class RemoveElement {

    public static void main(String[] args) {
        System.out.println(removeElement(new int[]{0,1,2,2,3,0,4,2}, 2));
    }

    private static int removeElement(int[] nums, int val) {
        int i = 0;
        for (int n : nums) { // Iterates through all the elements
            if (n != val) { // Checks if n isn't equal to key
                nums[i] = n; // Shifts the values
                System.out.println(Arrays.toString(nums) + " : " + n + " : " + i);
                i++; // Increments the count for returning and shifting
            }
            else {
                System.out.println(n + " : " + i);
            }
        }
        return i;
    }

}

package Miscellaneous;

import java.util.*;

public class Exercise1_2_3 {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        /*double d = scan.nextDouble();

        System.out.printf("%12.0f", d);

        String formatter = "%.";
        int precision = scan.nextInt();
        formatter += precision;
        formatter += "f";

        System.out.printf(formatter, Math.PI);*/

        /*String[] months = new String[]{"January", "February", "March", "April", "May", "June", "July", "August",
        "September", "October", "November", "December"};

        int day = scan.nextInt();
        String monthStr = scan.next();
        int month = -1;
        for (int i = 0; i < months.length; i++) {
            if (months[i].equalsIgnoreCase(monthStr)) {
                month = i;
            }
        }
        int year = scan.nextInt();

        GregorianCalendar date = new GregorianCalendar(year, month, day);

        String monthDay = date.getTime().toString().substring(0, 3);

        if (monthDay.equals("Mon")) System.out.println("Monday");
        else if (monthDay.equals("Tue")) System.out.println("Tuesday");
        else if (monthDay.equals("Wed")) System.out.println("Wednesday");
        else if (monthDay.equals("Thu")) System.out.println("Thursday");
        else if (monthDay.equals("Fri")) System.out.println("Friday");
        else if (monthDay.equals("Sat")) System.out.println("Saturday");
        else if (monthDay.equals("Sun")) System.out.println("Sunday");*/

        /*List<Integer> list = new ArrayList<>();

        while (scan.hasNextInt()) {
            list.add(scan.nextInt());
        }

        Collections.sort(list);

        Set<Integer> set = new HashSet<>();

        for (int i = 0; i < list.size(); i++) {
            set.add(i);
        }

        System.out.println(set);*/

        List<birthdays> list = new ArrayList<>();

        list.add(new birthdays(12, 24, 3600));
        list.add(new birthdays(8, 12, 2158));
        list.add(new birthdays(4, 6, 32));
        list.add(new birthdays(3, 9, 852));
        list.add(new birthdays(3, 9, 853));

        Collections.sort(list);

        System.out.println(list);

        String str = "ABC";
        int n = str.length();
        permute(str, 0, n-1);
    }

    /**
     * permutation function
     * @param str string to calculate permutation for
     * @param l starting index
     * @param r end index
     */
    private static void permute(String str, int l, int r)
    {
        if (l == r)
            System.out.println(str);
        else
        {
            for (int i = l; i <= r; i++)
            {
                str = swap(str,l,i);
                permute(str, l+1, r);
                str = swap(str,l,i);
            }
        }
    }

    /**
     * Swap Characters at position
     * @param a string value
     * @param i position 1
     * @param j position 2
     * @return swapped string
     */
    public static String swap(String a, int i, int j)
    {
        char temp;
        char[] charArray = a.toCharArray();
        temp = charArray[i] ;
        charArray[i] = charArray[j];
        charArray[j] = temp;
        return String.valueOf(charArray);
    }

}

class BinarySearch {

    static int binarySearch(int[] array, int l, int r, int x) {
        if (r >= 1) {
            int mid = l + (r - 1) / 2;

            // If the element is present at the middle itself
            if (array[mid] == x) return mid;

            // If element is smaller than mid, it can only be
            // in the left subarray.
            if (array[mid] > x) return binarySearch(array, l, mid - 1, x);

            // Else the element can only be present in right
            // subarray

            return binarySearch(array, mid + 1, r, x);
        }

        // If element is not present in array
        return -1;
    }

}


class birthdays implements Comparable<birthdays> {

    int month, day, year;

    birthdays (int month, int day, int year) {
        this.month = month;
        this.day = day;
        this.year = year;
    }

    @Override
    public String toString() {
        String dayTime = String.format("%02d", day);
        String monthTime = String.format("%02d", month);
        String yearTime = String.format("%04d", year);
        return "(" + dayTime + " " + monthTime + " " + yearTime + ")";
    }

    @Override
    public int compareTo(birthdays b) {
        if (b.month == month) {
            if (b.day == day) {
                return this.year - b.year;
            }
            return this.day - b.day;
        }
        return this.month - b.month;
    }
}
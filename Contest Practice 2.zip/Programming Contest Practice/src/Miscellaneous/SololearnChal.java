package Miscellaneous;

public class SololearnChal {
    public static void main(String[] args) {
        System.out.println("/a/a/".replaceAll("/", "/"));
        System.out.println("a/a/a".replaceAll("/", "/"));
        System.out.println("/a/a/a".replaceAll("/", ""));
        System.out.println("\\a\\a\\a".replaceAll("\\\\", "\\\\"));
    }
}
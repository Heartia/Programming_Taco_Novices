package Miscellaneous;

import java.util.HashMap;
import java.util.Scanner;

public class Bryce {
    private static HashMap<Integer, String> romNums = new HashMap<>();

    private static void fillMap() {
        romNums.put(1000, "M");
        romNums.put(900, "CM");
        romNums.put(500, "D");
        romNums.put(400, "CD");
        romNums.put(100, "C");
        romNums.put(90, "XC");
        romNums.put(50, "L");
        romNums.put(40, "XL");
        romNums.put(10, "X");
        romNums.put(9, "IX");
        romNums.put(5, "V");
        romNums.put(4, "IV");
        romNums.put(1, "I");
    }

    private static String toRomNum(int num) {
        StringBuilder romNum = new StringBuilder();

        while (num >= 1000) {
            romNum.append(romNums.get(1000));
            num -= 1000;
        }
        while (num >= 900) {
            romNum.append(romNums.get(900));
            num -= 900;
        }
        while (num >= 500) {
            romNum.append(romNums.get(500));
            num -= 500;
        }
        while (num >= 400) {
            romNum.append(romNums.get(400));
            num -= 400;
        }
        while (num >= 100) {
            romNum.append(romNums.get(100));
            num -= 100;
        }
        while (num >= 90) {
            romNum.append(romNums.get(90));
            num -= 90;
        }
        while (num >= 50) {
            romNum.append(romNums.get(50));
            num -= 50;
        }
        while (num >= 40) {
            romNum.append(romNums.get(40));
            num -= 40;
        }
        while (num >= 10) {
            romNum.append(romNums.get(10));
            num -= 10;
        }
        while (num >= 9) {
            romNum.append(romNums.get(9));
            num -= 9;
        }
        while (num >= 5) {
            romNum.append(romNums.get(5));
            num -= 5;
        }
        while (num >= 4) {
            romNum.append(romNums.get(4));
            num -= 4;
        }
        while (num >= 1) {
            romNum.append(romNums.get(1));
            num -= 1;
        }
        return romNum.toString();
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        fillMap();
        while (scan.hasNext()) {
            System.out.println(toRomNum(scan.nextInt()));
        }
    }
}

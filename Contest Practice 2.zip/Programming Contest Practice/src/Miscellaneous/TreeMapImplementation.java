package Miscellaneous;

import java.util.Comparator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class TreeMapImplementation {

    static class TreeCompare implements Comparator<String> {

        @Override
        public int compare(String o1, String o2) {
            int i, j, k;

            i = o1.lastIndexOf(' ');
            j = o2.lastIndexOf(' ');
            k = o1.substring(i).compareToIgnoreCase(o2.substring(j));

            if (k == 0) return o1.compareToIgnoreCase(o2);
            else return k;
        }
    }

    public static void main(String[] args) {
        TreeMap<String, Double> tm = new TreeMap<>(new TreeCompare());

        tm.put("Head First Java", 807.34);
        tm.put("Java: A Beginners Guide 6th "+
                "Edition", 593.05);
        tm.put("Java: The Complete Reference"+
                " 9th Edition", 531.31);
        tm.put("Core Java Volume I_Fundamentals"+
                " 9th Edition", 544.34);
        tm.put("Effective Java 2nd Edition", 373.70);

        // Values can be null
        tm.put("Java 8 in action", null);

        // Last entry with the same key
        // reflected in output
        tm.put("Java 8 in action", 539.65);

        Set<Map.Entry<String, Double>> set = tm.entrySet();
        for (Map.Entry<String, Double> me : set) {
            System.out.println(me.getKey() + ": Rs." + me.getValue());
        }

        tm.remove("Core Java Volume I_Fundamentals 9th Edition");
        System.out.println("...After removal of Core Java..." +
                "\n==================================================");
        for (Map.Entry<String, Double> me : set) {
            System.out.println(me.getKey() + ": Rs." + me.getValue());
        }
    }

}

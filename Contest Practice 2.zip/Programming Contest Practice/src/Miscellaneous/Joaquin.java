package Miscellaneous;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Joaquin {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("Joaquin.dat"));

        int repeat = scan.nextInt();
        scan.nextLine();

        for (int i = 0; i < repeat; i++) {
            int tSize = scan.nextInt(); // Gets the width and length of the square.
            boolean[][] grid = new boolean[tSize][tSize]; // Creates 2D array for storing the square.
            // The beginning and ending rows and columns for the square.
            int startRow = 0;
            int endRow = startRow + tSize - 1;
            int startCol = 0;
            int endCol = startCol + tSize - 1;

            while (startRow <= endRow) { // For each iteration, sets where the Xs will be.
                for (int r = startRow; r <= endRow; r++) { // Affects the rows
                    grid[r][startCol] = true;
                    grid[r][endCol] = true;
                }
                for (int c = startCol; c <= endCol; c++) { // Affects the columns
                    grid[startRow][c] = true;
                    grid[endRow][c] = true;
                }
                startRow += 2;
                endRow -= 2;
                startCol += 2;
                endCol -= 2;
            }
            // Prints the 2D array out.
            for (boolean[] bArr : grid) {
                for (boolean b : bArr) {
                    if (b) {
                        System.out.print("X");
                    }
                    else
                        System.out.print(" ");
                }
                System.out.println();
            }
            System.out.println("--------------------");
        }
    }
}

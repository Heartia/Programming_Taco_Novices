package Miscellaneous;

import java.util.Scanner;

public class LoansomeCarBuyer {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        while (scan.hasNext()) {
            int months = scan.nextInt();

            if (months < 0) System.exit(0);

            double downPay = scan.nextDouble();
            double loanAmt = scan.nextDouble();
            double carWorth = loanAmt + downPay;
            int recordAmt = scan.nextInt();

            double[] records = new double[months];

            for (int r = 0; r < recordAmt; r++) {
                int month = scan.nextInt();
                double record = scan.nextDouble();
                records[month] = record;
            }

            double depreciate = 0.0;

            for (int m = 0; m < records.length; m++) {
                loanAmt -= downPay;
                if (records[m] != 0.0) depreciate = records[m];
                carWorth *= 1 - (depreciate);
                System.out.println(loanAmt + " " + carWorth);

                if (loanAmt < carWorth) {
                    System.out.println((m + 1) + " months");
                    break;
                }
            }
        }
    }

}

package Miscellaneous;

import static java.lang.Math.*;

public class SololearnDiscuss {

    public static void main(String[] args) {
        int x = 1;
        x = (++x) + (++x) + x;
        System.out.println(x);

        x = 10;

        x += x++ + ++x + x;
        System.out.println(x);

        int a;
        int sum = 0;
        for (a = 3; a > 1; a /= a++) {
            sum += a;
        }

        int count = 0;
        while (count != 8) {
            ++count;
        }
        System.out.print("patel".substring(1, "patel".length() - 1));
        int xo = 1, y;
        y = xo++;
        System.out.println(y + "" + x);
    }
}

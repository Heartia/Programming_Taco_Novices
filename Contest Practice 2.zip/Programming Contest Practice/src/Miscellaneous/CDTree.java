package Miscellaneous;

public class CDTree {

    public static void main(String[] args) {

    }

}

class BST {

    class Node {
        int key;
        Node left, right;

        public Node(int key) {
            this.key = key;
            left = right = null;
        }
    }

    Node root;

    public BST() {
        root = null;
    }

    void insert(int key) {
        root = insertRec(root, key);
    }

    Node insertRec(Node node, int key) {
        if (root == null) {
            root = new Node(key);
            return root;
        }

        return root;
    }

}

package Miscellaneous;

import java.util.*;

public class Cartoonish {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int t = scan.nextInt();
        Gem.fillNames();

        for (int i = 0; i < t; i++) {
            System.out.println(new Gem());
        }
    }

    static class Gem {
        private Random random;
        String name, description;
        static HashMap<String, String> names = new HashMap<>();

        Gem() {
            random = new Random();
            int index = random.nextInt(names.size());
            String[] indices = Arrays.copyOf(names.keySet().toArray(), names.keySet().toArray().length, String[].class);
            name = indices[random.nextInt(indices.length)];
            description = names.get(name);
        }

        static void fillNames() {
            names.put("Rose Quartz", "The leader of a rebellion, an identity not existing."); // My third favourite before a certain reveal
            names.put("Blue Pearl", "The calm servant of Blue Diamond. She likes to draw. She's also my favourite."); // My favourite gem
            names.put("Pink Pearl", "The servant of deceased Pink Diamond. She was possessed by White Diamond.");
            names.put("Yellow Pearl", "The electric and narcissistic servant of Yellow Diamond.");
            names.put("Pearl", "The renegade of the rebellion, once bound to Pink Diamond, but not anymore."); // My second favourite gem
            names.put("Amethyst", "The fun and purple gem. Serving the crystal gems, she never was alive for the rebellion.");
            names.put("Ruby", "The hot headed gal with cowboy dreams, wife to Sapphire");
            names.put("Sapphire", "The introspective girl of ideas, wife to Ruby."); // My fourth favourite gem
            names.put("Peridot", "The slightly egotistic green tech genius, with a dorito chip shaped head.");
            names.put("Bismuth", "The rainbow haired blacksmith of strength.");
            names.put("Lapis Lazuli", "The once conflicted and PTSD ridden girl, now clearer than ever. She bends oceans like nothing."); // My current third favourite gem
            names.put("Biggs Jasper", "A fun quartz, once lost to corruption, but now here once again.");
            names.put("Yellow Diamond", "The tempered woman who rules over Homeworld, recently opening up.");
            names.put("Blue Diamond", "The sappy woman who rules over Homeworld, recently feeling happiness.");
            names.put("Pink Diamond", "The childish woman who once ruled over Homeworld, changing form to oppose Homeworld long ago.");
            names.put("White Diamond", "The perfectionist woman who rules over Homeworld, recently changing her mind.");
            names.put("Emerald", "A dedicated war general, serving Yellow Diamond.");
            names.put("Hessonite", "A garnet who, as a war commander, lost a certain light in her life.");
            names.put("Aquamarine", "The scouter who has an overpowered wand.");
            names.put("Nephrite", "The corrupted gem who loves chaaaps, recently healed from that corruption.");
            names.put("Squaridot", "The bootleg Peridot with dirty square hair.");
            names.put("Jasper", "The motivated warrior who may have just lost her purpose in a new era.");
            names.put("Holly Blue Agate", "Protector of a certain zoo that may need to be disbanded.");
            names.put("Yellow Zircon", "The far too inquisitive lawyer.");
            names.put("Blue Zircon", "A very reserved lawyer.");
            names.put("Doc Ruby", "A natural leader.");
            names.put("Eyeball Ruby", "The devoted foot soldier.");
            names.put("Leggy Ruby", "An absent-minded fellow.");
            names.put("Army Ruby", "A rowdy ruby.");
            names.put("Navy Ruby", "The master deceptionist.");
            names.put("Padparadscha", "A bit slow, but always fun."); // My fifth favourite gem

            names.put("Topaz", "A fusion who just wants to live in peace.");
            names.put("Garnet", "A fusion of love.");
            names.put("Opal", "A fusion with conflicting mindsets, but can stay together when needed.");
            names.put("Sugilite", "An expensive fusion that has never spoken since season 1. Also rowdy.");
            names.put("Alexandrite", "The rainbow fusion of Crystal Gem Unity.");
            names.put("Rainbow Quartz", "A beautiful fusion, dancing with flow.");
            names.put("Rainbow Quartz 2.0", "A fun fusion, with a poppin parasol.");
            names.put("Sardonyx", "A orange show host of comedy.");
            names.put("Obsidian", "The fullness of Crystal Gem Unity.");
            names.put("Sunstone", "A hot, hot leader fusion. Gets a bit meta.");
            names.put("Smoky Quartz", "Smoky fun.");
            names.put("Stevonnie", "The homeworld shock, unity between a gem and a human.");
            names.put("Malachite", "A toxic gemstone representing a toxic fusion.");
            names.put("Mega Ruby", "Three rubies, four rubies - Fuse to get bigger and stronger!");
            names.put("Lemon Jade", "A cute fusion between two gems who deserve to be together.");
            names.put("Flourite", "A fusion of many.");
            names.put("Rhodonite", "A fusion of an anxiety filled two. Frightened, but cute.");

            names.put("Steven", "The new leader of the Crystal gems");
            names.put("Connie", "A swordsgirl who supports many");
            names.put("Greg", "A guitar hero who learned many lessons and teaches them to his son.");
        }

        @Override
        public String toString() {
            return name + " - " + description;
        }
    }
}

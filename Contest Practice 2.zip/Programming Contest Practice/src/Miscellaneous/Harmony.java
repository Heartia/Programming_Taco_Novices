package Miscellaneous;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Harmony
{

    public static void main(String[] args) throws IOException
    {
        Scanner read = new Scanner(new File("harmony.dat"));
        int repeat = read.nextInt();
        read.nextLine();
        for(int i=0;i<repeat;i++) {
            String nums = read.nextLine();
            char[] chars = nums.toCharArray();
            int bigNums = 0;
            int odds = 0;
            int evens = 0;
            int lastDigit = Integer.parseInt(nums.substring(nums.length()-1));
            for(int j=0;j<chars.length-1;j++) {

                if(j%2==0) {
                    odds+=chars[j]-48;
                    if(chars[j]-48>=5) {
                        bigNums++;
                    }
                }
                else
                    evens+=chars[j]-48;
            }
            int totalSum = odds*3+evens+bigNums;

            String calcSum = totalSum+"";

            int computedLastDigit = 10-Integer.parseInt(calcSum.substring(calcSum.length()-1));

            if(computedLastDigit ==10)
                computedLastDigit = 0;

            System.out.println(calcSum);
            System.out.print(nums+ " ");
            if(lastDigit== computedLastDigit) {
                System.out.println("VALID");
            }

            else {
                System.out.println("INVALID " + computedLastDigit);
            }



//			System.out.println(totalSum);
//			long calcCheck = 10-Integer.parseInt(nums.substring(nums.length()-1));
//			System.out.print(nums+ " ");
//			if(calcCheck==nums.charAt(nums.length()-1)-48) {
//				System.out.println("VALID");
//			}
//			else {
//				System.out.println("INVALID " + calcCheck);
//			}
        }
    }

}
package Miscellaneous;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Riley {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("Riley.dat"));
        int t = scan.nextInt();

        for (int i = 0; i < t; i++) {
            int[][] fireGrid = new int[scan.nextInt()][scan.nextInt()]; // Filling in the grid.
            for (int r = 0; r < fireGrid.length; r++) {
                for (int c = 0; c < fireGrid[0].length; c++) {
                    fireGrid[r][c] = scan.nextInt();
                }
            }
            int sum = 0;
            for (int r = 0; r < fireGrid.length; r++) {
                for (int c = 0; c < fireGrid[0].length; c++) {
                    sum = floodFill(r, c, fireGrid);
                    if (sum != 0) {
                        System.out.println(sum);
                    }
                }
            }
        }
    }

    //private static int floodFill(int r, int c, int[][] grid) {
    //    if (r >= 0 && r < grid.length && c >= 0 && c < grid[0].length && grid[r][c] != 0) {
    //        System.out.println(grid[r][c]);
    //        grid[r][c] = 0;
    //        return floodFill(r - 1, c - 1, grid) + floodFill(r - 1, c, grid) + floodFill(r - 1, c + 1, grid) +
    //                floodFill(r, c + 1, grid) + floodFill(r, c - 1, grid) +
    //                floodFill(r + 1, c - 1, grid) + floodFill(r + 1, c, grid) + floodFill(r + 1, c + 1, grid);
    //    }
    //    return 0;
    //}

    private static int floodFill(int r, int c, int[][] grid) {
        // Termination case
        if (r < 0 || c < 0 || r > grid.length || c > grid[0].length) {
            return 0;
        }
        // Base case
        if (grid[r][c] == 0) {
            return 0;
        }
        // Recursive case
        grid[r][c] = 0;
        return floodFill(r - 1, c - 1, grid) + floodFill(r - 1, c, grid) + floodFill(r - 1, c + 1, grid) +
                floodFill(r, c + 1, grid) + floodFill(r, c - 1, grid) +
                floodFill(r + 1, c - 1, grid) + floodFill(r + 1, c, grid) + floodFill(r + 1, c + 1, grid);
    }
}

package Miscellaneous;

import java.util.Scanner;

/**
 * How Sheldon coded it. Long, inefficient, and complex.
 */

public class Eduardo {

    private static String[] alphabet = new String[]{"a", "b", "c", "d", "e", "f", "g", "h", "i",
    "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};

    private static int findInAlphabet(String letter) {
        for (int i = 0; i < alphabet.length; i++) {
            if (letter.equals(alphabet[i])) {
                return i;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            String[] words = line.split("\\s");
            int shiftNum = words[0].length();

            for (int i = 0; i < words.length; i++) {
                String[] letters = words[i].split("");
                for (int j = 0; j < words[i].length(); j++) {
                    int shift = findInAlphabet(letters[j]);
                    shift += shiftNum;
                    while (shift > 25) {
                        shift %= 25;
                        shift -= 1;
                    }
                    System.out.print(alphabet[shift]);
                }
                System.out.print(" ");
            }
            System.out.println();
        }
    }
}

package Miscellaneous;

import java.util.Scanner;

public class Nisha {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int x = 5;
        System.out.println(x);
    }

}

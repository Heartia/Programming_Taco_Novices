package Miscellaneous;

import java.util.Scanner;

public class Barb {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int t = scan.nextInt();
        System.out.println("A   A*A   3*A   A/2");

        for (int i = 1; i <= t; i++) {
            System.out.println(i + "     " + (i * i) + "     " + (3 * i) + "     " + (i / 2));
        }
    }
}

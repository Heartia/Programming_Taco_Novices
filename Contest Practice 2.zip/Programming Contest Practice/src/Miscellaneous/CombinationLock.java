package Miscellaneous;

import java.util.Scanner;

public class CombinationLock {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        while (scan.hasNext()) {
            int position = scan.nextInt(), lock1 = scan.nextInt(),
                    lock2 = scan.nextInt(), lock3 = scan.nextInt();

            if (position == 0 && lock1 == 0 && lock2 == 0 &&  lock3 == 0) {
                System.exit(1);
            }

            int degrees = 720;
            degrees += (lock1 * 9);
            degrees += 360;
            if (lock1 > lock2) {
                degrees += (lock2 - lock1) * 9;
            }
            else {
                degrees += ((40 - lock1) + lock2) * 9;
            }
        }
    }
}

package Miscellaneous;

import java.util.Scanner;
import java.util.Stack;

public class ValidParentheses {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        while(scan.hasNext()) {
            System.out.println(isValid(scan.next()));
        }
    }

    private static boolean isValid(String str) {
        Stack<Character> stack = new Stack<>();

        for (int s = 0; s < str.length(); s++) {
            char c = str.charAt(s);

            if (c == '(' || c == '[' || c == '{') {
                stack.push(c);
            }
            else if (!stack.isEmpty()) {
                if (c == ')') {
                    if (stack.peek() == '(') {
                        stack.pop();
                    }
                    else return false;
                } else if (c == '}') {
                    if (stack.peek() == '{') {
                        stack.pop();
                    }
                    else return false;
                } else if (c == ']') {
                    if (stack.peek() == '[') {
                        stack.pop();
                    }
                    else return false;
                }
            }
            else {
                return false;
            }
        }
        return stack.isEmpty();
    }

}

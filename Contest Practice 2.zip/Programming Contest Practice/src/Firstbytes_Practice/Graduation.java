package Firstbytes_Practice;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;

public class Graduation {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("Graduation.dat")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        int studentAmt = Integer.parseInt(br.readLine());
        ArrayList<Student> students = new ArrayList<>();
        students.ensureCapacity(studentAmt);

        for (int s = 0; s < studentAmt - 1; s++) {
            String info = br.readLine();
            String familyName = info.substring(0, info.indexOf(","));
            String givenNames = info.substring(info.indexOf(",") + 2, info.length() - 13).trim();
            String gpa = info.substring(info.length() - 13, info.length() - 11).trim();
            long ID = Long.parseLong(info.substring(info.length() - 10));
            students.add(new Student(familyName, givenNames, gpa, ID));
        }

        Collections.sort(students);

        for (int s = 0; s < studentAmt - 1; s++) {
            pw.println(students.get(s));
        }

        pw.close();
    }

}

class Student implements Comparable<Student> {

    String familyName;
    String givenNames;
    GPA gpa;
    long ID;

    @Contract(pure = true)
    public Student(String familyName, String givenNames, String gpa, long ID) {
        this.familyName = familyName;
        this.givenNames = givenNames;
        this.gpa = new GPA(gpa);
        this.ID = ID;
    }

    @Override
    public int compareTo(@NotNull Student other) {
        if (familyName.compareTo(other.familyName) == 0) {
            if (givenNames.compareTo(other.givenNames) == 0) {
                if (gpa.compareTo(other.gpa) == 0) {
                    return Long.compare(ID, other.ID);
                }
                else {
                    return gpa.compareTo(other.gpa);
                }
            }
            else {
                return givenNames.compareTo(other.givenNames);
            }
        }
        else {
            return familyName.compareTo(other.familyName);
        }
    }

    @Override
    public String toString() {
        StringBuilder studentInfo = new StringBuilder(String.format("%-40s", familyName + ", " + givenNames));
        studentInfo.append(" ").append(String.format("%-2s", gpa.gpa)).append(" ").append(ID);
        return studentInfo.toString();
    }
}

class GPA implements Comparable<GPA> {

    String gpa;
    int gpaVal;

    public GPA(String gpa) {
        this.gpa = gpa;
        switch(gpa) {
            case "A+":
                gpaVal = 1;
                break;
            case "A":
                gpaVal = 2;
                break;
            case "A-":
                gpaVal = 3;
                break;
            case "B+":
                gpaVal = 4;
                break;
            case "B":
                gpaVal = 5;
                break;
            case "B-":
                gpaVal = 6;
                break;
            case "C+":
                gpaVal = 7;
                break;
            case "C":
                gpaVal = 8;
                break;
            case "C-":
                gpaVal = 9;
                break;
            case "D+":
                gpaVal = 10;
                break;
            case "D":
                gpaVal = 11;
                break;
            case "D-":
                gpaVal = 12;
                break;
            default:
                gpaVal = 13;
        }
    }

    @Override
    public int compareTo(@NotNull GPA other) {
        return Integer.compare(gpaVal, other.gpaVal);
    }
}

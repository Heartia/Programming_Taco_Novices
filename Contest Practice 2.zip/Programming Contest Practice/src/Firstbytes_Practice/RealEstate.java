package Firstbytes_Practice;

import java.io.*;
import java.util.Arrays;

public class RealEstate {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("RealEstate.dat")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        int tests = Integer.parseInt(br.readLine());

        for (int t = 0; t < tests; t++) {
            String[] valStrs = br.readLine().split(" ");

            int budget = Integer.parseInt(valStrs[0]);
            int lotAmt = Integer.parseInt(valStrs[1]);

            String[] lotStrs = br.readLine().split(" ");
            int[] lots = new int[lotStrs.length];

            for (int l = 0; l < lotStrs.length; l++) {
                lots[l] = Integer.parseInt(lotStrs[l]);
            }

            int count = 0;

            for (int i = 0; i < lots.length; i++) {
                int costs = 0;
                int currCount = 0;
                for (int j = i; j < lots.length; j++) {
                    if (costs + lots[j] > budget) {
                        break;
                    }
                    costs += lots[j];
                    currCount++;
                }
                if (currCount > count) {
                    count = currCount;
                }
            }

            pw.println(count);
        }
        pw.close();
    }

}

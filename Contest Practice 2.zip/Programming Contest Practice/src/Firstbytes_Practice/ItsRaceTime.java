package Firstbytes_Practice;

import java.io.*;
import java.util.ArrayList;

public class ItsRaceTime {

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(new File("ItsRaceTime.dat")));
        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        String[] valStrs = br.readLine().split(" ");
        ArrayList<Integer> cars = new ArrayList<>();
        ArrayList<Integer> pits = new ArrayList<>();

        cars.ensureCapacity(Integer.parseInt(valStrs[1]));
        pits.ensureCapacity(Integer.parseInt(valStrs[1]));
        for (int i = 2; i < valStrs.length; i++) {
            cars.add(Integer.parseInt(valStrs[i]));
        }

        String message;
        while ((message = br.readLine()) != null) {
            if (message.equals("END")) {
                for (int i = 0; i < cars.size() - 1; i++) {
                    pw.print(cars.get(i) + " ");
                }
                pw.print(cars.get(cars.size() - 1));
                break;
            }
            String[] info = message.split(" ");
            if (message.startsWith("DROPOUT")) {
                int car = Integer.parseInt(info[1]);
                cars.remove((Integer) car);
            }
            else if (message.startsWith("OVERTAKE")) {
                int car = Integer.parseInt(info[1]);
                int index = cars.indexOf(car);
                if (index > 0) {
                    cars.remove(index);
                    cars.add(index - 1, car);
                }
            }
            else if (message.startsWith("PITSTOP")) {
                int car = Integer.parseInt(info[1]);
                cars.remove((Integer) car);
                pits.add(car);
            }
            else if (message.startsWith("PITRETURN")) {
                int car = Integer.parseInt(info[1]);
                if (pits.contains(car)) {
                    pits.remove((Integer) car);
                    if (Integer.parseInt(info[2]) > cars.size()) {
                        cars.add(cars.size(), car);
                    }
                    else {
                        cars.add(Integer.parseInt(info[2]), car);
                    }
                }
            }
            else if (message.startsWith("CRASH")) {
                for (int i = 1; i < info.length; i++) {
                    cars.remove((Integer) Integer.parseInt(info[i]));
                }
            }
        }
        pw.close();
    }

}

package UTD_Practice;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class MaxHeaps {

    public static void main(String[] args) {
        MaxHeap maxHeap = new MaxHeap(15);

        maxHeap.insert(5);
        maxHeap.insert(3);
        maxHeap.insert(17);
        maxHeap.insert(10);
        maxHeap.insert(84);
        maxHeap.insert(19);
        maxHeap.insert(6);
        maxHeap.insert(22);
        maxHeap.insert(9);

        PrintWriter printWriter = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
        printWriter.println("The max val is " + maxHeap.extractMax());

        printWriter.close();
    }

    static class MaxHeap {
        private int[] Heap;
        private int size;
        private int maxSize;

        public MaxHeap(int maxSize)
        {
            this.maxSize = maxSize;
            this.size = 0;
            Heap = new int[this.maxSize + 1];
            Heap[0] = Integer.MAX_VALUE;
        }

        // Returns position of parent
        private int parent(int pos) {
            return pos / 2;
        }

        private int leftChild(int pos) {
            return (2 * pos);
        }

        private int rightChild(int pos) {
            return (2 * pos) + 1;
        }

        private boolean isLeaf(int pos) {
            if (pos >= (size / 2) && pos <= size) {
                return true;
            }
            return false;
        }

        private void swap(int fpos, int spos) {
            int temp = Heap[fpos];
            Heap[fpos] = Heap[spos];
            Heap[spos] = temp;
        }

        private void maxHeapify(int pos) {
            if (isLeaf(pos)) {
                return;
            }
            if (Heap[pos] < Heap[leftChild(pos)] || Heap[pos] < Heap[rightChild(pos)]) {
                if (Heap[leftChild(pos)] > Heap[rightChild(pos)]) {
                    swap(pos, leftChild(pos));
                    maxHeapify(leftChild(pos));
                }
                else {
                    swap(pos, rightChild(pos));
                    maxHeapify(rightChild(pos));
                }
            }
        }

        private void insert(int element) {
            Heap[++size] = element;

            int current = size;
            while (Heap[current] > Heap[parent(current)]) {
                swap(current, parent(current));
                current = parent(current);
            }
        }

        @Override
        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 1; i <= size / 2; i++) {
                stringBuilder.append(" PARENT : ").append(Heap[i]).append(" LEFT CHILD : ").append(Heap[2 * i]).append(" RIGHT CHILD: ").append(Heap[2 * i + 1]).append("\n");
            }
            return stringBuilder.toString();
        }

        private int extractMax() {
            int popped = Heap[1];
            Heap[1] = Heap[size--];
            maxHeapify(1);
            return popped;
        }
    }

}

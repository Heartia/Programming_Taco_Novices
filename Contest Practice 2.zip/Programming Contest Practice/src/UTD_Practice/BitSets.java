package UTD_Practice;

import java.util.BitSet;

public class BitSets {

    public static void main(String[] args) {
        BitSet bitSet = new BitSet();


    }

}

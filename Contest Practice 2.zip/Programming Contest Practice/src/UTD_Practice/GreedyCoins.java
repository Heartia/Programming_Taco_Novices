package UTD_Practice;

import java.io.*;
import java.util.Arrays;

public class GreedyCoins {

    static int[] coins;
    static int coinHierarchy;

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        coins = new int[Integer.parseInt(br.readLine())];

        String[] line = br.readLine().split(" ");
        coins = new int[line.length];
        for (int i = 0; i < line.length; i++) {
            coins[i] = Integer.parseInt(line[i]);
        }
        Arrays.sort(coins);

        PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
        pw.println(greedy(Integer.parseInt(br.readLine())) + " coins needed");
        pw.close();
    }

    private static int greedy(int amount) {
        int coinTotal = 0;
        while (amount > coins[coins.length - 1] && coinHierarchy < coins.length) {
            if (amount > coins[coinHierarchy]) {
                amount -= coins[coinHierarchy];
                coinTotal++;
            }
            else {
                coinHierarchy++;
            }
        }
        return coinTotal;
    }

}

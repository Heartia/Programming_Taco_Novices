package UTD_Practice;

public class BinaryIndexed {

    public static void main(String[] args) {

    }

}

package UTD_Practice;

public class BinaryTrees {

    Node root;

    public void addNode(int key, String name) {

        Node newNode = new Node(key, name);

        if (root == null) {

            root = newNode;

        }
        else {

            Node focusNode = root; // Node we focus on

            Node parent; // Future parent

            while(true) {

                parent = focusNode; // Parent is now current node

                if (key <= focusNode.key) { // Checks if focus should be on left

                    focusNode = focusNode.left;

                    if (focusNode == null) { // If the left is empty, we know to
                        // put the node we're inserting on the left.
                        parent.left = newNode;
                        return;
                    }

                }
                else { // When focus goes on the right.

                    focusNode = focusNode.right;

                    if (focusNode == null) {

                        parent.right = newNode;
                        return;

                    }
                }
            }

        }

    }

    public Node findNode(int key) {

        Node focusNode = root; // Start at root

        while (focusNode.key != key) {

            if (key < focusNode.key) {
                focusNode = focusNode.left; // Looks at left child
            }
            else {
                focusNode = focusNode.right; // Looks at right child
            }

            if (focusNode == null) { // Goes all the way down to leaf
                return null;
            }
        }

        return focusNode;
    }

    public boolean remove(int key) {
        // True if key can be removed, false if otherwise.
        Node focusNode = root; // Node we focus on
        Node parent = root;

        boolean isItLeftChild = true;

        while (focusNode.key != key) {
            // Keep searching if focusNode.key is not the key!

            parent = focusNode;

            if (key < focusNode.key) {

                isItLeftChild = true;

                focusNode = focusNode.left;

            }
            else {

                isItLeftChild = false;

                focusNode = focusNode.right;

            }

            if (focusNode == null) {
                return false; // If key is not found.
            }
        }

        if (focusNode.left == null && focusNode.right == null) {
            // If it has no children, remove the leaf.

            if (focusNode == root) {

                root = null;

            }
            else if (isItLeftChild) {

                parent.left = null;

            }
            else {
                parent.right = null;
            }

        }
        else if (focusNode.right == null) {
            // If ONLY the left child has something.
            if (focusNode == root) {
                root = focusNode.left;
            }
            else if (isItLeftChild) {
                parent.left = focusNode.left;
            }
            else {
                parent.right = focusNode.left;
            }

        }
        else if (focusNode.left == null) {
            // If ONLY the right child has something
            if (focusNode == root) {
                root = focusNode.right;
            }
            else if (isItLeftChild) {
                parent.left = focusNode.right;
            }
            else {
                parent.right = focusNode.right;
            }
        }
        else {
            // When the node has 2 children
            Node replacement = getReplacementNode(focusNode);

            if (focusNode == root) {
                root = replacement;
            }
            else if (isItLeftChild) {
                parent.left = replacement;
            }
            else {
                parent.right = replacement;
            }
            replacement.left = focusNode.left;
        }

        return true;
    }

    public Node getReplacementNode(Node replacedNode) {

        Node replacementParent = replacedNode;
        Node replacement = replacedNode;

        Node focusNode = replacedNode.right;

        while (focusNode != null) {
            replacementParent = replacement;

            replacement = focusNode;

            focusNode = focusNode.left;
        }

        if (replacement != replacedNode.right) {

            replacementParent.left = replacement.right;
            replacement.right = replacedNode.right;

        }

        return replacement;
    }

    public String inOrderTraversal(Node focusNode) {
        return inOrderTraversal(focusNode, new StringBuilder());
    }

    private String inOrderTraversal(Node focusNode, StringBuilder list) {
        if (focusNode != null) {
            inOrderTraversal(focusNode.left, list);
            list.append(focusNode + "\n");
            inOrderTraversal(focusNode.right, list);
        }
        return list.toString().trim();
    }

    public String preOrderTraversal(Node focusNode) {
        return preOrderTraversal(focusNode, new StringBuilder());
    }

    private String preOrderTraversal(Node focusNode, StringBuilder list) {
        if (focusNode != null) {
            list.append(focusNode + "\n");
            preOrderTraversal(focusNode.left, list);
            preOrderTraversal(focusNode.right, list);
        }
        return list.toString().trim();
    }

    public String postOrderTraversal(Node focusNode) {
        return postOrderTraversal(focusNode, new StringBuilder());
    }

    private String postOrderTraversal(Node focusNode, StringBuilder list) {
        if (focusNode != null) {
            postOrderTraversal(focusNode.left, list);
            postOrderTraversal(focusNode.right, list);
            list.append(focusNode + "\n");
        }
        return list.toString().trim();
    }

    public static void main(String[] args) {

        BinaryTrees tree = new BinaryTrees();

        tree.addNode(50, "Boss");
        tree.addNode(25, "Vice President");
        tree.addNode(15, "Secretary");
        tree.addNode(30, "Office manager");
        tree.addNode(75, "Sales Manager");
        tree.addNode(85, "Salesman 1");
        tree.addNode(69, "Salesman 69");
        tree.addNode(69, "Salesman 420");

        System.out.println(tree.preOrderTraversal(tree.root));
        System.out.println("==================================");
        System.out.println(tree.inOrderTraversal(tree.root));
        System.out.println("==================================");
        System.out.println(tree.postOrderTraversal(tree.root));
        System.out.println("==================================");
        System.out.println(tree.findNode(69));
        System.out.println(tree.findNode(420));
        System.out.println("==================================");
        tree.remove(25);
        System.out.println(tree.inOrderTraversal(tree.root));

        /*
        Print out value of trees in given format:

        _______1
        ___1_______1
        _1___1___1___1
        1_1_1_1_1_1_1_1

        1st Row Indent 7 Spaces 0
        2nd Row Indent 3 Spaces 7
        3rd Row Indent 1 Spaces 3
        4th Row Indent 0 Spaces 1

        Indent : -2 ^ n * (-16 + 2 ^ n)

        Note: Need an iterator that starts at 1.
        Iterate until there are no more rows.

        Spaces: 0 and then whatever Indent was.

        First Index per row
        0
        1 2
        3 4 5 6
        7 8 9 10 11 12 13 14
        .5 * (-2 + (Math.pow(2, iterator))

        Number of items per row
        1, 2, 4, 8
        Math.pow(2, iterator - 1)

        Max Index Per Row
        indexToPrint + itemsPerRow
         */
    }

}

class Node {

    int key;
    String name;
    Node left;
    Node right;

    Node (int key, String name) {

        this.key = key;
        this.name = name;

    }

    public String toString() {
        return name + " has key " + key;
    }

}

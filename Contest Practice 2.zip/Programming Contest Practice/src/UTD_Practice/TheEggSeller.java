package UTD_Practice;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TheEggSeller {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("Eggs.txt"));

        int m = scan.nextInt();

        for (int i = 0; i < m; i++) {
            int customers = scan.nextInt();


        }
    }

}

package UTD_Practice;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class DroppingBalls {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("Balls.txt"));

        while (scan.hasNext()) {
            BinaryTree binaryTree = new BinaryTree(scan.nextInt());
            int index = scan.nextInt();

            for (int i = index; i >= 0; i--) {
                if (i == 0) {
                    System.out.println(binaryTree.insert(1));
                }
                else {
                    binaryTree.insert(0);
                }
            }
        }
    }

    static class BinaryTree {

        Node root;

        BinaryTree(int height) {
            root = makeHeight(new Node(1), height);
        }

        Node makeHeight(Node node, int height) {
            if (height <= 0 || node == null) {
                return node;
            }
            if (node.left == null) {
                node.left = new Node(node.nodeNum * 2);
            }
            if (node.right == null) {
                node.right = new Node(node.nodeNum * 2 + 1);
            }
            makeHeight(node.left, height - 1);
            makeHeight(node.right, height - 1);
            return node;
        }

        int insert(int key) {
            return insert(root, key);
        }

        int insert(Node node, int key) {
            if (node == null) {
                return -1;
            }
            if (node.leftOrRight == node.LEFT) {
                node.leftOrRight = node.RIGHT;
                if (node.left == null) {
                    node.key = key;
                }
                insert(node.left, key);
            }
            else {
                node.leftOrRight = node.LEFT;
                if (node.right == null) {
                    node.key = key;
                }
                insert(node.right, key);
            }
            return node.nodeNum;
        }

        class Node {

            final boolean LEFT = false, RIGHT = true;

            int key;
            int nodeNum;
            boolean leftOrRight;
            Node left, right;

            Node(int nodeNum) {
                left = right = null;
                key = -1;
                leftOrRight = LEFT;
                this.nodeNum = nodeNum;
            }

        }

    }

}

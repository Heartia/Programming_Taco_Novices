package UTD_Practice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ShoelaceTheorem {

    static double[] xs, ys;
    static double sum;

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        int n = Integer.parseInt(br.readLine());
        xs = new double[n + 1];
        ys = new double[n + 1];

        for (int i = 0; i < n; i++) {
            String[] line = br.readLine().split(" ");
            double[] vals = new double[line.length];
            for (int j = 0; j < line.length; j++) {
                vals[j] = Double.parseDouble(line[j]);
            }
            xs[i] = vals[0];
            ys[i] = vals[1];
        }

        xs[n] = xs[0];
        ys[n] = ys[0];

        for (int j = 0; j < n; j++) {
            sum += (xs[j] * ys[j + 1]) - (ys[j] * xs[j + 1]);
        }

        System.out.println(sum * (1.0 / 2.0));
    }

}

package UTD_Practice;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class ListOfConquests {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("Don.txt"));

        int t = scan.nextInt();

        HashMap<String, ArrayList<String>> women = new HashMap<>();
        HashSet<String> countries = new HashSet<>();

        for (int i = 0; i < t; i++) {
            String country = scan.next();
            String woman = scan.nextLine();
            countries.add(country);

            if (!women.containsKey(country)) {
                women.put(country, new ArrayList<String>());
                women.get(country).add(woman);
            }
            else {
                women.get(country).add(woman);
            }
        }

        String[] stuff = new String[countries.size()];
        int i = 0;
        for (Map.Entry<String, ArrayList<String>> entry : women.entrySet()) {
            stuff[i] += entry.getKey() + " " + entry.getValue().size();
            i++;
        }
        Arrays.sort(stuff);
        for (int j = 0; j < stuff.length; j++) {
            System.out.println(stuff[j].substring(4));
        }
    }

}

package UTD_Practice;

public class FenwickTrees {

    /*
    A simple solution is to run a loop from 0
    to i-1 and calculate the sum of the elements.
     To update a value, simply do arr[i] = x. The
      first operation takes O(n) time and the
      second operation takes O(1) time. Another
      simple solution is to create an extra array
       and store the sum of the first i-th
       elements at the i-th index in this new
       array. The sum of a given range can now be
        calculated in O(1) time, but the update
        operation takes O(n) time now. This works
         well if there are a large number of
         query operations but very few number
         of update operations.

    Could we perform both the query and update
     operations in O(log n) time?
    One efficient solution is to use Segment
    Tree that performs both operations in O(Logn)
     time.

    An alternative solution is Binary Indexed
    Tree, which also achieves O(Logn) time
    complexity for both operations. Compared
    with Segment Tree, Binary Indexed Tree
    requires less space and is easier to
    implement.
     */

    public static void main(String args[])
    {
        int[] freq = {2, 1, 1, 3, 2, 3,
                4, 5, 6, 7, 8, 9};
        int n = freq.length;
        FenwickTree tree = new FenwickTree();

        // Build fenwick tree from given array
        tree.constructBITree(freq, n);

        System.out.println("Sum of elements in arr[0..5]"+
                " is "+ tree.getSum(5));

        // Let use test the update operation
        freq[3] += 6;

        // Update BIT for above change in arr[]
        FenwickTree.updateBIT(n, 3, 6);

        // Find sum after the value is updated
        System.out.println("Sum of elements in arr[0..5]"+
                " after update is " + tree.getSum(5));
    }

    static class FenwickTree {

        final static int MAX = 1000;

        static int[] BiTree = new int[MAX];

        /*
        BITree[0...n] --> Array that represents
        Binary Indexed tree

        arr[0...n-1] --> Input array for which
        prefix sum is calculated.
         */

        // Returns the sum of array[0...index]
        // Assumes that the array is preprocessed
        // and partial sums of array eleemnts
        // are stored in BITree[].

        int getSum(int index) {
            int sum = 0; // Initialise result

            // Index in BITree[] is 1 more than
            // the index in array[]
            index = index + 1;

            // Traverse ancestors of BITree[index]
            while (index > 0) {
                // Add current element of BITree
                // to sum
                sum += BiTree[index];

                // Move index to parent node in
                // getSum view
                index -= index & (-index);
            }
            return sum;
        }

        /**
        * Updates a node in Binary index Tree (BITree)
         * at given index in BITree. The given value
         * is added to BITree[i] and all of its
         * ancestors in the tree.
         */
        public static void updateBIT(int n, int index, int val) {
            // Index in BITree[] is 1 more than
            // the index in arr[]
            index = index + 1;

            // Add val to the current node of BIT Tree
            // and update index to that parent in update
            // view.
            while (index <= n) {
                BiTree[index] += val;

                index += index & (-index);
            }
        }

        void constructBITree(int[] arr, int n) {
            // Initialise BITree[] as 0
            for (int i = 1; i <= n; i++) {
                BiTree[i] = 0;
            }

            // Store the actual values in BITree[]
            // using update()
            for (int i = 0; i < n; i++) {
                updateBIT(n, i, arr[i]);
            }
        }
    }

}

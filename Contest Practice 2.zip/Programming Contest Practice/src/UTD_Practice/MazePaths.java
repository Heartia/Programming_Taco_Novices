package UTD_Practice;

public class MazePaths {

    public static void main(String[] args) {

    }

}

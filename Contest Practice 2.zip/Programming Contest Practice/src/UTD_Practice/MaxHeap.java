package UTD_Practice;

public class MaxHeap {

    private int[] Heap;
    private int size;
    private int maxSize;

    /*
    Constructor to initialise an empty max heap
    with a given max capacity.
     */

    public MaxHeap(int maxSize) {
        this.maxSize = maxSize;
        this.size = 0;
        Heap = new int[this.maxSize + 1];
        Heap[0] = Integer.MAX_VALUE;
    }

    private int parent(int pos) {
        return pos / 2;
    }

    // Returns left and right children
    private int leftChild(int pos) {
        return (2 * pos);
    }

    private int rightChild(int pos) {
        return (2 * pos) + 1;
    }

    private boolean isLeaf(int pos) {
        if (pos >= (size / 2) && pos <= size) {
            return true;
        }
        return false;
    }

    private void swap(int fpos, int spos) {
        int temp = Heap[fpos];
        Heap[fpos] = Heap[spos];
        Heap[spos] = temp;
    }

    /*
    A recursive function to max heapify the given
    subtree. Assuming that the left and right subtrees
    are already heapified, the root gets fixed.
    */
    private void maxHeapify(int pos) {
        if (isLeaf(pos)) return;

        if (Heap[pos] < Heap[leftChild(pos)] ||
        Heap[pos] < Heap[rightChild(pos)]) {
            if (Heap[leftChild(pos)] > Heap[rightChild(pos)]) {
                swap(pos, leftChild(pos));
                maxHeapify(leftChild(pos));
            }
            else {
                swap(pos, rightChild(pos));
                maxHeapify(rightChild(pos));
            }
        }
    }

    // Insert a new element to the max heap.
    private void insert(int element) {
        Heap[++size] = element;

        // Traverse up and fix violated property
        int current = size;
        while (Heap[current] > Heap[parent(current)]) {
            swap(current, parent(current));
            current = parent(current);
        }
    }

    // Remove an element from max heap
    private int extractMax() {
        int popped = Heap[1];
        Heap[1] = Heap[size--];
        maxHeapify(1);
        return popped;
    }

    public String toString() {
        StringBuilder toReturn = new StringBuilder();
        for (int i = 1; i <= size / 2; i++) {
            toReturn.append(" PARENT : ").append(Heap[i]).append(" LEFT CHILD : ").append(Heap[2 * i]).append(" RIGHT CHILD :").append(Heap[2 * i + 1]).append("\n");
        }
        return toReturn.toString();
    }

    public static void main(String[] arg)
    {
        System.out.println("The Max Heap is ");
        MaxHeap maxHeap = new MaxHeap(15);
        maxHeap.insert(5);
        maxHeap.insert(3);
        maxHeap.insert(17);
        maxHeap.insert(10);
        maxHeap.insert(84);
        maxHeap.insert(19);
        maxHeap.insert(6);
        maxHeap.insert(22);
        maxHeap.insert(9);

        System.out.println(maxHeap);
        System.out.println("The max val is " + maxHeap.extractMax());
    }
}

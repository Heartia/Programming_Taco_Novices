package UTD_Practice;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigInteger;
import java.util.Scanner;

public class HungryForTrailingZeros {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("HFTZ.txt"));

        int testCase = 1;
        while (scan.hasNext()) {
            int eval = scan.nextInt();
            if (eval == -1) {
                System.exit(0);
            }
            System.out.println("Case " + testCase + ": " + findTrailingZeroes(eval));
            testCase++;
        }
    }

    public static int findTrailingZeroes(int n) {
        int count = 0;

        // Divides n by powers of 5 whilst updating count.
        for (int i = 5; n / i >= 1; i *= 5) {
            count += n / i;
        }
        return count;
    }

    public static BigInteger getFactorial(long num) {
        BigInteger result = BigInteger.ONE;
        for (int i = 1; i <= num; i++)
            result = result.multiply(BigInteger.valueOf(i));
        return result;
    }
}

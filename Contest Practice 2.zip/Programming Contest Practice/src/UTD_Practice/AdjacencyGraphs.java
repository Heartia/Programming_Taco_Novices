package UTD_Practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class AdjacencyGraphs {

    private static int[][] adjacencyMatrix;
    private static IndividualList[] adjacencyList;

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int numOfCities = scan.nextInt();
        int entries = scan.nextInt();
        adjacencyMatrix = new int[numOfCities][numOfCities];
        adjacencyList = new IndividualList[numOfCities];

        for (int i = 0; i < entries; i++) {
            int city = scan.next().charAt(0) - 65;

            String[] pathStrings = scan.nextLine().trim().split("\\s");
            System.out.println(Arrays.toString(pathStrings));
            int[] paths = new int[pathStrings.length];
            for (int l = 0; l < paths.length; l++) {
                paths[l] = pathStrings[l].charAt(0) - 65;
                adjacencyMatrix[city][paths[l]] = 1;
                //adjacencyList[i].add(paths[l]);
            }
        }

        for (int r = 0; r < adjacencyMatrix.length; r++) {
            for (int c = 0; c < adjacencyMatrix[0].length; c++) {
                if (adjacencyMatrix[r][c] != 0) {
                    System.out.println((char)(r + 65) + " to " + (char)(c + 65));
                }
            }
        }

        System.out.println("====================================");

        /*
        for (int r = 0; r < adjacencyList.length; r++) {
            for (int c = 0; c < adjacencyList[r].size(); c++) {
                System.out.println((char)(r + 65) + " to " + (char)(adjacencyList[0].get(c) + 65));
            }
        }
        */
    }

}

class IndividualList extends ArrayList<Integer> { }

package UTD_Practice;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class GolbachConjecture2 {

    private static boolean isPrime(long n) {
        if (n == 2 || n == 3) {
            return true;
        }
        if (n % 2 == 0 || n % 3 == 0) {
            return false;
        }

        int i = 5;
        int w = 2;

        while (i * i <= n) {
            if (n % i == 0) {
                return false;
            }
            i += w;
            w = 6 - w;
        }

        return true;
    }

    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("HFTZ.txt"));

        long begin = System.currentTimeMillis();
        while (scan.hasNext()) {
            System.out.println("Next read!");
            long n = scan.nextLong();
            if (n == 0) {
                break;
            }
            for (long a = 3; a <= n / 2;) {
                boolean stillRun = true;
                for (long b = n - a; b < n;) {
                    if (isPrime(b) && (a + b == n)) {
                        System.out.println(n + " = " + a + " + " + b);
                        stillRun = false;
                        break;
                    }
                    for (long i = b; i < 1000000; i++) {
                        if (isPrime(i)) {
                            b = i;
                            break;
                        }
                    }
                }
                if (!stillRun) {
                    break;
                }
                for (long i = a; i < 1000000; i++) {
                    if (isPrime(i)) {
                        a = i;
                        break;
                    }
                }
            }
        }
        System.out.println(System.currentTimeMillis() - begin + " milliseconds.");
    }

}

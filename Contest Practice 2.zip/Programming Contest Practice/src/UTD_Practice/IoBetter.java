package UTD_Practice;

import java.io.*;

public class IoBetter {

    public static void main(String[] args) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter printWriter = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        int i = Integer.parseInt(bufferedReader.readLine());
        // read() returns a single character.
        // readLine() should get your input.
        // Or just do i - 48
        printWriter.println("Integer printed out: " + i);

        printWriter.flush();
        printWriter.close();
    }

}

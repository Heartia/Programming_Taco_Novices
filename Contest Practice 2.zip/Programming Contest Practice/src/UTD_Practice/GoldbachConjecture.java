package UTD_Practice;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class GoldbachConjecture {

    private static List<Long> primes = new ArrayList<>();
    private static List<Long> notPrimes = new ArrayList<>();

    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("HFTZ.txt"));

        long begin = System.currentTimeMillis();
        while (scan.hasNext()) {
            long n = scan.nextLong();
            if (n == 0) {
                break;
            }
            for (long a = 3; a <= n / 2;) {
                boolean stillRun = true;
                for (long b = n - a; b < n;) {
                    if (checkPrime(b) && (a + b == n)) {
                        System.out.println(n + " = " + a + " + " + b);
                        stillRun = false;
                        break;
                    }
                    b = getNextPrime(b);
                }
                if (!stillRun) {
                    break;
                }
                a = getNextPrime(a);
            }
        }
        System.out.println(System.currentTimeMillis() - begin + " milliseconds.");
    }

    private static long getNextPrime(long n) {
        if (primes.contains(n)) {
            int index = primes.indexOf(n);
            if (index + 1 < primes.size()) {
                return primes.get(index + 1);
            }
        }
        BigInteger b = new BigInteger(String.valueOf(n));
        return Long.parseLong(b.nextProbablePrime().toString());
    }

    private static boolean checkPrime(long n) {
        if (primes.contains(n)) {
            return true;
        }
        else if (notPrimes.contains(n)) {
            return false;
        }
        BigInteger b = new BigInteger(String.valueOf(n));
        boolean isPrime = b.isProbablePrime(1);
        if (isPrime) {
            primes.add(n);
            Collections.sort(primes);
        }
        else {
            notPrimes.add(n);
            Collections.sort(notPrimes);
        }
        return isPrime;
    }

}

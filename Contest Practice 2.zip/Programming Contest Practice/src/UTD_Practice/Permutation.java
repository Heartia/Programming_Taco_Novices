package UTD_Practice;

// Java program to print all permutations of a
// given string.
public class Permutation
{
    public static void main(String[] args)
    {
        String str = "ABC";
        int n = str.length();
        Permutation permutation = new Permutation();
        System.out.println(permutation.permute(str, 0, n-1));
    }

    /**
     * permutation function
     * @param str string to calculate permutation for
     * @param l starting index
     * @param r end index
     */
    private String permute(String str, int l, int r)
    {
        String permuted = "";
        if (l == r)
            permuted += str + "\n";
        else
        {
            for (int i = l; i <= r; i++)
            {
                str = swap(str,l,i);
                permuted += permute(str, l+1, r);
                str = swap(str,l,i);
            }
        }
        return permuted;
    }

    /**
     * Swap Characters at position
     * @param a string value
     * @param i position 1
     * @param j position 2
     * @return swapped string
     */
    public String swap(String a, int i, int j)
    {
        char temp;
        char[] charArray = a.toCharArray();
        temp = charArray[i] ;
        charArray[i] = charArray[j];
        charArray[j] = temp;
        return String.valueOf(charArray);
    }

}
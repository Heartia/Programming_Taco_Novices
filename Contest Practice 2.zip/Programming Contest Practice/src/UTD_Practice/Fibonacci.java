package UTD_Practice;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class Fibonacci {

    private static ArrayList<BigInteger> fibStorage = new ArrayList<>();

    public static void main(String[] args) {
        long begin = System.currentTimeMillis();
        fillList(fibStorage, -1, 10000);
        System.out.println(fibonacci(7460));
        System.out.println(fibonacci(2000));
        System.out.println(fibonacci(5000));
        System.out.println(fibonacci(6800));
        System.out.println(fibonacci(3200));
        System.out.println(System.currentTimeMillis() - begin + " milliseconds taken.");
    }

    private static void fillList(List<BigInteger> list, int value, int max) {
        for (int i = 0; i < max; i++) {
            list.add(new BigInteger(value + ""));
        }
    }

     private static BigInteger fibonacci(int n) {
        if (!fibStorage.get(n).equals(new BigInteger("-1")))
            return fibStorage.get(n);
        if (n == 0) return new BigInteger("0");
        if (n == 1) return new BigInteger("1");
        BigInteger a = new BigInteger("0");
        BigInteger b = new BigInteger("1");
        for (int i = 2; i < n; i++) {
            BigInteger sum = a.add(b);
            a = new BigInteger(b.toString());
            b = sum;
        }
        fibStorage.add(n, b);
        return b;
    }

}

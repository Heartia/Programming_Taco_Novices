package UTD_Practice;

public class BinarySearchTree {

    // Class with left and right child of current node
    class Node {
        int key;
        Node left, right;

        public Node(int item) {
            key = item;
            left = right = null;
        }
    }

    // Root of BST
    Node root;

    BinarySearchTree() {
        root = null;
    }

    // Calls the insertRec method.
    void insert(int key) {
        root = insertRec(root, key);
    }

    // Recursively inserts a new key into a BST
    Node insertRec(Node root, int key) {
        // If tree is empty, return a new node
        // to make a key
        if (root == null) {
            root = new Node(key);
            return root;
        }

        // Searches for location of the key in the
        // binary search tree.
        if (key < root.key)
            root.left = insertRec(root.left, key);
        else if (key > root.key)
            root.right = insertRec(root.right, key);

        // returns the (unchanged) node pointer
        return root;
    }

    void remove(int key) {
        removeRec(root, key);
    }

    void removeRec(Node root, int key) {
        if (root == null) return;
        if (key < root.key)
            removeRec(root.left, key);
        else if (key > root.key)
            removeRec(root.right, key);
        else {
            if (root.left != null && root.right != null) {
                /* pos has two children */
                Node maxFromLeft = findMax (root.left); //need to make a findMax helper
                //"Replacing "  pos.key " with " maxFromLeft.key
                root.key = maxFromLeft.key;
                removeRec(root.left, maxFromLeft.key);
            }
            else if(root.left != null) {
                /* node pointed by pos has at most one child */
                Node trash = root;
                //"Promoting " pos.leftChild.key " to replace " pos.key
                root = root.left;
                trash = null;
            }
            else if(root.right != null) {
                /* node pointed by pos has at most one child */
                Node trash = root;
                /* "Promoting " pos.rightChild.key" to replace " pos.key */
                root = root.right;
                trash = null;
            }
            else {
                root = null;
            }
        }
    }

    Node findMin() {
        return findMin(root);
    }

    Node findMin(Node root) {
        if (root.left != null) {
            root = findMin(root.left);
        }
        return root;
    }

    Node findMax() {
        return findMax(root);
    }

    Node findMax(Node root) {
        if (root.right != null) {
            root = findMax(root.right);
        }
        return root;
    }

    void inorder() {
        inorderRec(root);
    }

    // Does the inorder traversal of a BST
    void inorderRec(Node root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.println(root.key);
            inorderRec(root.right);
        }
    }

    void preorder() {
        preorderRec(root);
    }

    void preorderRec(Node root) {
        if (root != null) {
            System.out.println(root.key);
            preorderRec(root.left);
            preorderRec(root.right);
        }
    }

    void postorder() {
        postorderRec(root);
    }

    void postorderRec(Node root) {
        if (root != null) {
            preorderRec(root.left);
            preorderRec(root.right);
            System.out.println(root.key);
        }
    }

    public static void main(String[] args) {
        BinarySearchTree tree = new BinarySearchTree();

        /* Let us create following BST
              50
           /     \
          30      70
         /  \    /  \
       20   40  60   80 */
        tree.insert(50);
        tree.insert(30);
        tree.insert(20);
        tree.insert(40);
        tree.insert(70);
        tree.insert(60);
        tree.insert(80);
        tree.remove(40);

        System.out.println(tree.findMax().key + "\n");
        System.out.println(tree.findMin().key + "\n");

        // print inorder traversal of the BST
        tree.inorder();
        System.out.println("=====");
        tree.preorder();
        System.out.println("=====");
        tree.postorder();
    }
}


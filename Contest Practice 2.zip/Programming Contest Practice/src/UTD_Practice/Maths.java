package UTD_Practice;

public class Maths {

    public static void main(String[] args) {
        System.out.println(gaussSum(100));
    }

    /*
    Returns the distance formula of two different points, (x1, y1) and (x2, y2)
    d = sqrt((x2 - x1)^2 + (y2 - y1)^2)
     */
    private static double getEuclideanDistance(double[] xs, double[] ys) {
        return Math.sqrt(Math.pow(xs[1] - xs[0], 2) + Math.pow(ys[1] - ys[0], 2));
    }

    private static int gaussSum(int n1, int n2) {
        return (n1 * (n1 + n2) / 2);
    }

    private static int gaussSum(int n) {
        return (n * (n + 1) / 2);
    }

}

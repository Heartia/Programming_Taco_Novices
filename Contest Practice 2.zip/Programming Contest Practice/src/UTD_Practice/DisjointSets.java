package UTD_Practice;

import java.util.Scanner;

public class DisjointSets {

    /**
     * This collection connects values together and
     * sees if they're in the same set.
     */

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int n = scan.nextInt(), t = scan.nextInt();
        DisjointSet dus = new DisjointSet(n);

        for (int i = 0; i < t; i++) {
            dus.unionAndCompress(scan.nextInt(), scan.nextInt());
        }

        // Checks if 4 is connected to 0
        System.out.println(dus.find(4) == dus.find(0));
        // Checks if 1 is connected to 0;
        System.out.println(dus.find(1) == dus.find(0));
    }

    static class DisjointSet {

        int[] rank, parent;
        int n;

        public DisjointSet(int n) {
            rank = new int[n];
            parent = new int[n];
            this.n = n;
            makeSet();
        }

        void makeSet() {
            for (int i = 0; i < n; i++) {
                parent[i] = i;
                // At first, all elements are in their own set.
            }
        }

        /**
         * Finds the representative/parent in the set.
         */
        public int find(int i) {
            if (parent[i] == i) {
                // If i is parent of itself, then
                // i represents this set.
                return i;
            }
            else {
                // If i is not the parent of itself,
                // i doesn't represent this set.
                // Thus, we recursively call find
                // to get its' parent.
                return find(parent[i]);
            }
        }

        /**
         * This find method utilizes path compression,
         * which will make tree traversal easier and faster.
         */
        public int findAndCompress(int i) {
            if (parent[i] == i) {
                return i;
            }
            else { // This is the main component change.
                int result = findAndCompress(parent[i]);

                // We cache the result by moving i's node
                // directly under the representative of
                // this set.
                parent[i] = result;
                // This makes the height, at most, 1.
                return result;
            }
        }

        /** Takes two elements as input, and finds the
         representative of their sets using find.

         It then puts either one of the trees under
         the root node of the other tree, merging the
         trees and the sets.*/
        public void union(int i, int j) {
            int irep = this.findAndCompress(i);
            int jrep = this.findAndCompress(j);

            // Makes the parent of i's representative
            // be j's representative effectively by
            // moving all of i's set into j's set.
            // It doesn't matter which tree is moved
            // under the other.
            this.parent[irep] = jrep;
        }

        /**
        * This is also just like union, but it does path
         * compression, too.
         */
        public void unionAndCompress(int i, int j) {
            // If i is representative of a set, rank[i] is the
            // height of the tree representing the set.

            /*
            If rank of left is less than right, move left
            under right to minimise the height, and vice versa.

            If ranks are equal, it doesn't matter which tree
            goes under the other, but the rank of the result will
            always be one greater than that of the trees.
             */

            int iRoot = findAndCompress(i), jRoot = findAndCompress(j);

            if (iRoot == jRoot) {
                return;
            }

            // If i's rank is less than j's rank.
            if (rank[iRoot] < rank[jRoot]) {
                parent[iRoot] = jRoot;
            }
            // Vice versa
            else if (rank[jRoot] < rank[iRoot]) {
                parent[jRoot] = iRoot;
            }
            else {
                // Moves j under i
                parent[jRoot] = iRoot;
                rank[iRoot] = rank[iRoot] + 1;
            }
        }

    }

}

package UTD_Practice;

import java.util.function.Function;

public class FuncProgramming {

    public static void main(String[] args) {
        print(() -> "Samhita"); /*
        Rather than just creating a NameSupplier and printing that,
        you can also call the print method with empty parameters (),
        apply lambda with -> and pass in the parameter used in
        the method called.
        */
        print(() -> "Samyu", (String name) -> {
            return "Lady " + name;
        }); /*
        You can also define your own lambda functions, as well.
        In this case, the lambda function is used as a decorator.
        */
    }

    private static void print(NameSupplier nameSupplier) {
        System.out.println("Hello " + nameSupplier.get());
    }

    private static void print(NameSupplier nameSupplier, Function<String, String> decorator) {
        System.out.println("Hello " + decorator.apply(nameSupplier.get()));
    }

    private interface NameSupplier {
        String get();
    }
}

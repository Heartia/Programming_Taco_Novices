package UTD_Practice;

public class SegmentTrees {

    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};

        SegmentTree.n = array.length;

        SegmentTree.build(array);

        System.out.println(SegmentTree.query(1, 3));

        SegmentTree.updateTreeNode(2, 1);

        System.out.println(SegmentTree.query(1, 3));
    }

    static class SegmentTree {

        /**
         * A segment tree is useful for a more efficient array
         * that can sum the values of specific indices of an array
         * much faster than that of your average array.
         */

        static int N = 100000; // Array size limit

        static int n; // Array size

        // Max size of tree
        static int[] tree = new int[2 * N];

        // Function to build the tree
        static void build(int[] arr) {

            // Insert leaf nodes in tree
            for (int i = 0; i < n; i++) {
                tree[n + i] = arr[i];
            }

            // Build the tree by calculating
            // parents.
            for (int i = n - 1; i > 0; --i) {
                tree[i] = tree[i << 1] +
                        tree[i << 1 | 1];
            }
        }

        // Function to update a tree node

        static void updateTreeNode(int p, int value) {
            // Set value at position p
            tree[p + n] = value;
            p = p + n;

            // Move upward and update parents
            for (int i = p; i > 1; i >>= 1) {
                tree[i >> 1] = tree[i] + tree[i ^ 1];
            }
        }

        static int query(int l, int r) {
            int res = 0;

            // loop to find the sum in the range
            for (l += n, r+= n; l < r; l >>= 1, r >>= 1) {
                if ((l & 1) > 0)
                    res += tree[l++];

                if ((r & 1) > 0)
                    res += tree[--r];
            }

            return res;
        }

    }

}

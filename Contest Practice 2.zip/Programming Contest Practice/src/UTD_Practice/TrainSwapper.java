package UTD_Practice;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TrainSwapper {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("Train.txt"));

        int toats = scan.nextInt();

        for (int t = 0; t < toats; t++) {
            int[] railcars = new int[scan.nextInt()];
            for (int i = 0; i < railcars.length; i++) {
                railcars[i] = scan.nextInt();
            }
            System.out.println("Optimal train swapping takes " + bubbleSort(railcars) + " swaps.");
        }
    }

    private static int bubbleSort(int[] array) {
        int n = array.length, swaps = 0;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (array[j] > array[j + 1]) {
                    int temp = array[j];
                    array[j] = array[j+1];
                    array[j+1] = temp;
                    swaps++;
                }
            }
        }
        return swaps;
    }

}

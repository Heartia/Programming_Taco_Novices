package UTD_Practice;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Random;
import java.util.Scanner;
import java.util.Stack;

public class Algorithms {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        Random random = new Random();

        // Permutation client code
        /*String str = "ABC";
        int n = str.length();
        permute(str, 0, n - 1);*/

        // Binary search client code
        /*int[] array = new int[random.nextInt(15) + 25];
        for (int i = 0; i < array.length; i++) {
            array[i] = random.nextInt(99) + 1;
        }
        int numToSearch = 64;
        System.out.println("Searched index is "+ binarySearch(array, numToSearch));*/

        // Expression evaluation client code
        ExpressionEvaluator evaluator = new ExpressionEvaluator();
        System.out.println(evaluator.evaluate(scan.nextLine()));
    }


    private static int binarySearch(int arr[], int numToSearch) {
        int startIndex = 0;
        int endIndex = arr.length - 1;
        int n = (endIndex + startIndex) / 2;
        while (arr[n] != numToSearch) {
            if (arr[n] > numToSearch) {
                endIndex = n - 1;
            }
            else if (arr[n] < numToSearch) {
                startIndex = n + 1;
            }
            n = (endIndex + startIndex) / 2;
        }
        return n;
    }

    /**
     * permutation function
     * @param str string to calculate permutation for
     * @param l starting index
     * @param r end index
     */
    private static void permute(String str, int l, int r)
    {
        if (l == r)
            System.out.println(str);
        else
        {
            for (int i = l; i <= r; i++)
            {
                str = swap(str,l,i);
                permute(str, l+1, r);
                str = swap(str,l,i);
            }
        }
    }

    /**
     * Swap Characters at position
     * @param a string value
     * @param i position 1
     * @param j position 2
     * @return swapped string
     */
    private static String swap(String a, int i, int j)
    {
        char temp;
        char[] charArray = a.toCharArray();
        temp = charArray[i] ;
        charArray[i] = charArray[j];
        charArray[j] = temp;
        return String.valueOf(charArray);
    }

}

class ExpressionEvaluator {
    private static final String ERROR_CONSTANT = "-234698324706982987345873279.493861948369184370918463948";
    public static final BigDecimal ERROR_BIGDEC = new BigDecimal(ERROR_CONSTANT);
    private static final MathContext MC = new MathContext(10, RoundingMode.HALF_EVEN);

    private char previousChar = 0;
    private boolean negSet = false;
    private boolean ignoreOneCloseParen = false;

    public BigDecimal evaluate(String expression) {
        char[] tokens = expression.toCharArray();

        // Stack for numbers: 'values'
        Stack<BigDecimal> values = new Stack<>();

        // Stack for Operators: 'ops'
        Stack<Character> ops = new Stack<>();

        for (int i = 0; i < tokens.length; i++) {
            if(tokens[i] == ' ') {
                continue;
            }

            if ((tokens[i] >= '0' && tokens[i] <= '9') || tokens[i] == '.') {
                StringBuilder buffer = new StringBuilder();

                if(negSet) {
                    buffer.append('-');
                    negSet = false;
                }

                while (i < tokens.length && ((tokens[i] >= '0' && tokens[i] <= '9') || tokens[i] == '.' || tokens[i] == 'E')) {
                    if(tokens[i] == 'E') {
                        buffer.append(tokens[i++]);
                    }
                    buffer.append(tokens[i++]);
                }
                i--;

                values.push(new BigDecimal(buffer.toString()));
            }

            // Current token is an opening brace, push it to 'ops'
            else if (tokens[i] == '(') {
                ops.push(tokens[i]);
            }

            // Closing brace encountered, solve entire brace
            else if (tokens[i] == ')') {
                if(!ignoreOneCloseParen) {
                    while (ops.peek() != '(') {
                        BigDecimal res = applyOp(ops.pop(), values.pop(), values.pop());
                        if(res.equals(ERROR_BIGDEC)) {
                            return ERROR_BIGDEC;
                        }

                        values.push(res);
                    }

                    ops.pop(); //remove open brace
                } else {
                    ignoreOneCloseParen = false;
                }
            }

            // Current token is an operator.
            else if (tokens[i] == '+' || tokens[i] == '-' || tokens[i] == '*' || tokens[i] == '/') {
                if(previousChar == '(' && tokens[i] == '-') {
                    ops.pop();
                    ignoreOneCloseParen = true;
                    negSet = true;
                } else {
                    // While top of 'ops' has same or greater precedence to current
                    // token, which is an operator. Apply operator on top of 'ops'
                    // to top two elements in values stack
                    while (!ops.empty() && hasPrecedence(tokens[i], ops.peek())) {
                        BigDecimal res = applyOp(ops.pop(), values.pop(), values.pop());
                        if(res.equals(ERROR_BIGDEC)) {
                            return ERROR_BIGDEC;
                        }

                        values.push(res);
                    }

                    // Push current token to 'ops'.
                    ops.push(tokens[i]);
                }
            }

            previousChar = tokens[i];
        }

        // System.out.println(values + " " + ops);

        // Entire expression has been parsed at this point, apply remaining
        // ops to remaining values
        while (!ops.empty()) {
            BigDecimal res = applyOp(ops.pop(), values.pop(), values.pop());
            if(res.equals(ERROR_BIGDEC)) {
                return ERROR_BIGDEC;
            }

            values.push(res);
        }

        // Top of 'values' contains result, return it
        return values.pop();
    }

    // Returns true if 'op2' has higher or same precedence as 'op1',
    // otherwise returns false.
    private static boolean hasPrecedence(char op1, char op2) {
        if (op2 == '(' || op2 == ')') {
            return false;
        }

        return !((op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-'));
    }

    // A utility method to apply an operator 'op' on operands 'a'
    // and 'b'. Return the result.
    private static BigDecimal applyOp(char op, BigDecimal b, BigDecimal a) {
        switch (op) {
            case '+':
                return a.add(b, MC);
            case '-':
                return a.subtract(b, MC);
            case '*':
                return a.multiply(b, MC);
            case '/':
                if (b.equals(BigDecimal.ZERO)) {
                    return new BigDecimal(ERROR_CONSTANT);
                }
                return a.divide(b, MC);
            default:
                return BigDecimal.ZERO;
        }
    }
}
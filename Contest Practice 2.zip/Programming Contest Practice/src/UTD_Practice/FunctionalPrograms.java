package UTD_Practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

public class FunctionalPrograms {

    public static void main(String[] args) {
        List<Employees.Employee> employees = new ArrayList<>();
        employees.add(new Employees.Employee("John Doe", 63));

        employees.add(new Employees.Employee("Sally Smith", 29));

        employees.add(new Employees.Employee("Bob Jone", 36));

        employees.add(new Employees.Employee("Margaret Foster", 53));

        printEmployeeClassic(employees, 50);
        System.out.println("================");
        printEmployeeFunctional(employees, 50);

        int[] array = {22, 91, 3, 45, 64, 67, -1};

        List<String> words = Arrays.asList("I", "Like", "Tacos", "But", "Hate", "Burritos");

        /*
        Takes the two strings and returns the longer string.
        It's part of the optional class, as the list reduce()
        is called may be empty.
         */
        Optional<String> longestString = words.stream().reduce((word1, word2) -> word1.length() > word2.length() ? word1 : word2);
        // Stream allows functional programming to be performed on it.
        // This is applied to each element of the string.
        longestString.ifPresent(System.out::println);
    }

    private static void printEmployeeClassic(List<Employees.Employee> employees, int age) {
        for (Employees.Employee emp: employees) { // For-each loop - goes through each employee
            if (emp.getAge() < age) { // Only prints employee out if they're younger than the age parameter.
                System.out.println(emp);
            }
        }
    }

    private static void printEmployeeFunctional(List<Employees.Employee> employees, int age) {
        employees.stream() // Converts list to stream for usage.
                .filter(emp -> emp.age < age) // Only execute the next line if emp.age < age
                .forEach(System.out::println); // For-each loop - goes through each employee and prints them if they match filter.
        /*
        filter() is like the functional equivalent of an if statement.
            filter processes a list to create a new list containing
            only the elements that follow a given predicate.
        forEach() is the functional equivalent for the for statement.
        map() applies a given function to each element of a list.
            It'll return the results in the same order.
        reduce() or fold() reduces a list to a single value, which is
            divided by the array's length to obtain an average.
         */
    }

    @FunctionalInterface
    interface DogAge {
        Integer apply(Dog dog);
    }

    class Dog {

    }

}

class Employees {

    static class Employee {
        String name;
        int age;

        Employee (String name, int age){
            this.name = name;
            this.age = age;
        }

        int getAge() {
            return age;
        }

        @Override
        public String toString() {
            return name + ": " + age;
        }
    }

}

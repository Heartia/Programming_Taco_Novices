import java.util.Scanner;

public class Books {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        
        int t = scan.nextInt();
        
        while(scan.hasNext()){
            
        }
        
        for(int x = 0; x<t; x++){
            
        }
    }
}

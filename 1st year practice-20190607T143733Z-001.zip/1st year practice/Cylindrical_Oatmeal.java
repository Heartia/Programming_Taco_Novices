public class Cylindrical_Oatmeal {
    public double radius;
    public double height;
    
    public Cylindrical_Oatmeal(double radius, double height){
        this.radius = radius;
        this.height = height;
    }
    
    public double circumference(){
        return 2*Math.PI*radius;
    }
    public double volume(){
        return Math.PI*(Math.pow(radius, 2))*height;
    }
    public double surfaceArea(){
        return height*(2*Math.PI*radius)+(2*Math.PI*(Math.pow(radius, 2)));
    }
}


import java.util.Scanner;

public class Weekend_Pass {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int w1 = scanner.nextInt();
        int w2 = scanner.nextInt();
        int w3 = scanner.nextInt();
        int w4 = scanner.nextInt();
        
        int sum = w1+w2+w3+w4;
        
        System.out.println(sum);
    }
    
}

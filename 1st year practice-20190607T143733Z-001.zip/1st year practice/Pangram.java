import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class Pangram {
    public static void main(String args[]) throws FileNotFoundException{
        Scanner scan = new Scanner(new File("Pangram.txt"));
        
        while(scan.hasNext()){
            
            int incri = 0;
            int incrim = 0;
            char[] albet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
            int[] count = new int[26];
            String line = scan.nextLine().trim();
            if(line.equals(".") || line.trim().equals("")){
                break;
            }
            for(int i = 0; i<line.length(); i++){
                if(line.charAt (i)>=65 && line.charAt(i)<=90){
                    if(count[line.charAt(i)-65]==0){
                    incri++;    
                    }
                    count[line.charAt(i)-65]++;
                    incrim++;
                }
                else if(line.charAt(i)>=97){ // Allows for lowercase to be an option, too.
                    if(count[line.charAt(i)-97]==0){
                        incri++;
                    }
                    
                    count[line.charAt(i)-97]++;
                    incrim++;
                }
            }
            if(incri<26){
                System.out.println("Neither Pangram: " + line);
            }
            else if (incrim==26){
                System.out.println("Perfect Pangram: " + line);
            }
            else{
                System.out.println("Gram of the Pan: " + line);
        }
        }
    }
}
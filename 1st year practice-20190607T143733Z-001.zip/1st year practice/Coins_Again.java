import java.util.Scanner;
import java.io.*;

public class Coins_Again {
    public static void main(String[] args) throws FileNotFoundException{
        Scanner scan = new Scanner(new File("Coins_Again.txt"));
        
        int t = scan.nextInt();
        while(scan.hasNext()){
            int c = scan.nextInt();
            int count = 0;
            for(int x = 0; x<c; x++){
                String tres = scan.nextLine();
                String[] ln = tres.split(" ");
                int coin = 0;
                for(int y = 0; y<c; y++){
                    coin = Integer.parseInt(ln[y]);
                    count++;
                    System.out.print(coin + " ");
                }
            }
        }
    }
}
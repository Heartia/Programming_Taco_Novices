import java.util.Scanner;

public class SeeTheCommandant1A
{
    public static void main(String args[])
    {
        String tips1 = "Read the points from your first 5 papers and add them.";
        String tips2 = "If you've earned 100 or more points, you're good!";
        String tips3 = "Otherwise, the Commandant will want to see you.";
        
        System.out.println(tips1+"\n"+tips2+"\n"+tips3+"\n");
        
        Scanner scanner = new Scanner(System.in); //keyboard
        int input1 = scanner.nextInt();
        int input2 = scanner.nextInt();
        int input3 = scanner.nextInt();
        int input4 = scanner.nextInt();
        int input5 = scanner.nextInt();
        
        int sum = input1+input2+input3+input4+input5;
        
        System.out.println("\n"+"Here's your total!"+"\n");
        
        if(sum >= 100)
            System.out.println("You passed! "+ sum+ " points");
        else
            System.out.println("Boi, you betz see dat Commandant! "+ sum+ " points!");
    }
}
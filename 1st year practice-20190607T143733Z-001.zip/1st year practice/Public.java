import java.util.Scanner;

public class Public
{
    public static void main(String args[])
    {
        Scanner scanner = new Scanner(System.in); //keyboard
        int startingMoney = 17;
        int fee = scanner.nextInt();
        System.out.print("Remaining latinum: ");
        System.out.println(startingMoney - fee);
    }
}
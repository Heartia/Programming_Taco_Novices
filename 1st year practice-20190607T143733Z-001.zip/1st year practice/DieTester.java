import java.util.Arrays;
import java.util.Scanner;

public class DieTester {
    public static void main(String[] args){
        try{
        Scanner scan = new Scanner(System.in);
        int toats = scan.nextInt();
        /*Part 1*/
        DieClass die = new DieClass();
        for(int r = 0; r<100; r++){
            if(r+1==100){
                System.out.print(die.roll());
            }
            else{
                System.out.print(die.roll() + ", ");
            }

        }
        
        /*Part 2*/
        int[] valueCount = new int[7];
        for(int ro = 0; ro<100; ro++){
            int county = die.roll();
            valueCount[county]++;
        }
        System.out.println("\n"+Arrays.toString(valueCount));
        
        /*Part 3*/
        DieClass dice = new DieClass();
        int[] valueCount2 = new int[13];
        for(int rol = 0; rol<100; rol++){
            int sum = die.roll()+dice.roll();
            valueCount2[sum]++;
        }
        System.out.println(Arrays.toString(valueCount2));
        
        /*Part 4*/
        int[] valueCount3 = new int[13];
        for(int roll = 0; roll<toats; roll++){
            int sums = die.roll()+dice.roll();
            valueCount3[sums]++;
        }
        System.out.println(Arrays.toString(valueCount3));
        for(int x = 2; x<valueCount3.length; x++){
            System.out.print(x + ":\t");
            for(int i = valueCount3[x]; i>9; i-=10){
                System.out.print("X");
            }
            System.out.print("\n");
        }
        }catch(Exception e){
            System.out.println("ERROR: Wrong input, or integer too big.");
        }
    }
}
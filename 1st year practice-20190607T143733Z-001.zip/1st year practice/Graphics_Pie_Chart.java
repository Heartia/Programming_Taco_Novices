import java.awt.*;
import javax.swing.*;
import java.awt.Color;
import java.awt.Font;

class GraphicsPanel extends JPanel {

	public void paintComponent(Graphics g)
	{
		g.setColor(Color.white);
                g.fillRect(0, 0, 900, 900);
                
                g.setColor(Color.black);
                Font title = new Font("Cambria", Font.BOLD, 40);
                g.setFont(title);                
                g.drawString("University Courses", 200, 50);
                
                Font text = new Font("Comic Sans MS", 100, 15);
                g.setFont(text);
                
                g.setColor(new Color(0xBC6AE8));
                g.fillArc(100, 100, 500, 500, 90, 61); //Language
                g.setColor(Color.black);
                g.drawString("17.037%, 23", 65, 175);
                
                g.setColor(new Color(0x26B793));                
                g.fillArc(100, 100, 500, 500, 151, 43); //Mathematics
                g.setColor(Color.black);
                g.drawString("11.851%, 16", 10, 350);
                
                g.setColor(new Color(0x0064B7));
                g.fillArc(100, 100, 500, 500, 194, 93); //Studies of Social
                g.setColor(Color.black);
                g.drawString("25.925%, 35", 30, 550);
                
                g.setColor(new Color(0xE813B1));
                g.fillArc(100, 100, 500, 500, 287, 51); //SCIENCE
                g.setColor(Color.black);
                g.drawString("14.074%, 19", 575, 550);
                
                g.setColor(new Color(0xFF8A5E));                
                g.fillArc(100, 100, 500, 500, 338, 112); //Arts that are fine
                g.setColor(Color.black);
                g.drawString("31.111%, 42", 625, 300);
                
                g.setColor(new Color(0xBC6AE8));
                g.fillRoundRect(600, 600, 30, 30, 10, 10);
                g.setColor(Color.black);
                g.drawString("Languages", 650, 620);
                
                g.setColor(new Color(0x26B793));
                g.fillRoundRect(600, 650, 30, 30, 10, 10);
                g.setColor(Color.black);
                g.drawString("The Maths", 650, 670);
                
                g.setColor(new Color(0x0064B7));
                g.fillRoundRect(600, 700, 30, 30, 10, 10);
                g.setColor(Color.black);
                g.drawString("Studies of Social", 650, 720);
                
                g.setColor(new Color(0xE813B1));
                g.fillRoundRect(600, 750, 30, 30, 10, 10);
                g.setColor(Color.black);
                g.drawString("The Science", 650, 770);
                
                g.setColor(new Color(0xFF8A5E));
                g.fillRoundRect(600, 800, 30, 30, 10, 10);
                g.setColor(Color.black);
                g.drawString("Arts that are Fine", 650, 820);
	}
}
public class Graphics_Pie_Chart {

  public static void main(String[] args) {
      //This is a necessary in order to create the frame window
      javax.swing.SwingUtilities.invokeLater(new Runnable() {
          public void run() {
              start();
          }
      });
  }

  public static void start() {

    //Sets up the frame
    JFrame frame = new JFrame("Graphics");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    //Adds the graphics panel and sets the size
    frame.setSize(new Dimension(900,900));
    frame.getContentPane().add(new GraphicsPanel(), BorderLayout.CENTER);
    frame.setVisible(true);
  }
}
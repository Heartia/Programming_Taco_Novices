import java.io.File;
import java.util.Scanner;
import java.util.Arrays;

public class Letter_Tax{
    public static void main(String[] args)throws Exception{
        Scanner scan = new Scanner(new File("Letter_Tax.text"));
        
        int t = scan.nextInt();
        
        for(int i = 0; i<t; i++){
            int toats = scan.nextInt();
            String sent = scan.next();
            
            char[] ln = sent.toCharArray();
            for(int j = 0; j<ln.length; j++){
                if(j%toats==0){
                    ln[j]=' ';
                }
            }
            String tence = Arrays.toString(ln);
            
            System.out.println(tence);
        }
    }
}
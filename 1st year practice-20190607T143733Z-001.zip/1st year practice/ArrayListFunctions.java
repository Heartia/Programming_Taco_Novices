import java.util.*;
import java.io.*;
import java.lang.*;

public class ArrayListFunctions {

	public ArrayList<Integer> Listy = new ArrayList<>();

	/*  Create an ArrayFunctions object
	 *  Calls all the methods to test the results
	 */
	public static void main(String args[]) throws FileNotFoundException
	{
		ArrayListFunctions aLF = new ArrayListFunctions();

		aLF.readInDataFile("ArrayData1.txt");

		System.out.println("ArrayList: \t" + aLF.getStringOfValues());
		System.out.println("Sum: \t\t" + aLF.sum());
		System.out.println("Average: \t" + aLF.average());
		System.out.println("Max: \t\t" + aLF.max());
                System.out.println("Find 7: \t" + aLF.find(7));
                System.out.println("Find 99: \t" + aLF.find(99));
		System.out.println("Ascending: \t" + aLF.isAscending());
		System.out.println("Count>10: \t" + aLF.countAboveThreshold(10));
                System.out.println("All>10: \t" + aLF.allAboveThreshold(10));
	}



	/*  Reads a data file and fill the array with data
	 *  Initializes and fills array
	 *  The first integer in the datafile is the size of the array.
	 */
	public void readInDataFile( String fileName ) throws FileNotFoundException
	{
            Scanner scan = new Scanner(new File("ArrayData1.txt"));
            int num = scan.nextInt();
            for(int i = 0; i<num; i++){
                int numero = scan.nextInt();
                Listy.add(numero);
            }
	}
        
        /*  
        *   Returns all values separated by a space.
        */
        public String getStringOfValues(){
            String full = "";
            for(int i = 0; i<Listy.size(); i++){
                full += Listy.get(i) + " ";
            }
            return full;
        }
	/*
	 *  Calculates and returns the sum of the array elements
	 */
	public Integer sum()
	{
            int sum = 0;
            for(int num = 0; num<Listy.size(); num++){
                sum+=Listy.get(num);
            }
            return sum;
	}

	/*
	 * Calculates and returns the average of the array elements as a double
	 */
	public Double average()
	{
            double average=(double)sum();
            average/=Listy.size();
            return average;
	}

	/*
	 * Returns the largest value in the array
	 */
	public Integer max()
	{
            int max = Listy.get(0);
            for(int in = 0; in<Listy.size(); in++){
                if (Listy.get(in)>max){
                    max=Listy.get(in);
                }
            }
            return max;
	}
        /*
	 *  Returns the index of key in the array; or return -1 if not key found
	 *
	 */
        public Integer find(Integer key)
        {
            for(int hole = 0; hole<Listy.size(); hole++){
                if (Objects.equals(Listy.get(hole), key)){
                    return hole;
                }
            }
            return -1;
        }

	/*
	 * Returns true if all the elements are in ascending order.
	 * Duplicate values are allowed in ascending order.
	 */
	public boolean isAscending()
	{
            boolean isAscending = false;
            for(int asc = 0; asc<Listy.size(); asc++){
            	int rise = Listy.get(asc);
            	int up = Listy.get(asc+1);
            	if(rise<up){
            		isAscending = true;
            	}
            	else{
            		isAscending = false;
            		break;
            	}
            }
            return isAscending;
	}

	/*
	 * Returns true if all the elements are in ascending order.
	 * Duplicate values are allowed in ascending order.
	 */
	public int countAboveThreshold(int thresh)
	{
            int count = 0;
            for(int c = 0; c<Listy.size(); c++){
                if (Listy.get(c)>thresh){
                    count++;
                }
            }
            return count;
	}
        public ArrayList<Integer>allAboveThreshold(int thresh){
            int count = 0;
            for(int c = 0; c<Listy.size(); c++){
                if (Listy.get(c)>thresh){
                    count++;
                }
            }
            ArrayList<Integer> thold = new ArrayList<>();
            int res = 0;
            for (int j = 0; j<Listy.size(); j++){
                if (Listy.get(j)>thresh){
                    thold.add(Listy.get(j));
                    res++;
                }
            }
            return thold;
        }
}
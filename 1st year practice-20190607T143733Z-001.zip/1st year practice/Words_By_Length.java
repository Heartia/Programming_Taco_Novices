import java.util.Scanner;
import java.util.*;
import java.io.*;

public class Words_By_Length {
    public static void main (String [] args) throws FileNotFoundException {
        Scanner scan = new Scanner (new File("Words_By_Length.txt"));
        int i = scan.nextInt();
        String[] words = new String[i];
        int count = 0;
        
        for(int x = 0; x<words.length; x++){
            String word = scan.next();
            words[x] = word;
        }
        /* Reads in file and places into array */
        for(int j = 1; j<25; j++){
            String result = (j + ": ");
            for(int k = 0; k<words.length; k++){
                if(words[k].length()==j){
                        result+=(words[k]+", ");
                }
            }
            if(!result.equals(j + ": ")){
                System.out.println(result.substring(0, result.length()-2));
            }
        }
    }
}
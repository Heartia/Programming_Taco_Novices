import java.util.Scanner;
import java.io.*;

public class Coins {
    public static void main(String[] args)throws FileNotFoundException{
            Scanner scan = new Scanner(new File("Coins.txt"));
            
            int t = scan.nextInt();
            
            for(int x = 0; x<t; x++){
                int result = 0;
                
                int h = scan.nextInt();
                if(h%2==1){
                    result = (h/2)+1;
                }
                else{
                    result = h/2;
                }
                System.out.println(result);
            }
    }
}

import java.io.*;
import java.util.*;

public class Arraylist_Practice {
    public static void main(String[] args)throws FileNotFoundException{
        ArrayList<String> Stringy = new ArrayList<String>();
        LinkedList<String> SuperStringy = new LinkedList<String> ();
        Scanner scan = new Scanner(System.in);
        
        while(true){
            String st = scan.next();
            if(st.equals("end")){
                break;
            }
            Stringy.add(st);
            SuperStringy.add(st);
        }
        for(int i = 0; i<Stringy.size(); i++){
            String get = Stringy.get(i);
            String getty = SuperStringy.get(i);
            System.out.println(get.substring(0, 1));
            System.out.println(getty.substring(0, 1));
        }
        System.out.println(Stringy);
        System.out.println(SuperStringy);
    }
}
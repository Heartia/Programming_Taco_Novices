public class Array_of_HOPE {
    public static void main (String args[]){
        char ch[] = new char[26];
        int a = 0;
        
        for(int t = 65; t<=90; t++){
            ch[a] = (char)t;
            a++;
        }
        
        for (int c = 0; c<ch.length; c++){
            System.out.print(ch[c]+ ", ");
        }
        
//        for (int c = 26; c<=ch.length; c--){
//            char o = (char) ((char)c+39);
//            System.out.println(o + ", ");
//        }
    }
}
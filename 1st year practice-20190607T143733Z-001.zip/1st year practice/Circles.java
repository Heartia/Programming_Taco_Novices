public class Circles
{
    public double radius;
    
    public Circles(double r)
    {
        radius = r;
    }
    public double area( )
    {
        double area = Math.PI * radius * radius;
        return area;
    }
    public double circumference( )
    {
        double circum = 2 * Math.PI * radius;
        return circum;
    }
    public double diameter ( )
    {
        double diameter = 2*radius;
        return diameter;
    }
}
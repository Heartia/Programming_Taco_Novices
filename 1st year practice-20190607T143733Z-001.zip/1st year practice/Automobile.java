public class Automobile{

    public double mpg;
    public double gallons = 0;

    public Automobile(double mpg){
        this.mpg = mpg;
    }
    public void fillUp(double fuel){
        gallons+=fuel;
    }
    public void takeTrip(double miles){
        gallons -= miles/mpg;
    }
    public double reportFuel(){
        return gallons;
    }
}

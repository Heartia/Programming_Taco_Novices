import java.io.*;
import static java.lang.Integer.toBinaryString;
import java.util.Arrays;
import java.util.Scanner;

public class Dotted_Decimal {
    public static void main(String args[]) throws FileNotFoundException{
        Scanner scan = new Scanner(new File("Dotted_Decimal.txt"));
        
        int ips = scan.nextInt();
        String b = "";
        
        for (int num = 0; num<ips; num++){
            String adrs = scan.next();
            String ip[] = adrs.split("\\.");
            for (int r = 0; r < ip.length; r++){
                int n = Integer.parseInt(ip[r]);
                b = toBinaryString(n);
                for (int t = b.length(); t < 8; t++){
                    b="0"+b;
                }
                System.out.print(b);
                }
            System.out.println("");
        }
    }
}

public class Deck_Of_Cards {
    public static void main(String[] args){
        Deck_Of_Cards_Deck decky = new Deck_Of_Cards_Deck();
        System.out.println(decky);
        decky.shuffle();
        System.out.println(decky);
        for(int i = 0; i<5; i++){
            System.out.println(decky.drawCard());
        }
    }
}
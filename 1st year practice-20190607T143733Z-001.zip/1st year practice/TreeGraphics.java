import java.awt.*;
import javax.swing.*;

class TreePanel extends JPanel {

	public void paintComponent(Graphics g)
	{
		g.setColor(Color.green);
            
                int x[] = {400, 475, 450, 500, 450, 525, 475, 550, 450, 475, 425, 425, 425, 425,   375, 375, 400, 375, 325, 350, 250, 325, 275, 350, 300, 350, 325, 400};
                int y[] = {100, 200, 200, 275, 250, 350, 325, 425, 400, 425, 412, 400, 412, 475,   475, 412, 400, 412, 425, 400, 425, 325, 350, 250, 275, 200, 200, 100};
                int points = x.length;
                g.fillPolygon(x, y, points);
	}
}

public class TreeGraphics {

  public static void main(String[] args) {
      //This is a necessary in order to create the frame window
      javax.swing.SwingUtilities.invokeLater(new Runnable() {
          public void run() {
              start();
          }
      });
  }

  public static void start() {

    //Sets up the frame
    JFrame frame = new JFrame("Graphics");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    //Adds the graphics panel and sets the size
    frame.setSize(new Dimension(800,600));
    frame.getContentPane().add(new TreePanel(), BorderLayout.CENTER);
    frame.setVisible(true);
  }
}
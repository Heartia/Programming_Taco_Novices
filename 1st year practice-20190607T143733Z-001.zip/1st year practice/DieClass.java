import java.util.Random;

public class DieClass {
    private int sides;
    private int value;
    
    public DieClass(){
        sides = 6;
    }
    
    public DieClass(int sides){
        this.sides = sides;
    }
    
    public int roll(){
        Random rando = new Random();
        value = rando.nextInt(sides)+1;
        return value;
    }
    
    public int getValue(){
        return value;
    }
    
    public int getSides() {
        return sides;
    }
    
    public String toString() {
        return "Die[value=" + value + ", sides=" + sides + "]";
    }
}
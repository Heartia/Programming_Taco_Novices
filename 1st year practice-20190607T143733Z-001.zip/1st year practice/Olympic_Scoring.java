import java.util.Scanner;
import java.util.*;
import java.io.*;

public class Olympic_Scoring {
    public static void main (String[] args) throws FileNotFoundException {
        Scanner scan = new Scanner (new File("Olympic_Scoring.txt"));
        
        int N = scan.nextInt();
        int[] athletes = new int[N];
        double biggy = -1;
        String bigname = "";
        double average = 0;
        
        for (int i = 0; i<N; i++){
            String name = scan.next();
            
            double[] scores = new double[7];
            for(int k = 0; k<scores.length; k++){
                double numero = scan.nextDouble();
                scores[k] = numero;
            }
            Arrays.sort(scores);
            
            double sum = 0;
            
            for (int j = 1; j<scores.length-1; j++){
                sum+=scores[j];
            }
            
            double avg = sum/5;
            if(avg>biggy){
                biggy = avg;
                bigname = name;
            }
            
            System.out.printf("%10s %.2f%n", name, avg);
        }
        System.out.println("Winner: " + bigname);
    }
}
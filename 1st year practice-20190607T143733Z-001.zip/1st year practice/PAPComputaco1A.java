import java.util.Scanner;

public class PAPComputaco1A
{
    public static void main(String args[])
    {
        Scanner scanner = new Scanner(System.in);
        int startingMoney = 17;
        int fee = scanner.nextInt(); //Leave () blank
        System.out.println(startingMoney - fee);
    }
}
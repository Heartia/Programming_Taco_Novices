public class CircleTester
{
    public static void main( String args[] )
    {
        Circles cir1 = new Circles(35.5);
        System.out.println( cir1.diameter( ) ); 
    }
}


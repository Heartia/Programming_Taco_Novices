public class BankAccountTester {
    public static void main(String[] args) {
        double amount = 1000;
        String name = "Sheldon P Duncan Jean";
        
        BankAccount myaccount = new BankAccount(1000, "Sheldon P Duncan Jean");
        myaccount.deposit(505.22);
        myaccount.withdraw(100);
        System.out.println("The " + myaccount.name + " account balance is, $" + myaccount.balance);
    }
}

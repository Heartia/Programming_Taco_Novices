import java.util.Scanner;

public class Basic_Calulator2 {
    public static void main(String[ ] args) {
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Calculator V1.0.0");
        System.out.println("Place spaces between operands and operators");
        System.out.println(" *For one number operations, put two numbers in");
        System.out.println("  to see the output of both numbers.");
        System.out.println("Acceptable Operators:");
        System.out.println("+, -, *, /, ^, %, sin, cos, tan, >, <");
        System.out.println("abs, floor, ceil, round, log");
        System.out.println("\nExample:");
        System.out.println("Input: 500000 ^ 5\n");
        System.out.println("Output:");
        System.out.println("500000.0 ^ 5.0");
        System.out.println("Calculating...");
        System.out.println("3.125E28\n");
        
        while(scan.hasNext()){
            
            double a = 0;
            String equa = "";
            double b = 0;
            
            try{
                a = scan.nextDouble();
                equa = scan.next();
                b = scan.nextDouble();
            }catch (Exception ex) {
                System.out.println("ERROR - Please enter correct input");
                System.out.println("");
                break;
            }
            
            System.out.println(a + " " + equa + " " + b);
            System.out.println("Calculating...");
            
            try{
            if(equa.equals("+")){
                System.out.println(a+b);
                System.out.println("");
            }
            else if(equa.equals("-")){
                System.out.println(a-b);
                System.out.println("");
            }
            else if(equa.equals("*")){
                System.out.println(a*b);
                System.out.println("");
            }
            else if(equa.equals("/")){
                System.out.println(a/b);
                System.out.println("");
            }
            else if(equa.equals("^")){
                System.out.println(Math.pow(a, b));
                System.out.println("");
            }
            else if(equa.equals("%")){
                System.out.println("R " + a%b);
                System.out.println("");
            }
            else if(equa.equals(">")){
                if(a>b){
                    double c = a-b;
                    System.out.println("True by " + c);
                    System.out.println("");
                }
                else{
                    System.out.println("false");
                    System.out.println("");
                }
            }
            else if(equa.equals("<")){
                if(b>a){
                    double c = b-a;
                    System.out.println("True by " + c);
                    System.out.println("");
                }
                else{
                    System.out.println("false");
                    System.out.println("");
                }
            }
            else if(equa.equals("cos")){
                System.out.println(a*(Math.cos(Math.toDegrees(b))));
                System.out.println("");
            }
            else if(equa.equals("sin")){
                System.out.println(a*(Math.sin(Math.toDegrees(b))));
                System.out.println("");
            }
            else if(equa.equals("tan")){
                System.out.println(a*(Math.tan(Math.toDegrees(b))));
                System.out.println("");
            }
            else if(equa.equals("abs")){
                System.out.println(Math.abs(a));
                System.out.println(Math.abs(b));
                System.out.println("");
            }
            else if(equa.equals("ceil")){
                System.out.println(Math.ceil(a));
                System.out.println(Math.ceil(b));
                System.out.println("");
            }
            else if(equa.equals("floor")){
                System.out.println(Math.floor(a));
                System.out.println(Math.floor(b));
                System.out.println("");
            }
            else if(equa.equals("round")){
                System.out.println(Math.round(a) + ".0");
                System.out.println(Math.round(b) + ".0");
                System.out.println("");
            }
            else if(equa.equals("log")){
                System.out.println(Math.log(a));
                System.out.println(Math.log(b));
                System.out.println("");
            }
            else if(equa.equals("end")){
                System.out.println("End");
                break;
            }
            else{
                System.out.println("ERROR - Please enter correct input\n");
            }
        }catch (Exception e){
            System.out.println("ERROR - Error has been met");
        }
        }
    }
}

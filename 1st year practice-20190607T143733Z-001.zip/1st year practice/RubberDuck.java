
public class RubberDuck {
    public String colour;
    public String saying;
    public String name;
    public int id;
    
    public static int duckCount = 0;
    public static int nextID = 1000;
    
    public RubberDuck(String name, String colour, String saying){
        this.colour = colour;
        this.saying = saying;
        this.name = name;
        
        this.id = nextID;
        duckCount++;
        nextID++;
    }
    
    public String toString (){
        return name + " #" + id + ", a " + colour + " duck, says, " + saying;
    }
    
    public static void printStatus () {
        System.out.println("There are " + duckCount + " RubberDuck objects made.");
        System.out.println("The next ID# will be " + nextID);
    }
}
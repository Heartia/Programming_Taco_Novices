import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Deck_Of_Cards_Deck {
    private ArrayList<Deck_Of_Cards_Card> cards = new ArrayList<>();
    
    public Deck_Of_Cards_Deck (){
        createCards();
    }
    
    private void createCards(){
        String[] suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
        String[] values = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
        for(int s = 0; s<suits.length; s++){
            for(int v = 0; v<values.length; v++){
                cards.add(new Deck_Of_Cards_Card(suits[s], values[v]));
            }
        }
    }
    
    public void shuffle(){
        Random r = new Random();
        for(int i = 0; i<cards.size(); i++){
            int n = r.nextInt(cards.size());
            Deck_Of_Cards_Card hold = cards.get(i);
            cards.set(i, cards.get(n));
            cards.set(n, hold);
        }
    }
    
    public Deck_Of_Cards_Card drawCard() {
        if(cards.isEmpty()){
            return null;
        }
        Deck_Of_Cards_Card draw = cards.remove(0);
        return draw;
    }
    
    public String toString() {
        String strung = "";
        for(int k = 0; k<cards.size(); k++){
            strung+=cards.get(k)+", ";
            if(k%4==3){
                strung+="\n";
            }
        }
        return strung;
    }
}
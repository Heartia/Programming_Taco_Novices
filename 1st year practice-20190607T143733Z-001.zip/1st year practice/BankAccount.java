public class BankAccount {
    public double balance;
    public String name;

    public BankAccount(double abalance, String aname){
        balance = abalance;
        name = aname;
    }
    
    public void deposit(double deposito)
    {
        balance+=deposito;
    }
    
    public void withdraw(double withdrawl)
    {
        balance-=withdrawl;
    }
}
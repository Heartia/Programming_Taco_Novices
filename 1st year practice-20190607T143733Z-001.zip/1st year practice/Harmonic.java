import java.util.Scanner;
import java.io.*;

public class Harmonic {
    public static void main(String[] args) throws FileNotFoundException{
        Scanner scan = new Scanner(new File("Harmonic.txt"));
        
        int t = scan.nextInt();
        for(int x = 0; x<t; x++){
            double n = scan.nextDouble();
            double r = 0;
            for(double y = 1; y<=n; y++){
                r+=1/y;
            }
            System.out.printf("%.3f", r);
            System.out.println("");
        }
    }
}
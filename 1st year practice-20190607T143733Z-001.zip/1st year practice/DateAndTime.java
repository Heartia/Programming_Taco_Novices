import java.util.Calendar;
import java.util.Date;

public class DateAndTime {
    public static void main (String args[]){
        Calendar hour = Calendar.getInstance();
        System.out.println(hour);
    }

//    private static int getTime() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
}

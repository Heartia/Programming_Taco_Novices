import java.util.Scanner;

public class Cylindrical_Oatmeal_Tester {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        
        while(true){
            System.out.print("What is the radius of the cylinder? ");
            double radius = scan.nextDouble();
            System.out.print("\nWhat is the height of the cylinder? ");
            double height = scan.nextDouble();
            
            Cylindrical_Oatmeal oats = new Cylindrical_Oatmeal(radius, height);
            
            if(radius==0||height==0){
                System.out.println("\nend");
                break;
            }
            
            System.out.println("\nCircumference = " + oats.circumference());
            System.out.println("Volume = " + oats.volume());
            System.out.println("Surface Area = " + oats.surfaceArea());
        }
    }
}

import java.util.Scanner;
import java.io.*;

public class Factorial {
    public static void main(String[] args) throws FileNotFoundException{
        Scanner scan = new Scanner(new File("Factorial.txt"));
        
        int n= scan.nextInt();
        int[]a=new int[n];
        
        for(int i=0;i<n;i++){
            a[i]=scan.nextInt();}
        
        for(int i=0;i<n;i++){
            int b=0;
            int c=a[i];
            String d="";
            while(c>0){
                d+=c+"x";
                c--;
                if(c==0){
                System.out.println(d.substring(0,d.length()-1));}
            }
        }
    }
}

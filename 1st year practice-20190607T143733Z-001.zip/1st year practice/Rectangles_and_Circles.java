import java.awt.*;
import javax.swing.*;

class MainPanel extends JPanel {

	public void paintComponent(Graphics g)
	{
		g.fillOval(100,100,200,200);
                
		g.drawRect(400,100,200,200);
                g.drawLine(500,200,500,300);
                
                g.drawString("Sheldon P. Duncan-Jean", 50, 363);
                
                g.drawOval(100,400,200,200);
                g.drawOval(175,400,50,200);
                g.drawOval(137,400,125,200);
                g.drawOval(100,475,200,50);
                g.drawOval(100,437,200,125);
                
                g.drawRect(400,400,200,200);
                g.drawRect(450,450,200,200);
                g.drawLine(400,400,450,450);
                g.drawLine(600,600,650,650);
                g.drawLine(400,600,450,650);
                g.drawLine(600,400,650,450);
                
                g.draw3DRect(700, 700, 100, 100, true);
	}
}

public class Rectangles_and_Circles {

  public static void main(String[] args) {
      //This is a necessary in order to create the frame window
      javax.swing.SwingUtilities.invokeLater(new Runnable() {
          public void run() {
              start();
          }
      });
  }

  public static void start() {

    //Sets up the frame
    JFrame frame = new JFrame("Graphics");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    //Adds the graphics panel and sets the size
    frame.setSize(new Dimension(1000,1000));
    frame.getContentPane().add(new MainPanel(), BorderLayout.CENTER);
    frame.setVisible(true);
  }
}
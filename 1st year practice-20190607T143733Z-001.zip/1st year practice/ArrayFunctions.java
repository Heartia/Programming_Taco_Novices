import java.util.*;
import java.io.*;

public class ArrayFunctions {

	public int[] arrays;

	/*  Create an ArrayFunctions object
	 *  Calls all the methods to test the results
	 */
	public static void main(String args[]) throws FileNotFoundException
	{
		ArrayFunctions aF = new ArrayFunctions();

		aF.readInDataFile("ArrayData1.txt");

		System.out.println("Array: \t\t" + Arrays.toString(aF.arrays));
		System.out.println("Sum: \t\t" + aF.sum());
		System.out.println("Average: \t" + aF.average());
		System.out.println("Max: \t\t" + aF.max());
		System.out.println("Min: \t\t" + aF.min());
                System.out.println("Find 7: \t" + aF.find(7));
                System.out.println("Find 99: \t" + aF.find(99));
		System.out.println("Ascending: \t" + aF.isAscending());
		System.out.println("Descending:\t" + aF.isDescending());
		System.out.println("Above 10: \t" + Arrays.toString(aF.aboveThreshold(10)));
	}


	/*  Reads a data file and fill the array with data
	 *  Initializes and fills array
	 *  The first integer in the datafile is the size of the array.
	 */
	public void readInDataFile( String fileName ) throws FileNotFoundException
	{
            Scanner scan = new Scanner(new File(fileName));
            int num = scan.nextInt();
            arrays = new int[num];
            for(int i = 0; i<num; i++){
                int numero = scan.nextInt();
                arrays[i] = numero;
            }
            arrays = arrays;
	}

	/*
	 *  Calculates and returns the sum of the array elements
	 */
	public int sum()
	{
            int sum = 0;
            for(int num = 0; num<arrays.length; num++){
                sum+=arrays[num];
            }
            return sum;
        }
	/*
	 * Calculates and returns the average of the array elements as a double
	 */
	public double average()
	{
            double average=(double)sum();
            average/=arrays.length;
            return average;
        }

	/*
	 * Returns the largest value in the array
	 */
	public int max()
	{
            int max = arrays[0];
            for(int in = 0; in<arrays.length; in++){
                if (arrays[in]>max){
                    max=arrays[in];
                }
            }
            return max;
	}

	/*
	 *  Returns the smallest value in the array
	 *
	 */
	public int min()
	{
            int min = arrays[0];
            for(int nt = 0; nt<arrays.length; nt++){
                if (arrays[nt]<min){
                    min=arrays[nt];
                }
            }
            return min;
        }
        
        /*
	 *  Returns the index of key in the array; or return -1 if not key found
	 *
	 */
        public int find(int key)
        {
            for(int hole = 0; hole<arrays.length; hole++){
                if (arrays[hole]==key){
                    return hole;
                }
            }
            return -1;
        }

	/*
	 * Returns true if all the elements are in ascending order.
	 * Duplicate values are allowed in ascending order.
	 */
	public boolean isAscending()
	{
            boolean isAscending = false;
            for(int asc = 0; asc<arrays.length; asc++){
            	int rise = arrays[asc];
            	int up = arrays[asc+1];
            	if(rise<up){
            		isAscending = true;
            	}
            	else{
            		isAscending = false;
            		break;
            	}
            }
            return isAscending;
        }

	/*
	 * Returns true if all the elements are in ascending order.
	 * Duplicate values are allowed in ascending order.
	 */
	public boolean isDescending()
	{
            boolean isDescending = false;
            for(int desc = 0; desc<arrays.length; desc++){
            	int lower = arrays[desc];
            	int down = arrays[desc+1];
            	if(lower>down){
            		isDescending = true;
            	}
            	else{
            		isDescending = false;
            		break;
            	}
            }
            return isDescending;
        }

	/*
	 *  Returns an array of the all the values in the array above a threshold
	 */
	public int[] aboveThreshold(int thresh)
	{
            int count = 0;
            for(int c = 0; c<arrays.length; c++){
                if (arrays[c]>thresh){
                    count++;
                }
            }
            int[] thold = new int[count];
            int res = 0;
            for (int j = 0; j<arrays.length; j++){
                if (arrays[j]>thresh){
                    thold[res]=arrays[j];
                    res++;
                }
            }
            return thold;
        }
}
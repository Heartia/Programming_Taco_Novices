public class Coaches {
    public static void main(String[] args){
        System.out.println("Thank you!");
    }
}
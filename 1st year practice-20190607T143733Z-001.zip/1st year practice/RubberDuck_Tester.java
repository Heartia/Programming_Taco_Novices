import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class RubberDuck_Tester {
    public static void main (String args[]) throws FileNotFoundException {
        Scanner scan = new Scanner(new File("RubberDuck.txt"));
        int t = scan.nextInt();
        for (int a = 0; a<t; a++) {
            String name = scan.next();
            String colour = scan.next();
            String saying = scan.next();
            
            RubberDuck ducky = new RubberDuck(name, colour, saying);
            System.out.println(ducky);
        }
        RubberDuck.printStatus();
    }
}
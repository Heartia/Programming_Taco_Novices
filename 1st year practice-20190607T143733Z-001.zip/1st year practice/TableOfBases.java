import static java.lang.Integer.toHexString;
import static java.lang.Integer.toBinaryString;
import static java.lang.Integer.toOctalString;

public class TableOfBases {
    public static void main (String args[]){
        System.out.printf("%-10s%-10s%-10s%-10s%-10s%n", "Decimal", "Binary", "Octal", "Hex", "Character");
        for(int j = 65; j<=90; j++){
            char ch = (char)j;
            String b = toBinaryString(j);
            String o = toOctalString(j);
            String h = toHexString(j);
            System.out.printf("%-10s%-10s%-10s%-10s%-10s%n", j, b, o, h, ch);
        }
    }
}
